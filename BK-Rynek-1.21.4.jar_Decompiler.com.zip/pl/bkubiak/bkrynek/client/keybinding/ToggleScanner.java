package pl.bkubiak.bkrynek.client.keybinding;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import org.lwjgl.glfw.GLFW;
import pl.bkubiak.bkrynek.client.util.ColorUtils;
import pl.bkubiak.bkrynek.core.util.Messages;

@Environment(EnvType.CLIENT)
public class ToggleScanner {
   public static class_304 toggleScanningKey;
   public static boolean scanningEnabled = true;

   public static void init() {
      toggleScanningKey = KeyBindingHelper.registerKeyBinding(new class_304("Włączenie podświetlenia itemów", 82, "BK-Rynek"));
      ClientTickEvents.END_CLIENT_TICK.register((ClientTickEvents.EndTick)(client) -> {
         while(toggleScanningKey.method_1436()) {
            long window = client.method_22683().method_4490();
            boolean ctrlPressed = GLFW.glfwGetKey(window, 341) == 1 || GLFW.glfwGetKey(window, 345) == 1;
            if (ctrlPressed) {
               scanningEnabled = !scanningEnabled;
               String msgKey = scanningEnabled ? "command.scanner.toggle.on" : "command.scanner.toggle.off";
               String msg = Messages.get(msgKey);
               if (client.field_1724 != null) {
                  client.field_1724.method_7353(ColorUtils.translateColorCodes(msg), false);
               }
            }
         }

      });
   }
}
