package pl.bkubiak.bkrynek.client.keybinding;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import org.lwjgl.glfw.GLFW;
import pl.bkubiak.bkrynek.client.util.SearchAutomationController;
import pl.bkubiak.bkrynek.core.util.Messages;

@Environment(EnvType.CLIENT)
public class ToggleAutomation {
   public static class_304 toggleAutomationKey;

   public static void init() {
      toggleAutomationKey = KeyBindingHelper.registerKeyBinding(new class_304("Włączenie/Wyłączenie bota", 72, "BK-Rynek"));
      ClientTickEvents.END_CLIENT_TICK.register((ClientTickEvents.EndTick)(client) -> {
         while(toggleAutomationKey.method_1436()) {
            long window = client.method_22683().method_4490();
            boolean ctrlPressed = GLFW.glfwGetKey(window, 341) == 1 || GLFW.glfwGetKey(window, 345) == 1;
            if (ctrlPressed) {
               if (SearchAutomationController.isActive()) {
                  SearchAutomationController.cancel();
                  SearchAutomationController.sendFeedback(Messages.get("command.automation.toggle.off"), 16733525);
               } else {
                  SearchAutomationController.start(3);
                  SearchAutomationController.sendFeedback(Messages.get("command.automation.toggle.on"), 5635925);
               }
            }
         }

      });
   }
}
