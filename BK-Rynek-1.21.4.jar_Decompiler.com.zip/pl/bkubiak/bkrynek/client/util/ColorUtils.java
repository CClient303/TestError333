package pl.bkubiak.bkrynek.client.util;

import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_124;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_2583;
import net.minecraft.class_5250;
import net.minecraft.class_2558.class_2559;
import net.minecraft.class_2568.class_5247;

@Environment(EnvType.CLIENT)
public class ColorUtils {
   private static final Pattern URL_PATTERN = Pattern.compile("(?:https?://|www\\.)\\S+|dc\\.bkubiak\\.dev|tipply\\.pl\\S*", 2);

   public static class_2561 translateColorCodes(String input) {
      if (input != null && !input.isEmpty()) {
         class_5250 result = class_2561.method_43473();
         StringBuilder currentSegment = new StringBuilder();
         class_2583 currentStyle = class_2583.field_24360;
         char[] chars = input.toCharArray();

         for(int i = 0; i < chars.length; ++i) {
            char c = chars[i];
            if (c == '&' && i + 1 < chars.length) {
               if (currentSegment.length() > 0) {
                  appendWithLinks(result, currentSegment.toString(), currentStyle);
                  currentSegment.setLength(0);
               }

               ++i;
               char code = Character.toLowerCase(chars[i]);
               currentStyle = applyColorCode(code);
            } else {
               currentSegment.append(c);
            }
         }

         if (currentSegment.length() > 0) {
            appendWithLinks(result, currentSegment.toString(), currentStyle);
         }

         return result;
      } else {
         return class_2561.method_43473();
      }
   }

   private static void appendWithLinks(class_5250 root, String text, class_2583 style) {
      Matcher matcher = URL_PATTERN.matcher(text);

      int lastEnd;
      int end;
      for(lastEnd = 0; matcher.find(); lastEnd = end) {
         int start = matcher.start();
         end = matcher.end();
         if (start > lastEnd) {
            String pre = text.substring(lastEnd, start);
            root.method_10852(class_2561.method_43470(pre).method_10862(style));
         }

         String url = text.substring(start, end);
         String target = url;
         if (!url.toLowerCase().startsWith("http")) {
            target = "https://" + url;
         }

         class_2583 linkStyle = style.method_10958(new class_2558(class_2559.field_11749, target)).method_10949(new class_2568(class_5247.field_24342, class_2561.method_43470("Otwórz: " + target)));
         root.method_10852(class_2561.method_43470(url).method_10862(linkStyle));
      }

      if (lastEnd < text.length()) {
         String post = text.substring(lastEnd);
         root.method_10852(class_2561.method_43470(post).method_10862(style));
      }

   }

   private static class_2583 applyColorCode(char code) {
      if (code == 'r') {
         return class_2583.field_24360;
      } else {
         switch (code) {
            case '0':
               return class_2583.field_24360.method_10977(class_124.field_1074);
            case '1':
               return class_2583.field_24360.method_10977(class_124.field_1058);
            case '2':
               return class_2583.field_24360.method_10977(class_124.field_1077);
            case '3':
               return class_2583.field_24360.method_10977(class_124.field_1062);
            case '4':
               return class_2583.field_24360.method_10977(class_124.field_1079);
            case '5':
               return class_2583.field_24360.method_10977(class_124.field_1064);
            case '6':
               return class_2583.field_24360.method_10977(class_124.field_1065);
            case '7':
               return class_2583.field_24360.method_10977(class_124.field_1080);
            case '8':
               return class_2583.field_24360.method_10977(class_124.field_1063);
            case '9':
               return class_2583.field_24360.method_10977(class_124.field_1078);
            case ':':
            case ';':
            case '<':
            case '=':
            case '>':
            case '?':
            case '@':
            case 'A':
            case 'B':
            case 'C':
            case 'D':
            case 'E':
            case 'F':
            case 'G':
            case 'H':
            case 'I':
            case 'J':
            case 'K':
            case 'L':
            case 'M':
            case 'N':
            case 'O':
            case 'P':
            case 'Q':
            case 'R':
            case 'S':
            case 'T':
            case 'U':
            case 'V':
            case 'W':
            case 'X':
            case 'Y':
            case 'Z':
            case '[':
            case '\\':
            case ']':
            case '^':
            case '_':
            case '`':
            default:
               return class_2583.field_24360;
            case 'a':
               return class_2583.field_24360.method_10977(class_124.field_1060);
            case 'b':
               return class_2583.field_24360.method_10977(class_124.field_1075);
            case 'c':
               return class_2583.field_24360.method_10977(class_124.field_1061);
            case 'd':
               return class_2583.field_24360.method_10977(class_124.field_1076);
            case 'e':
               return class_2583.field_24360.method_10977(class_124.field_1054);
            case 'f':
               return class_2583.field_24360.method_10977(class_124.field_1068);
         }
      }
   }

   public static String toLegacy(class_2561 text) {
      if (text == null) {
         return "";
      } else {
         StringBuilder sb = new StringBuilder();
         text.method_27658((style, string) -> {
            if (style.method_10973() != null) {
               for(class_124 f : class_124.values()) {
                  if (f.method_543() && f.method_532() != null && f.method_532().equals(style.method_10973().method_27716())) {
                     sb.append("§").append(f.method_36145());
                     break;
                  }
               }
            }

            if (style.method_10984()) {
               sb.append("§l");
            }

            if (style.method_10966()) {
               sb.append("§o");
            }

            if (style.method_10965()) {
               sb.append("§n");
            }

            if (style.method_10986()) {
               sb.append("§m");
            }

            if (style.method_10987()) {
               sb.append("§k");
            }

            sb.append(string);
            return Optional.empty();
         }, class_2583.field_24360);
         return sb.toString();
      }
   }
}
