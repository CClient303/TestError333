package pl.bkubiak.bkrynek.client.util;

import com.google.gson.Gson;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class DiscordWebhook {
   private static final Gson gson = new Gson();

   public static void send(String webhookUrl, Object bodyObject) {
      if (webhookUrl != null && !webhookUrl.isEmpty()) {
         CompletableFuture.runAsync(() -> {
            try {
               URL url = URI.create(webhookUrl).toURL();
               HttpURLConnection connection = (HttpURLConnection)url.openConnection();
               connection.setRequestMethod("POST");
               connection.setRequestProperty("Content-Type", "application/json");
               connection.setRequestProperty("User-Agent", "Mozilla/5.0");
               connection.setDoOutput(true);
               String json = gson.toJson(bodyObject);
               OutputStream os = connection.getOutputStream();

               try {
                  byte[] input = json.getBytes(StandardCharsets.UTF_8);
                  os.write(input, 0, input.length);
               } catch (Throwable var9) {
                  if (os != null) {
                     try {
                        os.close();
                     } catch (Throwable var8) {
                        var9.addSuppressed(var8);
                     }
                  }

                  throw var9;
               }

               if (os != null) {
                  os.close();
               }

               connection.getResponseCode();
               connection.disconnect();
            } catch (Exception e) {
               e.printStackTrace();
            }

         });
      }
   }

   public static void sendPurchaseNotification(String webhookUrl, String itemName, String price, String server, int amount, String enchants, String lore) {
      System.out.println("[BK-Rynek DEBUG] sendPurchaseNotification called for: " + itemName);
      CompletableFuture.runAsync(() -> {
         try {
            Thread.sleep(3000L);
         } catch (InterruptedException var13) {
         }

         String balance = ScoreboardUtils.getBalance();
         Map<String, Object> body = new HashMap();
         body.put("username", "BK-Rynek Notifications");
         body.put("avatar_url", "https://i.imgur.com/DLs7dkY.png");
         List<Map<String, Object>> embeds = new ArrayList();
         Map<String, Object> embed = new HashMap();
         embed.put("title", "\ud83d\uded2 Pomyślnie zakupiono przedmiot!");
         embed.put("color", 3066993);
         List<Map<String, Object>> fields = new ArrayList();
         fields.add(createField("Przedmiot", "`" + itemName + "`", true));
         fields.add(createField("Ilość", "`" + amount + " szt.`", true));
         fields.add(createField("Cena", "`" + price + "`", true));
         fields.add(createField("Stan konta", "`" + (balance != null ? balance : "---") + "`", true));
         if (enchants != null && !enchants.isEmpty()) {
            fields.add(createField("Enchanty", "```" + truncate(enchants, 900) + "```", false));
         }

         if (lore != null && !lore.isEmpty()) {
            fields.add(createField("Lore", "```" + truncate(lore, 900) + "```", false));
         }

         fields.add(createField("Serwer", "`" + server + "`", false));
         embed.put("fields", fields);
         Map<String, String> footer = new HashMap();
         footer.put("text", "BK-Rynek • bkubiak.dev/mods");
         embed.put("footer", footer);
         embed.put("description", "[Strona autora](https://bkubiak.dev/mods) • [Wesprzyj projekt (Tipply)](https://tipply.pl/@rajzeh)");
         embeds.add(embed);
         body.put("embeds", embeds);
         sendSync(webhookUrl, body);
      });
   }

   public static void sendErrorNotification(String webhookUrl, String reason, String server, String itemName, String price) {
      Map<String, Object> body = new HashMap();
      body.put("username", "BK-Rynek Notifications");
      body.put("avatar_url", "https://i.imgur.com/DLs7dkY.png");
      List<Map<String, Object>> embeds = new ArrayList();
      Map<String, Object> embed = new HashMap();
      embed.put("title", "⚠️ Błąd automatyzacji!");
      embed.put("color", 15158332);
      List<Map<String, Object>> fields = new ArrayList();
      fields.add(createField("Powód", "`" + reason + "`", true));
      if (itemName != null && !itemName.isEmpty()) {
         fields.add(createField("Przedmiot", "`" + itemName + "`", true));
      }

      if (price != null && !price.isEmpty()) {
         fields.add(createField("Cena", "`" + price + "`", true));
      }

      fields.add(createField("Serwer", "`" + server + "`", true));
      embed.put("fields", fields);
      Map<String, String> footer = new HashMap();
      footer.put("text", "BK-Rynek Mod • bkubiak.dev/mods");
      embed.put("footer", footer);
      embeds.add(embed);
      body.put("embeds", embeds);
      send(webhookUrl, body);
   }

   public static void sendSaleNotification(String webhookUrl, String earnings, String server) {
      CompletableFuture.runAsync(() -> {
         try {
            Thread.sleep(3000L);
         } catch (InterruptedException var9) {
         }

         String balance = ScoreboardUtils.getBalance();
         Map<String, Object> body = new HashMap();
         body.put("username", "BK-Rynek Notifications");
         body.put("avatar_url", "https://i.imgur.com/DLs7dkY.png");
         List<Map<String, Object>> embeds = new ArrayList();
         Map<String, Object> embed = new HashMap();
         embed.put("title", "\ud83d\udcb0 Przedmiot sprzedany!");
         embed.put("color", 15844367);
         List<Map<String, Object>> fields = new ArrayList();
         fields.add(createField("Zarobek", "`" + earnings + "`", true));
         fields.add(createField("Stan konta", "`" + (balance != null ? balance : "---") + "`", true));
         fields.add(createField("Serwer", "`" + server + "`", true));
         embed.put("fields", fields);
         Map<String, String> footer = new HashMap();
         footer.put("text", "BK-Rynek • bkubiak.dev/mods");
         embed.put("footer", footer);
         embed.put("description", "[Strona autora](https://bkubiak.dev/mods) • [Wesprzyj projekt (Tipply)](https://tipply.pl/@rajzeh)");
         embeds.add(embed);
         body.put("embeds", embeds);
         sendSync(webhookUrl, body);
      });
   }

   public static void sendListingNotification(String webhookUrl, String itemName, double price, String server, int amount) {
      CompletableFuture.runAsync(() -> {
         Map<String, Object> body = new HashMap();
         body.put("username", "BK-Rynek Notifications");
         body.put("avatar_url", "https://i.imgur.com/DLs7dkY.png");
         List<Map<String, Object>> embeds = new ArrayList();
         Map<String, Object> embed = new HashMap();
         embed.put("title", "\ud83d\udcdc Przedmiot wystawiony!");
         embed.put("color", 1629439);
         List<Map<String, Object>> fields = new ArrayList();
         fields.add(createField("Przedmiot", "`" + itemName + "`", true));
         fields.add(createField("Ilość", "`" + amount + " szt.`", true));
         fields.add(createField("Cena", "`" + (int)price + "$`", true));
         fields.add(createField("Serwer", "`" + server + "`", true));
         embed.put("fields", fields);
         Map<String, String> footer = new HashMap();
         footer.put("text", "BK-Rynek • bkubiak.dev/mods");
         embed.put("footer", footer);
         embed.put("description", "[Strona autora](https://bkubiak.dev/mods) • [Wesprzyj projekt (Tipply)](https://tipply.pl/@rajzeh)");
         embeds.add(embed);
         body.put("embeds", embeds);
         sendSync(webhookUrl, body);
      });
   }

   public static void sendFullInventoryNotification(String webhookUrl, String server) {
      CompletableFuture.runAsync(() -> {
         Map<String, Object> body = new HashMap();
         body.put("username", "BK-Rynek Notifications");
         body.put("avatar_url", "https://i.imgur.com/DLs7dkY.png");
         List<Map<String, Object>> embeds = new ArrayList();
         Map<String, Object> embed = new HashMap();
         embed.put("title", "⚠️ Ekwipunek pełny!");
         embed.put("color", 16711680);
         List<Map<String, Object>> fields = new ArrayList();
         fields.add(createField("Status", "Automatyzacja zatrzymana", false));
         fields.add(createField("Serwer", "`" + server + "`", false));
         embed.put("fields", fields);
         Map<String, String> footer = new HashMap();
         footer.put("text", "BK-Rynek Mod • bkubiak.dev/mods");
         embed.put("footer", footer);
         embeds.add(embed);
         body.put("embeds", embeds);
         sendSync(webhookUrl, body);
      });
   }

   private static void sendSync(String webhookUrl, Object bodyObject) {
      if (webhookUrl != null && !webhookUrl.isEmpty()) {
         try {
            URL url = URI.create(webhookUrl).toURL();
            HttpURLConnection connection = (HttpURLConnection)url.openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setRequestProperty("User-Agent", "Mozilla/5.0");
            connection.setDoOutput(true);
            String json = gson.toJson(bodyObject);
            OutputStream os = connection.getOutputStream();

            try {
               byte[] input = json.getBytes(StandardCharsets.UTF_8);
               os.write(input, 0, input.length);
            } catch (Throwable var9) {
               if (os != null) {
                  try {
                     os.close();
                  } catch (Throwable var8) {
                     var9.addSuppressed(var8);
                  }
               }

               throw var9;
            }

            if (os != null) {
               os.close();
            }

            int responseCode = connection.getResponseCode();
            System.out.println("[BK-Rynek DEBUG] sendSync Response: " + responseCode);
            connection.disconnect();
         } catch (Exception e) {
            System.err.println("[BK-Rynek DEBUG] sendSync Exception: " + e.getMessage());
            e.printStackTrace();
         }

      }
   }

   private static String truncate(String text, int maxLength) {
      if (text != null && text.length() > maxLength) {
         String var10000 = text.substring(0, maxLength);
         return var10000 + "...";
      } else {
         return text;
      }
   }

   private static Map<String, Object> createField(String name, String value, boolean inline) {
      Map<String, Object> field = new HashMap();
      field.put("name", name);
      field.put("value", value);
      field.put("inline", inline);
      return field;
   }
}
