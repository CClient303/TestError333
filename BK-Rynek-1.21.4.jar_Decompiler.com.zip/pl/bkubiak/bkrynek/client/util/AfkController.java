package pl.bkubiak.bkrynek.client.util;

import java.util.Random;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;
import net.minecraft.class_437;

@Environment(EnvType.CLIENT)
public class AfkController {
   private static boolean enabled = false;
   private static long nextJumpTime = 0L;
   private static int jumpTicksRemaining = 0;
   private static final Random random = new Random();
   private static boolean wasScreenOpen = false;
   private static long reopenTime = 0L;
   private static final long MIN_INTERVAL_MS = 120000L;
   private static final long MAX_INTERVAL_MS = 150000L;
   private static final int JUMP_DURATION_TICKS = 30;

   public static void enable() {
      enabled = true;
      scheduleNextJump();
   }

   public static void disable() {
      enabled = false;
      jumpTicksRemaining = 0;
      wasScreenOpen = false;
      reopenTime = 0L;
      class_310 client = class_310.method_1551();
      if (client != null && client.field_1690 != null) {
         client.field_1690.field_1903.method_23481(false);
      }

   }

   private static void scheduleNextJump() {
      long intervalMs = 120000L + random.nextLong(30000L);
      nextJumpTime = System.currentTimeMillis() + intervalMs;
   }

   public static void onTick(class_310 client) {
      if (enabled && client.field_1724 != null) {
         if (reopenTime > 0L) {
            if (System.currentTimeMillis() >= reopenTime) {
               if (client.method_1562() != null) {
                  client.method_1562().method_45730("ah");
               }

               reopenTime = 0L;
            }

         } else if (jumpTicksRemaining > 0) {
            client.field_1690.field_1903.method_23481(true);
            --jumpTicksRemaining;
            if (jumpTicksRemaining == 0) {
               client.field_1690.field_1903.method_23481(false);
               if (wasScreenOpen) {
                  reopenTime = System.currentTimeMillis() + 2000L;
                  wasScreenOpen = false;
               }
            }

         } else {
            if (System.currentTimeMillis() >= nextJumpTime) {
               if (client.field_1755 != null) {
                  wasScreenOpen = true;
                  client.method_1507((class_437)null);
               } else {
                  wasScreenOpen = false;
               }

               jumpTicksRemaining = 30;
               scheduleNextJump();
            }

         }
      }
   }

   public static boolean isEnabled() {
      return enabled;
   }
}
