package pl.bkubiak.bkrynek.client.util;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;
import net.minecraft.class_412;
import net.minecraft.class_419;
import net.minecraft.class_437;
import net.minecraft.class_639;
import net.minecraft.class_642;
import net.minecraft.class_9112;
import net.minecraft.class_642.class_8678;
import pl.bkubiak.bkrynek.client.BkRynekClient;
import pl.bkubiak.bkrynek.core.config.ServerEntry;

@Environment(EnvType.CLIENT)
public final class ReconnectController {
   private static String lastServerAddress;
   private static class_642 lastServerInfo;
   private static long reconnectAt = 0L;
   private static boolean pending = false;
   private static boolean isReconnecting = false;
   private static class_437 lastDisconnectScreen = null;
   private static final int DEFAULT_DELAY_SECONDS = 8;
   private static boolean cancelled = false;

   private ReconnectController() {
   }

   public static boolean isReconnecting() {
      return isReconnecting;
   }

   public static void setReconnecting(boolean val) {
      isReconnecting = val;
   }

   public static void globalTick() {
      class_310 client = class_310.method_1551();
      if (client != null) {
         class_642 currentEntry = client.method_1558();
         if (currentEntry != null && currentEntry.field_3761 != null && !currentEntry.field_3761.isEmpty()) {
            lastServerInfo = currentEntry;
            lastServerAddress = currentEntry.field_3761;
         }

         class_437 currentScreen = client.field_1755;
         if (currentScreen instanceof class_419) {
            onDisconnectScreenInit(currentScreen);
         } else {
            lastDisconnectScreen = null;
         }

         if (pending && currentScreen instanceof class_419 && !cancelled && System.currentTimeMillis() >= reconnectAt) {
            reconnect();
         }

      }
   }

   public static void onDisconnectScreenInit(class_437 screen) {
      if (screen != lastDisconnectScreen) {
         lastDisconnectScreen = screen;
         startCountdown();
      }

   }

   public static void setLastServer(class_642 info) {
      if (info != null) {
         lastServerInfo = info;
         lastServerAddress = info.field_3761;
      }

   }

   private static void startCountdown() {
      if (lastServerAddress != null || lastServerInfo != null) {
         cancelled = false;
         int delaySec = 8;

         try {
            String addr = lastServerAddress;
            if (addr != null) {
               ServerEntry entry = BkRynekClient.findServerEntry(addr);
               if (entry != null) {
                  if (Boolean.FALSE.equals(entry.autoReconnect)) {
                     return;
                  }

                  if (entry.reconnectDelayMs != null && entry.reconnectDelayMs > 0) {
                     delaySec = Math.max(8, entry.reconnectDelayMs);
                  }
               }
            }
         } catch (Exception var3) {
         }

         reconnectAt = System.currentTimeMillis() + (long)delaySec * 1000L;
         pending = true;
      }
   }

   public static boolean isPending() {
      return pending;
   }

   public static boolean isCancelled() {
      return cancelled;
   }

   public static int getSecondsUntilReconnect() {
      return (int)Math.max(0L, (reconnectAt - System.currentTimeMillis()) / 1000L);
   }

   public static void reconnect() {
      pending = false;
      cancelled = false;
      isReconnecting = true;
      class_310 client = class_310.method_1551();
      if (lastServerInfo != null) {
         String addrStr = lastServerAddress != null ? lastServerAddress : lastServerInfo.field_3761;
         class_412.method_36877(client.field_1755, client, class_639.method_2950(addrStr), lastServerInfo, false, (class_9112)null);
      } else if (lastServerAddress != null) {
         class_642 info = new class_642("Auto-Reconnect", lastServerAddress, class_8678.field_45611);
         class_412.method_36877(client.field_1755, client, class_639.method_2950(lastServerAddress), info, false, (class_9112)null);
      }

   }

   public static void cancel() {
      pending = false;
      cancelled = true;
   }
}
