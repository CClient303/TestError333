package pl.bkubiak.bkrynek.client.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_266;
import net.minecraft.class_268;
import net.minecraft.class_269;
import net.minecraft.class_310;
import net.minecraft.class_8646;
import net.minecraft.class_9011;
import pl.bkubiak.bkrynek.core.util.ColorStripUtils;

@Environment(EnvType.CLIENT)
public class ScoreboardUtils {
   public static String getBalance() {
      try {
         class_310 client = class_310.method_1551();
         if (client.field_1687 == null || client.field_1724 == null) {
            return "---";
         }

         class_269 scoreboard = client.field_1687.method_8428();
         class_266 sidebarObj = scoreboard.method_1189(class_8646.field_45157);
         if (sidebarObj != null) {
            String result = extractFromObjective(scoreboard, sidebarObj);
            if (!result.equals("---")) {
               return result;
            }
         }

         for(class_266 obj : scoreboard.method_1151()) {
            if (obj != sidebarObj) {
               String result = extractFromObjective(scoreboard, obj);
               if (!result.equals("---")) {
                  return result;
               }
            }
         }
      } catch (Exception var6) {
      }

      return "---";
   }

   private static String extractFromObjective(class_269 scoreboard, class_266 objective) {
      for(class_9011 entry : scoreboard.method_1184(objective)) {
         String owner = entry.comp_2127();
         StringBuilder fullLine = new StringBuilder();
         class_268 team = scoreboard.method_1164(owner);
         if (team != null) {
            fullLine.append(team.method_1144().getString());
            fullLine.append(owner);
            fullLine.append(team.method_1136().getString());
         } else {
            fullLine.append(owner);
         }

         if (entry.comp_2129() != null) {
            fullLine.append(" ").append(entry.comp_2129().getString());
         }

         String clean = ColorStripUtils.stripAllColorsAndFormats(fullLine.toString());
         String lower = clean.toLowerCase();
         if (lower.contains("pieniądze") || lower.contains("pieniadze") || lower.contains("balance") || lower.contains("stan konta") || lower.contains("$")) {
            String filtered = clean.replaceAll("(?i)[^0-9.,kKmM$złLNP]", "").trim();
            Pattern p = Pattern.compile("([0-9.,]+)\\s?([$]|zł|PLN|k|m)?", 2);
            Matcher m = p.matcher(filtered);
            String bestMatch = null;

            while(m.find()) {
               String candidate = m.group(0).trim();
               if (candidate.matches(".*[0-9].*")) {
                  bestMatch = candidate;
               }
            }

            if (bestMatch != null) {
               if (!bestMatch.contains("$") && !bestMatch.contains("zł") && !bestMatch.contains("PLN")) {
                  bestMatch = bestMatch + "$";
               }

               return bestMatch;
            }
         }
      }

      return "---";
   }
}
