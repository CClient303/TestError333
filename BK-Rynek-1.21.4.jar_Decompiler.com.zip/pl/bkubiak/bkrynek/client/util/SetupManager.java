package pl.bkubiak.bkrynek.client.util;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1735;
import net.minecraft.class_310;
import pl.bkubiak.bkrynek.client.BkRynekClient;
import pl.bkubiak.bkrynek.client.command.ClientCommandRegistration;
import pl.bkubiak.bkrynek.core.config.ServerEntry;
import pl.bkubiak.bkrynek.core.util.Messages;

@Environment(EnvType.CLIENT)
public class SetupManager {
   private static SetupState currentState;

   public static void startSetup() {
      currentState = SetupManager.SetupState.SETTING_REFRESH;
   }

   public static boolean isActive() {
      return currentState != SetupManager.SetupState.INACTIVE;
   }

   public static String getSetupInstruction() {
      switch (currentState.ordinal()) {
         case 1 -> {
            return Messages.get("setup.step1");
         }
         case 2 -> {
            return Messages.get("setup.step2");
         }
         case 3 -> {
            return Messages.get("setup.step3");
         }
         default -> {
            return "";
         }
      }
   }

   public static void handleSlotSelect(class_1735 slot) {
      if (isActive()) {
         String address = BkRynekClient.getServerAddress();
         ServerEntry entry = BkRynekClient.findServerEntry(address);
         if (entry == null) {
            sendFeedback(Messages.get("setup.error.no_config"));
            currentState = SetupManager.SetupState.INACTIVE;
         } else {
            int slotId = slot.field_7874;
            switch (currentState.ordinal()) {
               case 1:
                  entry.refreshSlot = slotId;
                  sendFeedback(Messages.get("setup.ok.refresh", "slot", String.valueOf(slotId)));
                  currentState = SetupManager.SetupState.SETTING_CONFIRM;
                  break;
               case 2:
                  entry.confirmSlot = slotId;
                  sendFeedback(Messages.get("setup.ok.confirm", "slot", String.valueOf(slotId)));
                  currentState = SetupManager.SetupState.SETTING_NEXT_PAGE;
                  break;
               case 3:
                  entry.marketNextPageSlot = slotId;
                  sendFeedback(Messages.get("setup.ok.next_page", "slot", String.valueOf(slotId)));
                  sendFeedback(Messages.get("setup.complete"));
                  currentState = SetupManager.SetupState.INACTIVE;
                  ClientCommandRegistration.syncMemoryToConfig();
            }

         }
      }
   }

   public static void showInfo() {
      String address = BkRynekClient.getServerAddress();
      ServerEntry entry = BkRynekClient.findServerEntry(address);
      if (entry == null) {
         sendFeedback(Messages.get("setup.error.no_config"));
      } else {
         String notSet = Messages.get("setup.info.not_set");
         sendFeedback(Messages.get("setup.info.title", "address", address));
         sendFeedback(Messages.get("setup.info.refresh", "value", entry.refreshSlot != null ? String.valueOf(entry.refreshSlot) : notSet));
         sendFeedback(Messages.get("setup.info.confirm", "value", entry.confirmSlot != null ? String.valueOf(entry.confirmSlot) : notSet));
         sendFeedback(Messages.get("setup.info.next", "value", entry.marketNextPageSlot != null ? String.valueOf(entry.marketNextPageSlot) : notSet));
      }
   }

   private static void sendFeedback(String message) {
      class_310 client = class_310.method_1551();
      if (client.field_1724 != null) {
         String prefix = Messages.get("setup.prefix");
         client.field_1724.method_7353(ColorUtils.translateColorCodes(prefix + message), false);
      }

   }

   public static void stopSetup() {
      if (isActive()) {
         currentState = SetupManager.SetupState.INACTIVE;
         sendFeedback(Messages.get("setup.cancelled"));
      }

   }

   static {
      currentState = SetupManager.SetupState.INACTIVE;
   }

   @Environment(EnvType.CLIENT)
   public static enum SetupState {
      INACTIVE,
      SETTING_REFRESH,
      SETTING_CONFIRM,
      SETTING_NEXT_PAGE;

      // $FF: synthetic method
      private static SetupState[] $values() {
         return new SetupState[]{INACTIVE, SETTING_REFRESH, SETTING_CONFIRM, SETTING_NEXT_PAGE};
      }
   }
}
