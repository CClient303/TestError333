package pl.bkubiak.bkrynek.client.util;

import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import pl.bkubiak.bkrynek.client.BkRynekClient;

@Environment(EnvType.CLIENT)
public final class LobbyAutomationController {
   private static boolean guiScanPending = false;
   private static long lastActionMs = 0L;
   private static boolean lobbyDetectionEnabled = true;
   private static boolean flowRunning = false;
   public static boolean isAutoReconnectedContext = false;
   private static MoveState currentState;
   private static int stateTicks;
   private static float initialYaw;
   private static float initialPitch;

   private LobbyAutomationController() {
   }

   public static void startLobbyFlow() {
      if (!flowRunning) {
         if (lobbyDetectionEnabled) {
            ToastManager.show("Rozpoczynanie lobby flow...", 11184895);
            flowRunning = true;
            currentState = LobbyAutomationController.MoveState.START_WAIT;
            stateTicks = 20;
         }
      }
   }

   public static void stopAll() {
      flowRunning = false;
      currentState = LobbyAutomationController.MoveState.IDLE;
      stateTicks = 0;
      guiScanPending = false;
      class_310 client = class_310.method_1551();
      if (client != null && client.field_1690 != null) {
         client.field_1690.field_1894.method_23481(false);
      }

   }

   public static void onTick() {
      if (flowRunning) {
         class_310 client = class_310.method_1551();
         if (client.field_1724 != null && client.field_1755 == null) {
            if (stateTicks > 0) {
               --stateTicks;
               if (currentState != LobbyAutomationController.MoveState.WALK_SHORT && currentState != LobbyAutomationController.MoveState.WALK_LONG) {
                  client.field_1690.field_1894.method_23481(false);
               } else {
                  client.field_1690.field_1894.method_23481(true);
                  if (currentState == LobbyAutomationController.MoveState.WALK_LONG) {
                     float yawOffset = (float)Math.sin((double)stateTicks * 0.2) * 10.0F;
                     float pitchOffset = (float)Math.cos((double)stateTicks * 0.1) * 5.0F;
                     client.field_1724.method_36456(initialYaw + yawOffset);
                     client.field_1724.method_36457(initialPitch + pitchOffset);
                  }
               }

               if (stateTicks == 0) {
                  switch (currentState.ordinal()) {
                     case 1:
                        currentState = LobbyAutomationController.MoveState.WALK_SHORT;
                        stateTicks = 20;
                        break;
                     case 2:
                        currentState = LobbyAutomationController.MoveState.STOP_WAIT;
                        stateTicks = 20;
                        break;
                     case 3:
                        if (client.field_1724 != null) {
                           initialYaw = client.field_1724.method_36454();
                           initialPitch = client.field_1724.method_36455();
                        }

                        currentState = LobbyAutomationController.MoveState.WALK_LONG;
                        stateTicks = 80;
                        break;
                     case 4:
                        client.field_1690.field_1894.method_23481(false);
                        if (client.field_1724 != null) {
                           client.field_1724.method_36456(initialYaw);
                           client.field_1724.method_36457(initialPitch);
                        }

                        currentState = LobbyAutomationController.MoveState.IDLE;
                        break;
                     case 5:
                        if (client.field_1724 != null && client.field_1761 != null) {
                           client.field_1761.method_2919(client.field_1724, class_1268.field_5808);
                           client.field_1724.method_6104(class_1268.field_5808);
                        }

                        guiScanPending = true;
                        lastActionMs = System.currentTimeMillis();
                        currentState = LobbyAutomationController.MoveState.IDLE;
                  }
               }
            }

         }
      }
   }

   public static void onChatMessage(class_2561 message, boolean overlay) {
      String text = message.getString().toLowerCase();
      if (!overlay || !text.contains("weryfikacja pozycji") && !text.contains("zacznij") && !text.contains("porusza")) {
         if (lobbyDetectionEnabled && flowRunning) {
            if (text.contains("trwa przenoszenie")) {
               stopAll();
            } else {
               if (text.contains("wyboru trybu") || text.contains("wybierz tryb") || text.contains("wybierz serwer") || text.contains("zapraszam do wyboru") || text.contains("zweryfikowano czynnik zaufania")) {
                  useCompass();
               }

            }
         }
      } else if (isAutoReconnectedContext) {
         startLobbyFlow();
      }
   }

   private static void useCompass() {
      class_310 client = class_310.method_1551();
      if (client.field_1724 != null) {
         currentState = LobbyAutomationController.MoveState.IDLE;
         stateTicks = 0;
         if (client.field_1690 != null) {
            client.field_1690.field_1894.method_23481(false);
         }

         client.execute(() -> {
            int compassSlot = -1;

            for(int i = 0; i < 9; ++i) {
               if (client.field_1724.method_31548().method_5438(i).method_31574(class_1802.field_8251)) {
                  compassSlot = i;
                  break;
               }
            }

            if (compassSlot != -1) {
               client.field_1724.method_31548().field_7545 = compassSlot;
               currentState = LobbyAutomationController.MoveState.CLICK_COMPASS;
               stateTicks = 10;
               flowRunning = true;
            }

         });
      }
   }

   public static void onScreenRender(class_2561 title, class_1703 handler, List<class_1735> slots) {
      if (flowRunning && guiScanPending && System.currentTimeMillis() - lastActionMs >= 200L) {
         for(class_1735 slot : slots) {
            if (slot.field_7874 <= 53 && slot.method_7681()) {
               class_1799 stack = slot.method_7677();
               if (stack.method_31574(class_1802.field_8264) || stack.method_7964().getString().toLowerCase().contains("anarchia")) {
                  class_310 client = class_310.method_1551();
                  client.field_1761.method_2906(handler.field_7763, slot.field_7874, 0, class_1713.field_7790, client.field_1724);
                  guiScanPending = false;
                  flowRunning = false;
                  ToastManager.show("Lobby flow zakończone.", 5635925);
                  (new Thread(() -> {
                     try {
                        Thread.sleep(8000L);
                        client.execute(() -> {
                           if (client.field_1724 != null) {
                              BkRynekClient.isSniperMode = true;
                              SearchAutomationController.start(-1);
                              client.field_1724.field_3944.method_45730("ah");
                           }

                        });
                     } catch (InterruptedException var2) {
                     }

                  })).start();
                  break;
               }
            }
         }

      }
   }

   public static void setEnabled(boolean enabled) {
      lobbyDetectionEnabled = enabled;
   }

   public static boolean shouldForceForward() {
      return flowRunning && (currentState == LobbyAutomationController.MoveState.WALK_SHORT || currentState == LobbyAutomationController.MoveState.WALK_LONG) && stateTicks > 0;
   }

   static {
      currentState = LobbyAutomationController.MoveState.IDLE;
      stateTicks = 0;
      initialYaw = 0.0F;
      initialPitch = 0.0F;
   }

   @Environment(EnvType.CLIENT)
   private static enum MoveState {
      IDLE,
      START_WAIT,
      WALK_SHORT,
      STOP_WAIT,
      WALK_LONG,
      CLICK_COMPASS;

      // $FF: synthetic method
      private static MoveState[] $values() {
         return new MoveState[]{IDLE, START_WAIT, WALK_SHORT, STOP_WAIT, WALK_LONG, CLICK_COMPASS};
      }
   }
}
