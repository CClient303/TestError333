package pl.bkubiak.bkrynek.client.util;

import java.util.ArrayList;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_5481;
import pl.bkubiak.bkrynek.client.gui.widgets.Panel;

@Environment(EnvType.CLIENT)
public class ToastManager {
   private static final List<ToastInstance> toasts = new ArrayList();
   private static final int TOAST_WIDTH = 240;
   private static final int TOAST_PADDING = 12;
   private static final int ICON_SIZE = 16;

   public static void show(String message, int color) {
      show(ColorUtils.translateColorCodes(message), color);
   }

   public static void show(class_2561 text, int color) {
      toasts.removeIf(ToastInstance::isExpired);
      if (toasts.size() >= 5) {
         toasts.remove(0);
      }

      toasts.add(new ToastInstance(text, color));
   }

   public static void render(class_332 context) {
      if (!toasts.isEmpty()) {
         class_310 client = class_310.method_1551();
         class_327 textRenderer = client.field_1772;
         int screenWidth = client.method_22683().method_4486();
         int screenHeight = client.method_22683().method_4502();
         toasts.removeIf(ToastInstance::isExpired);
         int currentY = screenHeight - 30;

         for(int i = toasts.size() - 1; i >= 0; --i) {
            ToastInstance toast = (ToastInstance)toasts.get(i);
            toast.prepare(textRenderer, 192);
            int height = toast.getHeight();
            currentY -= height + 8;
            int x = screenWidth - 240 - 20;
            toast.render(context, textRenderer, x, currentY);
         }

      }
   }

   @Environment(EnvType.CLIENT)
   private static class ToastInstance {
      private final class_2561 text;
      private final int accentColor;
      private final long startTime;
      private final long duration = 4500L;
      private List<class_5481> wrappedLines;
      private int height;
      private float slideAnimation = 0.0F;

      public ToastInstance(class_2561 text, int color) {
         this.text = text;
         this.accentColor = color;
         this.startTime = System.currentTimeMillis();
      }

      public boolean isExpired() {
         return System.currentTimeMillis() - this.startTime > 4500L;
      }

      public void prepare(class_327 renderer, int maxWidth) {
         if (this.wrappedLines == null) {
            this.wrappedLines = renderer.method_1728(this.text, maxWidth);
            this.height = Math.max(40, 24 + this.wrappedLines.size() * 10 + 4);
         }

      }

      public int getHeight() {
         return this.height;
      }

      public void render(class_332 context, class_327 renderer, int x, int y) {
         long age = System.currentTimeMillis() - this.startTime;
         float alpha = 1.0F;
         if (age < 300L) {
            alpha = (float)age / 300.0F;
            this.slideAnimation = class_3532.method_15363((float)age / 200.0F, 0.0F, 1.0F);
         } else if (age > 3900L) {
            alpha = 1.0F - (float)(age - 3900L) / 600.0F;
         }

         alpha = Math.max(0.0F, Math.min(1.0F, alpha));
         int slideOffset = (int)((1.0F - this.slideAnimation) * 30.0F);
         int finalX = x + slideOffset;
         int a = (int)(alpha * 255.0F);
         int bgColor = a << 24 | 986895;
         int borderColor = a << 24 | this.accentColor & 16777215;
         int glowColor = a / 3 << 24 | this.accentColor & 16777215;
         int textColor = a << 24 | 16777215;
         Panel.drawRoundedRect(context, finalX - 1, y - 1, 242, this.height + 2, 8, glowColor);
         Panel.drawRoundedRect(context, finalX, y, 240, this.height, 7, bgColor);
         context.method_25294(finalX + 1, y + 7, finalX + 3, y + this.height - 7, borderColor);
         Panel.drawRoundedRectOutline(context, finalX, y, 240, this.height, 7, a / 2 << 24 | 2236962);
         int iconX = finalX + 12;
         int iconY = y + (this.height - 16) / 2;
         Panel.drawRoundedRect(context, iconX - 2, iconY - 2, 20, 20, 3, a / 4 << 24 | this.accentColor & 16777215);
         this.drawIcon(context, iconX, iconY, 16, borderColor, this.accentColor);
         int textX = finalX + 12 + 16 + 12;
         int textY = y + (this.height - this.wrappedLines.size() * 10) / 2;

         for(int i = 0; i < this.wrappedLines.size(); ++i) {
            context.method_51430(renderer, (class_5481)this.wrappedLines.get(i), textX, textY + i * 10, textColor, true);
         }

      }

      private void drawIcon(class_332 context, int x, int y, int size, int color1, int color2) {
         int rgb = this.accentColor & 16777215;
         if (rgb != 4521796 && rgb != 56661) {
            if (rgb == 16729156) {
               this.drawX(context, x, y, size, color1);
            } else if (rgb != 16777045 && rgb != 16763904 && rgb != 16755200) {
               this.drawInfoCircle(context, x, y, size, color1);
            } else {
               this.drawExclamation(context, x, y, size, color1);
            }
         } else {
            this.drawCheckmark(context, x, y, size, color1);
         }

      }

      private void drawCheckmark(class_332 ctx, int x, int y, int size, int color) {
         int cx = x + size / 2;
         int cy = y + size / 2;
         ctx.method_25294(cx - 2, cy, cx, cy + 4, color);
         ctx.method_25294(cx, cy + 2, cx + 4, cy - 2, color);
      }

      private void drawX(class_332 ctx, int x, int y, int size, int color) {
         int cx = x + size / 2;
         int cy = y + size / 2;
         ctx.method_25294(cx - 4, cy - 1, cx + 4, cy + 1, color);
         ctx.method_25294(cx - 1, cy - 4, cx + 1, cy + 4, color);
         ctx.method_25294(cx - 3, cy - 3, cx - 1, cy - 1, color);
         ctx.method_25294(cx + 1, cy - 3, cx + 3, cy - 1, color);
         ctx.method_25294(cx - 3, cy + 1, cx - 1, cy + 3, color);
         ctx.method_25294(cx + 1, cy + 1, cx + 3, cy + 3, color);
      }

      private void drawExclamation(class_332 ctx, int x, int y, int size, int color) {
         int cx = x + size / 2;
         int cy = y + size / 2;
         ctx.method_25294(cx - 1, cy - 5, cx + 1, cy + 1, color);
         ctx.method_25294(cx - 1, cy + 3, cx + 1, cy + 5, color);
      }

      private void drawInfoCircle(class_332 ctx, int x, int y, int size, int color) {
         int cx = x + size / 2;
         int cy = y + size / 2;
         ctx.method_25294(cx - 1, cy - 5, cx + 1, cy - 3, color);
         ctx.method_25294(cx - 1, cy - 1, cx + 1, cy + 5, color);
      }
   }
}
