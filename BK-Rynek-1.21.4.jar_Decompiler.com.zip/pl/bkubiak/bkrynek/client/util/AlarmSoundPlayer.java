package pl.bkubiak.bkrynek.client.util;

import java.util.Timer;
import java.util.TimerTask;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1109;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3414;
import net.minecraft.class_7923;
import pl.bkubiak.bkrynek.core.config.ServerEntry;
import pl.bkubiak.bkrynek.core.config.ServersConfig;

@Environment(EnvType.CLIENT)
public final class AlarmSoundPlayer {
   private AlarmSoundPlayer() {
   }

   public static void playForMatchCount(ServersConfig config, String activeProfile, int matchedCount) {
      if (config != null && config.servers != null) {
         String miniSound = "";
         String stackSound = "";

         for(ServerEntry entry : config.servers) {
            if (entry.profileName.equals(activeProfile)) {
               if (entry.miniAlarmSound != null) {
                  miniSound = entry.miniAlarmSound;
               }

               if (entry.miniAlarmSoundStack != null) {
                  stackSound = entry.miniAlarmSoundStack;
               }
               break;
            }
         }

         if (matchedCount <= 9) {
            playSoundNTimes(miniSound, matchedCount);
         } else {
            playSoundNTimes(stackSound, 1);
         }

      }
   }

   private static void playSoundNTimes(String soundId, int times) {
      if (!soundId.isEmpty() && times > 0) {
         class_2960 id = class_2960.method_12829(soundId);
         if (id != null) {
            final class_3414 soundEvent = (class_3414)class_7923.field_41172.method_63535(id);
            if (soundEvent != null) {
               final Timer timer = new Timer();
               long initialDelay = 300L;
               long interval = 150L;

               for(int i = 0; i < times; ++i) {
                  long delay = initialDelay + (long)i * interval;
                  timer.schedule(new TimerTask() {
                     public void run() {
                        class_310.method_1551().execute(() -> class_310.method_1551().method_1483().method_4873(class_1109.method_4757(soundEvent, 1.0F, 1.0F)));
                     }
                  }, delay);
               }

               timer.schedule(new TimerTask() {
                  public void run() {
                     timer.cancel();
                  }
               }, initialDelay + (long)times * interval + 50L);
            }
         }
      }
   }
}
