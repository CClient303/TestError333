package pl.bkubiak.bkrynek.client.util;

import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1887;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_2813;
import net.minecraft.class_2815;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_6880;
import net.minecraft.class_746;
import net.minecraft.class_7923;
import net.minecraft.class_9280;
import net.minecraft.class_9290;
import net.minecraft.class_9304;
import net.minecraft.class_9334;
import net.minecraft.class_1792.class_9635;
import pl.bkubiak.bkrynek.client.BkRynekClient;
import pl.bkubiak.bkrynek.client.keybinding.ToggleScanner;
import pl.bkubiak.bkrynek.client.mixin.ScreenHandlerAccessor;
import pl.bkubiak.bkrynek.core.config.PriceEntry;
import pl.bkubiak.bkrynek.core.config.ServerEntry;
import pl.bkubiak.bkrynek.core.manager.ClientPriceListManager;
import pl.bkubiak.bkrynek.core.scan.ScanEvaluator;
import pl.bkubiak.bkrynek.core.scan.ScanInput;
import pl.bkubiak.bkrynek.core.scan.ScanResult;
import pl.bkubiak.bkrynek.core.util.ColorStripUtils;
import pl.bkubiak.bkrynek.core.util.EnchantMapper;
import pl.bkubiak.bkrynek.core.util.Messages;
import pl.bkubiak.bkrynek.core.util.PriceFormatter;

@Environment(EnvType.CLIENT)
public final class SearchAutomationController {
   private static final State state = new State();
   private static final Map<String, Pattern> patternCache = new ConcurrentHashMap();
   private static final ScheduledExecutorService SCHEDULER = Executors.newScheduledThreadPool(2);
   private static ScheduledFuture<?> SCAN_FUTURE = null;
   private static final long AUTO_SELL_PAUSE_INTERVAL_MS = 10000L;

   private static Pattern getPattern(String regex) {
      return (Pattern)patternCache.computeIfAbsent(regex, (r) -> Pattern.compile(r, 2));
   }

   private SearchAutomationController() {
   }

   public static void start(int pages) {
      reset();
      state.active = true;
      state.sessionStartTime = System.currentTimeMillis();
      state.initialBalance = parseBalance(ScoreboardUtils.getBalance());
      ToggleScanner.scanningEnabled = true;
      String mode = BkRynekClient.isSniperMode ? "SNIPER" : "SCAN";
      sendFeedback(Messages.format("automation.start", Map.of("mode", mode)));
      sendFeedback(Messages.get("automation.start_hint"));
   }

   public static void cancel() {
      if (state.active) {
         state.active = false;
      }

      reset();
   }

   public static boolean isActive() {
      return state.active;
   }

   public static boolean isInsideConfirmScreen() {
      return state.isInsideConfirmScreen;
   }

   public static void onScreenRender(class_2561 title, class_1703 handler, List<class_1735> slots) {
      if (state.active) {
         long now = System.currentTimeMillis();
         if (state.active && (state.initialBalance <= (double)0.0F || state.initialBalance == (double)-1.0F) && now - state.sessionStartTime < 5000L) {
            double b = parseBalance(ScoreboardUtils.getBalance());
            if (b > (double)0.0F) {
               state.initialBalance = b;
               System.out.println("[BK-Rynek] Initial balance recovered: " + b);
            }
         }

         ServerEntry entry = findEntry();
         if (entry != null) {
            String address = BkRynekClient.getServerAddress().toLowerCase();
            if ((address.contains("anarchia.gg") || address.contains("anarchia.pl")) && entry.sortingSlot == null) {
               entry.sortingSlot = 53;
            }

            now = System.currentTimeMillis();
            String currentTitle = title.getString().toLowerCase();
            int syncId = handler.field_7763;
            boolean titleIsMarket = currentTitle.contains("rynek") || currentTitle.contains("aukcj") || currentTitle.contains("ah") || currentTitle.contains("market") || currentTitle.contains("auction") || currentTitle.contains("itemy") || currentTitle.contains("aukcje") || currentTitle.contains("aukcja") || entry.marketGuiTitle != null && currentTitle.contains(entry.marketGuiTitle.toLowerCase());
            if (state.lastSyncId != (long)syncId) {
               state.screenFirstSeenTime = now;
               state.lastSyncId = (long)syncId;
               state.stuckInConfirmStartTime = 0L;
               if (titleIsMarket) {
                  startThreadedScanner(handler);
               } else {
                  stopThreadedScanner();
               }

               state.currentBalance = parseBalance(ScoreboardUtils.getBalance());
            }

            boolean confirmKeywordsInTitle = currentTitle.contains("potwierdz") || currentTitle.contains("potwierdź") || currentTitle.contains("confirm") || currentTitle.contains("na pewno") || currentTitle.contains("sure") || currentTitle.contains("zakup") && !titleIsMarket;
            if (titleIsMarket && !state.marketDetectedLogged) {
               sendFeedback("&7Detected Market: &f" + entry.profileName, 16763904);
               state.marketDetectedLogged = true;
            }

            if (state.active && !state.buyingItem) {
               int emptySlots = 0;
               class_1661 inv = class_310.method_1551().field_1724.method_31548();

               for(int i = 0; i < 36; ++i) {
                  if (inv.method_5438(i).method_7960()) {
                     ++emptySlots;
                  }
               }

               if (emptySlots < 1) {
                  sendFeedback("&cEQUIPMENT FULL! Automatic stop.", 16711680);
                  state.active = false;
                  String webhook = BkRynekClient.serversConfig.discordWebhookUrl;
                  if (webhook != null && !webhook.isEmpty()) {
                     DiscordWebhook.sendFullInventoryNotification(webhook, BkRynekClient.getServerAddress());
                  }

                  return;
               }
            }

            if (Boolean.TRUE.equals(entry.aggressiveAnarchiaMode) && (entry.marketActionDelayMs == null || entry.marketActionDelayMs > 50)) {
               entry.marketActionDelayMs = 50;
            }

            if (entry.profileName.equals("anarchia_smp") && titleIsMarket && !state.buyingItem && !state.isRestarting && !state.purchasePending) {
               String keyword = "nowsze";
               class_1735 sortSlot = findSlot(slots, 53);
               if (sortSlot != null && sortSlot.method_7681()) {
                  boolean isSorted = isNajnowszeSelected(sortSlot.method_7677(), keyword);
                  if (!isSorted && now < state.sortingPauseUntil) {
                     isSorted = true;
                  }

                  if (!isSorted) {
                     state.sortingConfirmed = false;
                     int sortDelay = Boolean.TRUE.equals(entry.aggressiveAnarchiaMode) ? 100 : 800;
                     if (now - state.lastClickMs > (long)sortDelay) {
                        class_310 client = class_310.method_1551();
                        client.execute(() -> {
                           if (state.active && client.field_1724 != null && client.field_1724.field_7512 != null && client.field_1724.field_7512.field_7763 == syncId) {
                              clickSlot(client.field_1724.field_7512, 53, 1);
                           }

                        });
                        state.lastClickMs = now;
                        sendFeedback("&eChanging sorting to: Latest", 16763904);
                     }

                     return;
                  }

                  if (!state.sortingConfirmed) {
                     state.sortingConfirmed = true;
                     sendFeedback("&aSorting set: Latest", 5635925);
                  }
               }

               int refreshDelay = entry.marketNextDelayMs != null && entry.marketNextDelayMs > 0 ? entry.marketNextDelayMs : (Boolean.TRUE.equals(entry.aggressiveAnarchiaMode) ? 50 : 100);
               if (state.sortingConfirmed && now - state.lastActionMs > (long)refreshDelay) {
                  if (now < state.refreshBlockedUntil) {
                     return;
                  }

                  if (checkForMatchesAndLock(slots, handler)) {
                     return;
                  }

                  if (!state.purchasePending && !state.buyingItem) {
                     clickSlot(handler, 0, 1);
                     state.lastActionMs = now;
                  }

                  return;
               }
            }

            int marketItemCount = 0;
            boolean confirmButtonsFound = false;

            for(int i = 0; i < Math.min(slots.size(), 54); ++i) {
               class_1735 s = (class_1735)slots.get(i);
               if (s != null && s.method_7681()) {
                  class_1799 stack = s.method_7677();
                  String name = stack.method_7964().getString().toLowerCase();
                  boolean needsSellerCheck = marketItemCount < 5;
                  boolean needsConfirmCheck = !confirmButtonsFound;
                  if (!needsSellerCheck && !needsConfirmCheck) {
                     break;
                  }

                  List<class_2561> tooltip = stack.method_7950(class_9635.field_51353, (class_1657)null, class_1836.field_41070);
                  StringBuilder loreBuilder = new StringBuilder();

                  for(class_2561 line : tooltip) {
                     loreBuilder.append(line.getString().toLowerCase()).append(" ");
                  }

                  String lore = loreBuilder.toString();
                  boolean hasSellerLore = false;
                  if (needsSellerCheck) {
                     hasSellerLore = entry.loreSellerRegex != null && !entry.loreSellerRegex.isEmpty() ? getPattern(entry.loreSellerRegex).matcher(lore).find() : lore.contains("wystawi") || lore.contains("seller");
                     if (hasSellerLore) {
                        ++marketItemCount;
                     }
                  }

                  if (needsConfirmCheck) {
                     boolean isConfirmItem = entry.confirmItemName != null && !entry.confirmItemName.isEmpty() ? name.contains(entry.confirmItemName.toLowerCase()) : name.contains("potwierdz") || name.contains("potwierdź") || name.contains("confirm") || name.contains("zakup produkt");
                     if (!hasSellerLore && (isConfirmItem || name.contains("anuluj") || name.contains("cancel"))) {
                        confirmButtonsFound = true;
                     }
                  }
               }
            }

            boolean confirmKeywords = confirmKeywordsInTitle || confirmButtonsFound || currentTitle.contains("zakup") && marketItemCount <= 1;
            boolean isMarket = marketItemCount > 1 || titleIsMarket && !confirmKeywords;
            if (state.marketContinuousOpenTime > 0L && titleIsMarket && !confirmKeywords) {
               isMarket = true;
            }

            state.isInsideConfirmScreen = confirmKeywords && !isMarket;
            if (isMarket && !state.buyingItem && !state.purchasePending) {
               if (state.marketFirstSeenTime == 0L) {
                  state.marketFirstSeenTime = now;
               }

               if (!state.buyingItem && !state.autoSellPauseActive && !state.isRestarting && !state.marketLimitReached) {
                  if (state.marketContinuousOpenTime == 0L) {
                     state.marketContinuousOpenTime = now;
                  }

                  if ((now - state.marketContinuousOpenTime > 5000L || now - state.lastActionMs < 3000L) && now - state.lastAutoSellPauseMs > 10000L && hasItemsToSell()) {
                     state.autoSellPauseActive = true;
                     state.lastAutoSellPauseMs = now;
                     sendFeedback("§e[Auto-Sell] §fClosing market to list items...", 16763904);
                     class_310 client = class_310.method_1551();
                     client.execute(() -> {
                        if (client.field_1724 != null) {
                           if (client.field_1724.field_3944 != null && client.field_1724.field_7512 != null) {
                              client.field_1724.field_3944.method_52787(new class_2815(client.field_1724.field_7512.field_7763));
                           }

                           client.field_1724.method_7346();
                           if (client.field_1755 != null) {
                              client.method_1507((class_437)null);
                           }

                           sendFeedback("&e[Auto-Sell] Market GUI closed.", 11184810);
                        }

                     });
                     return;
                  }
               }
            } else {
               state.marketFirstSeenTime = 0L;
            }

            if (isMarket) {
               state.waitingForMarketOpen = false;
            } else if (state.waitingForMarketOpen && state.active && now - state.lastOpenAttemptMs > 2000L) {
               if (state.openAttemptsLeft > 0) {
                  --state.openAttemptsLeft;
                  state.lastOpenAttemptMs = now;
                  sendFeedback("&ePonawiam otwieranie rynku... (" + state.openAttemptsLeft + " prob)", 16777045);
                  sendMarketCommand();
               } else {
                  state.waitingForMarketOpen = false;
                  sendFeedback("&cNie udalo sie otworzyc rynku po kilku probach.", 16711680);
                  cancel();
               }
            }

            if (state.waitingForConfirmMsg) {
               long timeoutLimit = isMarket ? state.confirmMsgTimeout - 2000L : state.confirmMsgTimeout;
               if (now > timeoutLimit) {
                  state.waitingForConfirmMsg = false;
                  sendFeedback(Messages.get("automation.confirm.timeout"), 16763904);
                  restartScan(now, 1000);
               }

            } else if (isMarket) {
               if (state.buyingItem && now - state.buyingStartTime > 1000L) {
                  state.buyingItem = false;
               }

               if (!state.buyingItem && !state.purchasePending) {
                  int baseDelay = entry.marketNextDelayMs != null && entry.marketNextDelayMs > 0 ? entry.marketNextDelayMs : (BkRynekClient.isSniperMode ? 150 : 200);
                  if (now - state.lastActionMs >= (long)baseDelay && !state.purchasePending && !state.buyingItem) {
                     if (BkRynekClient.isSniperMode) {
                        if (!entry.profileName.equals("anarchia_smp")) {
                           int rSlot = entry.refreshSlot != null ? entry.refreshSlot : 51;
                           if (checkForMatchesAndLock(slots, handler)) {
                              return;
                           }

                           clickSlot(handler, rSlot, 0);
                           state.lastActionMs = now;
                        }
                     } else {
                        class_1735 nextSlot = findSlot(slots, entry.marketNextPageSlot);
                        boolean isLastPage = false;
                        String nextSlotName = nextSlot != null ? nextSlot.method_7677().method_7964().getString() : "";
                        int[] pages = extractPageNumbers(nextSlotName);
                        if (pages == null) {
                           pages = extractPageNumbers(title.getString());
                        }

                        if (pages != null && pages[0] >= pages[1] && pages[1] > 0) {
                           isLastPage = true;
                        }

                        if (isLastPage) {
                           sendFeedback(Messages.get("automation.pages.end"), 16763904);
                           restartScan(now);
                           return;
                        }

                        String currentSignature = buildPageSignature(slots);
                        if (nextSlot != null && !nextSlot.method_7677().method_7960()) {
                           if (currentSignature.equals(state.lastPageSignature)) {
                              if (now - state.lastClickMs > 800L) {
                                 restartScan(now);
                              }
                           } else {
                              clickSlot(handler, entry.marketNextPageSlot, 0);
                              state.lastClickMs = now;
                              state.lastActionMs = now;
                              state.lastPageSignature = currentSignature;
                           }
                        } else if (now - state.marketFirstSeenTime > 1500L) {
                           restartScan(now);
                        }
                     }

                  }
               }
            } else if (state.buyingItem || confirmKeywords) {
               if (!state.buyingItem && !confirmKeywords) {
                  if (confirmKeywords && !state.waitingForConfirmMsg && !state.buyingItem && !state.purchasePending) {
                     if (state.stuckInConfirmStartTime == 0L) {
                        state.stuckInConfirmStartTime = now;
                     } else {
                        long stuckTimeout = Boolean.TRUE.equals(entry.aggressiveAnarchiaMode) ? 250L : 2000L;
                        if (now - state.stuckInConfirmStartTime > stuckTimeout) {
                           if (Boolean.TRUE.equals(entry.aggressiveAnarchiaMode) && state.confirmClickCount < 5) {
                              sendFeedback("&eStuck! Retrying confirm click... (" + (state.confirmClickCount + 1) + ")", 16763904);
                              clickSlot(handler, entry.confirmSlot != null ? entry.confirmSlot : 10, 0);
                              ++state.confirmClickCount;
                              state.stuckInConfirmStartTime = now;
                              return;
                           }

                           sendFeedback("&eStuck in confirm screen, forcing restart...", 16763904);
                           state.stuckInConfirmStartTime = 0L;
                           restartScan(now, 0, Boolean.TRUE.equals(entry.aggressiveAnarchiaMode));
                        }
                     }

                     return;
                  }

                  state.stuckInConfirmStartTime = 0L;
               } else {
                  if (state.buyingItem && now - state.buyingStartTime > (long)(Boolean.TRUE.equals(entry.aggressiveAnarchiaMode) ? 1000 : 4000)) {
                     if (Boolean.TRUE.equals(entry.aggressiveAnarchiaMode) && state.confirmClickCount < 3) {
                        sendFeedback("&eTimeout! Retrying confirm click... (" + (state.confirmClickCount + 1) + "/3)", 16763904);
                        clickSlot(handler, entry.confirmSlot != null ? entry.confirmSlot : 10, 0);
                        ++state.confirmClickCount;
                        state.buyingStartTime = now;
                        return;
                     }

                     sendFeedback(Messages.get("automation.buy.timeout"), 16711680);
                     state.buyingItem = false;
                     restartScan(now, 0);
                     return;
                  }

                  boolean titleChanged = state.startBuyTitle.isEmpty() || !currentTitle.equals(state.startBuyTitle);
                  int confirmDelay = entry.marketConfirmDelayMs != null && entry.marketConfirmDelayMs > 0 ? entry.marketConfirmDelayMs : 10;
                  boolean syncIdChanged = state.lastSyncIdWhenBought != -1 && syncId != state.lastSyncIdWhenBought;
                  boolean windowDelayPassed = now - state.screenFirstSeenTime >= (long)confirmDelay;
                  long safetyTimeout = Boolean.TRUE.equals(entry.aggressiveAnarchiaMode) ? 100L : 500L;
                  if ((syncIdChanged || titleChanged || confirmKeywords || now - state.buyingStartTime > safetyTimeout) && windowDelayPassed) {
                     if (Boolean.TRUE.equals(entry.aggressiveAnarchiaMode)) {
                        if (!state.isThreadedBuyActive) {
                           startThreadedBuy(handler.field_7763, entry.confirmSlot != null ? entry.confirmSlot : 10, confirmDelay);
                        }
                     } else {
                        boolean shouldClick = state.confirmClickCount < entry.marketConfirmAttempts && now - state.lastActionMs > (long)confirmDelay;
                        if (!shouldClick && now - state.screenFirstSeenTime > 300L && now - state.lastActionMs > 100L) {
                           shouldClick = true;
                        }

                        if (shouldClick) {
                           if (entry.confirmSlot != null && entry.confirmSlot >= 0) {
                              clickSlot(handler, entry.confirmSlot, 0);
                           }

                           ++state.confirmClickCount;
                           state.lastActionMs = now;
                           String var10000 = Messages.get("automation.buy.confirming");
                           sendFeedback(var10000 + " (Próba " + state.confirmClickCount + ")");
                        }
                     }
                  }
               }

            }
         }
      }
   }

   private static void restartScan(long now) {
      restartScan(now, 0, false);
   }

   private static void restartScan(long now, int extraDelay) {
      restartScan(now, extraDelay, true);
   }

   private static void restartScan(long now, int extraDelay, boolean forceHard) {
      if (!state.isRestarting) {
         state.isRestarting = true;
         state.restartStartTime = now;
         state.extraRestartDelay = extraDelay;
         state.lastActionMs = now + 500L;
         state.lastPageSignature = "";
         state.refreshBlockedUntil = 0L;
         sendFeedback(Messages.get("automation.market.restarting"), 16763904);
         class_310.method_1551().execute(() -> {
            if (class_310.method_1551().field_1724 != null) {
               if (class_310.method_1551().field_1755 != null) {
                  class_310.method_1551().field_1724.method_7346();
                  class_310.method_1551().method_1507((class_437)null);
               }
            } else {
               state.isRestarting = false;
            }

         });
      }
   }

   public static void onItemMatch(class_1735 slot, double price, double priceLimit, PriceEntry priceEntry) {
      if (!state.purchasePending && !state.buyingItem && !state.waitingForConfirmMsg) {
         int syncId = class_310.method_1551().field_1724.field_7512.field_7763;
         executePurchase(slot, price, priceLimit, priceEntry, syncId);
      }
   }

   private static void executePurchase(class_1735 slot, double price, double priceLimit, PriceEntry priceEntry, int syncId) {
      executePurchase(slot, price, priceLimit, priceEntry, syncId, false);
   }

   private static void executePurchase(class_1735 slot, double price, double priceLimit, PriceEntry priceEntry, int syncId, boolean skipGuards) {
      if (!class_310.method_1551().method_18854()) {
         class_310.method_1551().execute(() -> executePurchase(slot, price, priceLimit, priceEntry, syncId, skipGuards));
      } else if (slot.field_7874 > 53) {
         state.purchasePending = false;
      } else {
         class_310 client = class_310.method_1551();
         int currentSyncId = syncId;
         if (client.field_1724 != null && client.field_1724.field_7512 != null && client.field_1724.field_7512.field_7763 != syncId) {
            class_1735 currentSlot = client.field_1724.field_7512.method_7611(slot.field_7874);
            if (currentSlot == null || !currentSlot.method_7681()) {
               state.purchasePending = false;
               return;
            }

            ScanInput input = createScanInput(currentSlot);
            ScanResult recheck = ScanEvaluator.evaluate(input, BkRynekClient.serversConfig, BkRynekClient.isSumMode);
            if (!recheck.highlight) {
               System.out.println("[BK-Rynek] Purchase aborted: Item changed after SyncId mismatch");
               state.purchasePending = false;
               return;
            }

            currentSyncId = client.field_1724.field_7512.field_7763;
         }

         if (skipGuards || state.active && !state.buyingItem && !state.waitingForConfirmMsg && !isItemPurchasedRecent(slot.field_7874) && !isItemTooExpensive(slot.method_7677().method_7964().getString(), price)) {
            if (state.buyingItem && state.lastMatchedSlotId == slot.field_7874 && System.currentTimeMillis() - state.buyingStartTime < 500L) {
               state.purchasePending = false;
            } else {
               state.lastMatchedItemName = slot.method_7677().method_7964().getString();
               state.lastMatchedPriceDouble = price;
               state.lastMatchedPrice = PriceFormatter.formatPrice(price);
               class_1799 stack = slot.method_7677();
               state.lastMatchedItemName = stack.method_7964().getString();
               state.lastMatchedAmount = stack.method_7947();

               try {
                  List<class_2561> tooltip = stack.method_7950(class_9635.field_51353, (class_1657)null, class_1836.field_41070);
                  StringBuilder loreBuilder = new StringBuilder();

                  for(int i = 1; i < tooltip.size(); ++i) {
                     String line = ((class_2561)tooltip.get(i)).getString();
                     String cleanLine = ColorStripUtils.stripAllColorsAndFormats(line).trim();
                     if (!cleanLine.isEmpty() && !cleanLine.startsWith("» Wystawił") && !cleanLine.startsWith("» Wystawiono") && !cleanLine.startsWith("» Koszt") && !cleanLine.startsWith("» Wygaśnie") && !cleanLine.startsWith("» Kliknij") && !cleanLine.contains("Kliknij LEWYM, aby zakupić")) {
                        if (loreBuilder.length() > 0) {
                           loreBuilder.append("\n");
                        }

                        loreBuilder.append(line);
                     }
                  }

                  state.lastMatchedLore = loreBuilder.toString();
               } catch (Exception var18) {
                  state.lastMatchedLore = "";
               }

               try {
                  StringBuilder enchantsBuilder = new StringBuilder();
                  class_9304 enchs = (class_9304)stack.method_57824(class_9334.field_49633);
                  if (enchs != null) {
                     for(Object2IntMap.Entry<class_6880<class_1887>> enchEntry : enchs.method_57539()) {
                        String enchName = ((class_1887)((class_6880)enchEntry.getKey()).comp_349()).comp_2686().getString();
                        int level = enchEntry.getIntValue();
                        if (enchantsBuilder.length() > 0) {
                           enchantsBuilder.append(", ");
                        }

                        enchantsBuilder.append(enchName).append(" ").append(level);
                     }
                  }

                  state.lastMatchedEnchants = enchantsBuilder.toString();
               } catch (Exception var17) {
                  state.lastMatchedEnchants = "";
               }

               long now = System.currentTimeMillis();
               state.buyingItem = true;
               state.buyingStartTime = now;
               state.lastActionMs = now;
               state.confirmClickCount = 0;
               state.matchedEntry = priceEntry;
               state.lastMatchedSlotId = slot.field_7874;
               state.purchasePending = false;
               sendFeedback("&eMATCH FOUND: &f" + state.lastMatchedItemName + " &7(&a" + state.lastMatchedPrice + "&7)", 16777045);
               state.purchasedCache.put(slot.field_7874, now + 500L);
               clickSlot(client.field_1724.field_7512, slot.field_7874, 0);
               state.refreshBlockedUntil = System.currentTimeMillis() + 10L;
               state.startBuyTitle = client.field_1724.field_7512.getClass().getSimpleName();
               class_437 screen = client.field_1755;
               if (screen != null) {
                  state.startBuyTitle = screen.method_25440().getString().toLowerCase();
               }

               state.lastKnownPrice = state.lastMatchedPrice;
               state.lastKnownItem = state.lastMatchedItemName;
               state.lastSyncIdWhenBought = currentSyncId;
               if (!state.isThreadedInitialClickActive) {
                  startRapidBuySpam(currentSyncId, slot.field_7874, 15);
               }

            }
         } else {
            state.purchasePending = false;
         }
      }
   }

   public static void onChatMessage(class_2561 message, boolean overlay) {
      String rawText = message.getString();
      String cleanText = ColorStripUtils.stripAllColorsAndFormats(rawText);
      String cleanTextLower = cleanText.toLowerCase();
      long now = System.currentTimeMillis();
      if (!rawText.contains("[BK Rynek]") && !rawText.contains("BK Rynek")) {
         if (state.active) {
            if (state.waitingForConfirmMsg && now > state.confirmMsgTimeout) {
               state.waitingForConfirmMsg = false;
            }

            boolean isMarketLimit = cleanTextLower.contains("limit produktów") || cleanTextLower.contains("limit wystawionych") || cleanTextLower.contains("osiągnąłeś limit") || cleanTextLower.contains("osiagnales limit") || cleanTextLower.contains("osiagn") && cleanTextLower.contains("limit");
            if (isMarketLimit) {
               state.marketLimitReached = true;
               state.pendingSellCommand = null;
               sendFeedback("&c[Auto-Sell] Market limit reached! Returning to market scan...", 16733525);
               System.out.println("[BK-Rynek] Market limit detected from message: " + cleanText);
               if (state.autoSellPauseActive) {
                  state.autoSellPauseActive = false;
                  restartScan(System.currentTimeMillis(), 0, true);
               }

            } else {
               boolean hasFormatting = !message.method_10866().method_10967() || message.method_10855().stream().anyMatch((s) -> !s.method_10866().method_10967());
               boolean looksLikePlayerChat = cleanText.contains(" » ");
               if (BkRynekClient.serversConfig != null) {
                  System.out.println("[BK-Rynek DEBUG] Chat: [" + cleanText + "] fmt=" + hasFormatting + " player=" + looksLikePlayerChat);
               }

               if (hasFormatting && !looksLikePlayerChat) {
                  boolean hasSuccess = cleanTextLower.contains("kupiles przedmiot") || cleanTextLower.contains("kupiłeś przedmiot") || cleanTextLower.contains("pomyslnie zakupiles") || cleanTextLower.contains("pomyślnie zakupiłeś") || cleanTextLower.contains("zakupiono przedmiot") || cleanTextLower.contains("zakupiono produkt") || cleanTextLower.contains("zakupiles produkt") || cleanTextLower.contains("kupiłeś produkt");
                  ServerEntry entry = findEntry();
                  if (entry != null && entry.successMessages != null) {
                     for(String msg : entry.successMessages) {
                        if (cleanTextLower.contains(msg.toLowerCase())) {
                           hasSuccess = true;
                           break;
                        }
                     }
                  }

                  boolean isListedConfirmation = cleanTextLower.contains("wystawiono produkt") || cleanTextLower.contains("wystawiono przedmiot") || cleanTextLower.contains("successfully listed");
                  boolean isBoughtByMe = cleanTextLower.contains("zakupiłeś") || cleanTextLower.contains("zakupiles");
                  boolean isSaleKeyword = cleanTextLower.contains("sprzedany") || cleanTextLower.contains("aukcj") || cleanTextLower.contains("rynek") || cleanTextLower.contains("market") || cleanTextLower.contains("produkt") || cleanTextLower.contains("bought") || cleanTextLower.contains("sold");
                  boolean isJunk = cleanTextLower.contains("zmianki") || cleanTextLower.contains("rzucił wyzwanie");
                  Pattern saleMoneyPattern = Pattern.compile("(?:\\+|dodane |otrzymano |wpłynęło |zarobiłeś )?([\\d\\s.,]+[kKmMldLD]?)\\$");
                  Matcher saleMatcher = saleMoneyPattern.matcher(cleanText);
                  boolean isSaleMonetary = saleMatcher.find() && isSaleKeyword && !isBoughtByMe && !isJunk;
                  if (!cleanText.contains("możesz to wykonać za") && !cleanText.contains("mozes zto wykonac za")) {
                     if (isListedConfirmation) {
                        ++state.sessionListed;
                        String webhook = BkRynekClient.serversConfig.discordWebhookUrl;
                        boolean listingEnabled = BkRynekClient.serversConfig.webhookListingEnabled;
                        System.out.println("[BK-Rynek DEBUG] Listing Match Detected!");
                        System.out.println("[BK-Rynek DEBUG]   Text: " + cleanText);
                        boolean var45 = webhook != null && !webhook.isEmpty();
                        System.out.println("[BK-Rynek DEBUG]   Webhook URL: " + var45);
                        System.out.println("[BK-Rynek DEBUG]   Listing Enabled: " + listingEnabled);
                        System.out.println("[BK-Rynek DEBUG]   Item: " + state.lastListingItemName + " x" + state.lastListingAmount + " (" + state.lastListingPrice + "$)");
                        if (webhook != null && !webhook.isEmpty() && listingEnabled) {
                           DiscordWebhook.sendListingNotification(webhook, state.lastListingItemName, state.lastListingPrice, BkRynekClient.getServerAddress(), state.lastListingAmount);
                        }

                     } else if (isSaleMonetary) {
                        if (now - state.lastSaleWebhookMs > 1000L) {
                           state.lastSaleWebhookMs = now;

                           try {
                              String valStr = saleMatcher.group(1).replace(" ", "");
                              double val = PriceFormatter.parsePrice(valStr);
                              if (val > (double)0.0F) {
                                 state.marketLimitReached = false;
                                 State var41 = state;
                                 var41.sessionProfit += val;
                                 String earnings = PriceFormatter.formatPrice(val);
                                 ++state.sessionSold;
                                 if (state.sessionListed > 0) {
                                    --state.sessionListed;
                                 }

                                 String webhook = BkRynekClient.serversConfig.discordWebhookUrl;
                                 boolean sellEnabled = BkRynekClient.serversConfig.webhookSellEnabled;
                                 boolean var44 = webhook != null && !webhook.isEmpty();
                                 System.out.println("[BK-Rynek DEBUG] Sale Match! Webhook: " + var44 + ", SellEnabled: " + sellEnabled);
                                 if (webhook != null && !webhook.isEmpty() && sellEnabled) {
                                    DiscordWebhook.sendSaleNotification(webhook, earnings, BkRynekClient.getServerAddress());
                                 }

                                 if (state.marketLimitReached) {
                                    state.marketLimitReached = false;
                                    sendFeedback("&a[Auto-Sell] Sale detected! Resuming listing check...", 5635925);
                                 }
                              }
                           } catch (Exception var25) {
                           }
                        }

                     } else {
                        boolean hasError = cleanTextLower.contains("juz prawdopodobnie usuniety") || cleanTextLower.contains("już prawdopodobnie usunięty") || cleanTextLower.contains("sprzedany") || cleanTextLower.contains("nie jest juz dostepny") || cleanTextLower.contains("nie jest już dostępny") || cleanTextLower.contains("produkt ten zostal juz") || cleanTextLower.contains("produkt ten został już") || cleanTextLower.contains("przedmiot zostal juz sprzedany") || cleanTextLower.contains("przedmiot został już sprzedany") || cleanTextLower.contains("prawdopodobnie usuniety") || cleanTextLower.contains("prawdopodobnie usunięty") || cleanTextLower.contains("this item was already bought");
                        if (entry != null && entry.errorMessages != null) {
                           for(String msg : entry.errorMessages) {
                              if (cleanTextLower.contains(msg.toLowerCase())) {
                                 hasError = true;
                                 break;
                              }
                           }
                        }

                        if (hasError) {
                           state.sortingPauseUntil = now + 2000L;
                           if (state.buyingItem || state.waitingForConfirmMsg) {
                              if (state.lastMatchedSlotId != -1) {
                                 markItemPurchasedRecent(state.lastMatchedSlotId);
                              }

                              state.waitingForConfirmMsg = false;
                              state.buyingItem = false;
                              state.purchasePending = false;
                              state.lastActionMs = now + (long)(Boolean.TRUE.equals(entry.aggressiveAnarchiaMode) ? 50 : 200);
                              state.refreshBlockedUntil = now + 10L;
                              sendFeedback(Messages.get("automation.item.sold"), 16711680);
                           }

                        } else if (!hasSuccess || !state.buyingItem && !state.waitingForConfirmMsg) {
                           if (hasSuccess || state.waitingForConfirmMsg || state.buyingItem) {
                              boolean hasNoMoney = cleanTextLower.contains("nie masz tyle") || cleanTextLower.contains("brak środków") || cleanTextLower.contains("nie posiadasz") || cleanTextLower.contains("nie stac cie") || cleanTextLower.contains("nie stać cię") || cleanTextLower.contains("nie stac ciebie") || cleanTextLower.contains("nie stać ciebie") || cleanTextLower.contains("nie posiadasz wystarczajaco") || cleanTextLower.contains("nie posiadasz wystarczająco");
                              if (hasNoMoney) {
                                 state.buyingItem = false;
                                 state.waitingForConfirmMsg = false;
                                 state.purchasePending = false;
                                 String itemName = state.matchedEntry != null ? state.matchedEntry.name : state.lastKnownItem;
                                 String errorMsg = Messages.format("automation.error.no_money_item", Map.of("item", itemName));
                                 sendFeedback("&c" + errorMsg, 16711680);
                                 markItemTooExpensive(itemName, state.lastMatchedPriceDouble);
                                 sendFeedback("&eTemporarily locked (expensive): &f" + itemName + " (" + (int)state.lastMatchedPriceDouble + "$)", 16777045);
                                 String webhook = BkRynekClient.serversConfig.discordWebhookUrl;
                                 if (webhook != null && !webhook.isEmpty()) {
                                    String priceStr = String.valueOf((int)state.lastMatchedPriceDouble);
                                    DiscordWebhook.sendErrorNotification(webhook, errorMsg, BkRynekClient.getServerAddress(), itemName, priceStr);
                                 }

                              }
                           }
                        } else {
                           if (state.lastMatchedSlotId != -1) {
                              markItemPurchasedRecent(state.lastMatchedSlotId);
                           }

                           state.waitingForConfirmMsg = false;
                           state.buyingItem = false;
                           state.purchasePending = false;
                           state.lastActionMs = now;
                           state.refreshBlockedUntil = now + 10L;
                           ++state.sessionBought;
                           if (state.lastMatchedPriceDouble > (double)0.0F) {
                              State var40 = state;
                              var40.sessionProfit -= state.lastMatchedPriceDouble;
                           }

                           state.sortingPauseUntil = now + 2000L;
                           sendFeedback(Messages.get("automation.webhook.success_confirmed"));
                           String webhook = BkRynekClient.serversConfig.discordWebhookUrl;
                           boolean buyEnabled = BkRynekClient.serversConfig.webhookBuyEnabled;
                           boolean var10001 = webhook != null && !webhook.isEmpty();
                           System.out.println("[BK-Rynek DEBUG] Success Match! Webhook: " + var10001 + ", BuyEnabled: " + buyEnabled);
                           if (webhook != null && !webhook.isEmpty() && buyEnabled) {
                              DiscordWebhook.sendPurchaseNotification(webhook, state.lastMatchedItemName, state.lastMatchedPrice, BkRynekClient.getServerAddress(), state.lastMatchedAmount, state.lastMatchedEnchants, state.lastMatchedLore);
                           }

                           state.snipeHistory.add(0, new SnipeEntry(state.lastMatchedItemName, state.lastMatchedPriceDouble, state.lastMatchedAmount));
                           if (state.snipeHistory.size() > 5) {
                              state.snipeHistory.remove(5);
                           }

                           if (!state.marketLimitReached && hasItemsToSell()) {
                              state.autoSellPauseActive = true;
                              state.lastAutoSellPauseMs = now;
                              sendFeedback("§e[Auto-Sell] §fPurchase confirmed! Closing market to list items...", 16763904);
                              class_310 client = class_310.method_1551();
                              client.execute(() -> {
                                 if (client.field_1724 != null) {
                                    if (client.field_1724.field_3944 != null && client.field_1724.field_7512 != null) {
                                       client.field_1724.field_3944.method_52787(new class_2815(client.field_1724.field_7512.field_7763));
                                    }

                                    client.field_1724.method_7346();
                                    if (client.field_1755 != null) {
                                       client.method_1507((class_437)null);
                                    }
                                 }

                              });
                           }

                        }
                     }
                  }
               }
            }
         }
      }
   }

   private static int[] extractPageNumbers(String text) {
      if (text == null) {
         return null;
      } else {
         Pattern p = Pattern.compile("(\\d+)/(\\d+)");
         Matcher m = p.matcher(text);
         if (m.find()) {
            try {
               return new int[]{Integer.parseInt(m.group(1)), Integer.parseInt(m.group(2))};
            } catch (Exception var4) {
            }
         }

         return null;
      }
   }

   private static double parseBalance(String balanceStr) {
      if (balanceStr != null && !balanceStr.equals("---")) {
         try {
            String clean = balanceStr.replaceAll("[^0-9.,]", "").replace(",", ".");
            return clean.isEmpty() ? (double)0.0F : Double.parseDouble(clean);
         } catch (Exception var2) {
            return (double)0.0F;
         }
      } else {
         return (double)0.0F;
      }
   }

   public static void onScreenClosed() {
      state.marketContinuousOpenTime = 0L;
      state.marketFirstSeenTime = 0L;
      state.isInsideConfirmScreen = false;
   }

   private static class_1735 findSlot(List<class_1735> slots, Integer id) {
      if (id == null) {
         return null;
      } else {
         for(class_1735 s : slots) {
            if (s.field_7874 == id) {
               return s;
            }
         }

         return null;
      }
   }

   private static void clickSlot(class_1703 handler, int slotId, int button) {
      class_310 client = class_310.method_1551();
      if (client.field_1724 != null && client.field_1761 != null) {
         client.field_1761.method_2906(handler.field_7763, slotId, button, class_1713.field_7790, client.field_1724);
      }
   }

   private static void sendClickPacket(int syncId, int slotId, int button) {
      class_310 client = class_310.method_1551();
      if (client.field_1724 != null && client.field_1724.field_3944 != null && client.field_1724.field_7512 != null) {
         int revision = 0;
         class_1703 var6 = client.field_1724.field_7512;
         if (var6 instanceof ScreenHandlerAccessor) {
            ScreenHandlerAccessor accessor = (ScreenHandlerAccessor)var6;
            revision = accessor.getRevision();
         }

         client.field_1724.field_3944.method_52787(new class_2813(syncId, revision, slotId, button, class_1713.field_7790, class_1799.field_8037, new Int2ObjectOpenHashMap()));
      }
   }

   private static void startRapidBuySpam(int syncId, int slotId, int intervalMs) {
      state.isThreadedInitialClickActive = true;
      SCHEDULER.submit(() -> {
         try {
            for(; state.active && state.buyingItem && !state.isInsideConfirmScreen; Thread.sleep((long)intervalMs)) {
               class_310 client = class_310.method_1551();
               if (client.field_1724 != null) {
                  if (client.field_1724.field_7512 != null && client.field_1724.field_7512.field_7763 == syncId) {
                     sendClickPacket(syncId, slotId, 0);
                  }
                  continue;
               }
            }
         } catch (InterruptedException var7) {
         } finally {
            state.isThreadedInitialClickActive = false;
         }

      });
   }

   private static void startThreadedBuy(int syncId, int slotId, int delay) {
      state.isThreadedBuyActive = true;
      SCHEDULER.submit(() -> {
         try {
            int maxTime = 4000;

            for(long start = System.currentTimeMillis(); state.active && state.buyingItem && System.currentTimeMillis() - start < (long)maxTime; Thread.sleep(delay > 0 ? (long)delay : 20L)) {
               class_310 client = class_310.method_1551();
               if (client.field_1724 == null) {
                  break;
               }

               if (client.field_1724.field_7512 != null && client.field_1724.field_7512.field_7763 == syncId) {
                  sendClickPacket(syncId, slotId, 0);
               }
            }
         } catch (InterruptedException var10) {
         } finally {
            state.isThreadedBuyActive = false;
         }

      });
   }

   private static boolean isNajnowszeSelected(class_1799 stack, String keyword) {
      class_9290 loreComponent = (class_9290)stack.method_57824(class_9334.field_49632);
      if (loreComponent != null && loreComponent.comp_2400() != null && !loreComponent.comp_2400().isEmpty()) {
         for(class_2561 line : loreComponent.comp_2400()) {
            String text = line.getString().toLowerCase();
            if (text.contains(keyword)) {
               class_2583 style = line.method_10866();
               if (style != null && style.method_10973() != null) {
                  String colorStr = style.method_10973().toString().toLowerCase();
                  if (colorStr.contains("yellow") || colorStr.contains("gold") || colorStr.contains("e") || colorStr.contains("6")) {
                     return true;
                  }
               }

               for(class_2561 sibling : line.method_10855()) {
                  String sibText = sibling.getString().toLowerCase();
                  class_2583 sibStyle = sibling.method_10866();
                  if ((sibText.contains(keyword) || sibText.contains("➤")) && sibStyle != null && sibStyle.method_10973() != null) {
                     String sibColor = sibStyle.method_10973().toString().toLowerCase();
                     if (sibColor.contains("yellow") || sibColor.contains("gold") || sibColor.contains("ffff55") || sibColor.contains("ffaa00")) {
                        return true;
                     }
                  }
               }

               String rawLine = line.getString();
               if (rawLine.contains("§e") || rawLine.contains("§6")) {
                  return true;
               }
            }
         }

         return false;
      } else {
         return false;
      }
   }

   private static String buildPageSignature(List<class_1735> slots) {
      if (slots == null) {
         return "";
      } else {
         StringBuilder sb = new StringBuilder();

         for(int i = 0; i < Math.min(slots.size(), 45); ++i) {
            class_1735 s = (class_1735)slots.get(i);
            if (s != null && !s.method_7677().method_7960()) {
               sb.append(s.method_7677().method_7964().getString());
            }

            sb.append("|");
         }

         return sb.toString();
      }
   }

   private static void sendMarketCommand() {
      class_310 client = class_310.method_1551();
      if (client.field_1724 != null && client.field_1724.field_3944 != null) {
         ServerEntry entry = findEntry();
         String cmd = entry != null && entry.marketCommands != null && !entry.marketCommands.isEmpty() ? (String)entry.marketCommands.get(0) : "ah";
         if (cmd.startsWith("/")) {
            cmd = cmd.substring(1);
         }

         sendFeedback(Messages.format("automation.sending", Map.of("command", cmd)), 16777045);
         client.field_1724.field_3944.method_45730(cmd);
      }
   }

   private static ServerEntry findEntry() {
      return BkRynekClient.findServerEntry(BkRynekClient.getServerAddress());
   }

   private static void reset() {
      state.active = false;
      state.marketLimitReached = false;
      state.buyingItem = false;
      state.buyingStartTime = 0L;
      state.startBuyTitle = "";
      state.lastActionMs = 0L;
      state.lastClickMs = 0L;
      state.lastPageSignature = "";
      state.waitingForConfirmMsg = false;
      state.confirmMsgTimeout = 0L;
      state.lastMatchedItemName = "";
      state.lastMatchedPrice = "";
      state.lastMatchedEnchants = "";
      state.lastMatchedLore = "";
      state.lastMatchedSlotId = -1;
      state.lastMatchedAmount = 0;
      state.lastMatchedPriceDouble = (double)0.0F;
      state.matchedEntry = null;
      state.isRestarting = false;
      state.restartStartTime = 0L;
      state.extraRestartDelay = 0;
      state.isInsideConfirmScreen = false;
      state.marketFirstSeenTime = 0L;
      state.marketDetectedLogged = false;
      state.confirmClickCount = 0;
      state.lastSyncId = -1L;
      state.screenFirstSeenTime = 0L;
      state.sortingConfirmed = false;
      state.waitingForMarketOpen = false;
      state.openAttemptsLeft = 0;
      state.lastOpenAttemptMs = 0L;
      state.stuckInConfirmStartTime = 0L;
      state.autoSellPauseActive = false;
      state.lastAutoSellPauseMs = 0L;
      state.marketContinuousOpenTime = 0L;
      state.currentMatches.clear();
      state.lastSaleWebhookMs = 0L;
      state.pendingSellCommand = null;
      state.pendingSellDelay = 150L;
      state.sortingPauseUntil = 0L;
      state.lastListingItemName = "";
      state.lastListingPrice = (double)0.0F;
      state.lastListingAmount = 0;
      state.purchasePending = false;
      state.refreshBlockedUntil = 0L;
      state.lastKnownItem = "None";
      state.isThreadedInitialClickActive = false;
      state.isThreadedBuyActive = false;
      state.isThreadedRefreshActive = false;
   }

   public static void resetSessionStats() {
      state.sessionBought = 0;
      state.sessionSold = 0;
      state.sessionProfit = (double)0.0F;
      state.initialBalance = (double)0.0F;
      state.currentBalance = (double)0.0F;
      state.sessionListed = 0;
      state.marketLimitReached = false;
      state.sessionStartTime = System.currentTimeMillis();
      sendFeedback("Session statistics have been reset!", 5635925);
   }

   private static void sendFeedback(String msg) {
      sendFeedback(msg, 65280);
   }

   public static void sendFeedback(String msg, int color) {
      class_746 player = class_310.method_1551().field_1724;
      if (player != null) {
         String prefix = "&8[&2B&aK &fRynek&8] ";
         player.method_7353(ColorUtils.translateColorCodes(prefix + msg), false);
         ToastManager.show(msg, color);
      }

   }

   public static long getMarketContinuousOpenTime() {
      return state.marketContinuousOpenTime;
   }

   public static int getSessionBought() {
      return state.sessionBought;
   }

   public static int getSessionSold() {
      return state.sessionSold;
   }

   public static double getSessionProfit() {
      return state.sessionProfit;
   }

   public static double getInitialBalance() {
      return state.initialBalance;
   }

   public static double getCurrentBalance() {
      double bal = parseBalance(ScoreboardUtils.getBalance());
      if (bal > (double)0.0F) {
         state.currentBalance = bal;
      }

      return state.currentBalance;
   }

   public static List<SnipeEntry> getSnipeHistory() {
      return state.snipeHistory;
   }

   public static long getSessionStartTime() {
      return state.sessionStartTime;
   }

   public static int getSessionListed() {
      return state.sessionListed;
   }

   public static String getLastKnownPrice() {
      return state.lastKnownPrice;
   }

   public static String getLastKnownItem() {
      return state.lastKnownItem;
   }

   public static String getCurrentStatus() {
      return state.active ? (state.buyingItem ? "§eBUYING" : "§aSCANNING") : "§7IDLE";
   }

   public static void onTick() {
      if (state.active) {
         long now = System.currentTimeMillis();
         if (state.pendingSellCommand != null) {
            if (now - state.lastActionMs > state.pendingSellDelay) {
               class_310 client = class_310.method_1551();
               if (client.field_1724 != null && client.field_1724.field_3944 != null) {
                  client.field_1724.field_3944.method_45730(state.pendingSellCommand);
                  sendFeedback("&a[Auto-Sell] &fListing command sent!", 5635925);
               }

               state.pendingSellCommand = null;
               state.pendingSellDelay = 150L;
               state.lastActionMs = now;
            }

         } else if (state.isRestarting) {
            ServerEntry entry = findEntry();
            long delay = entry != null && entry.marketRestartDelayMs != null && entry.marketRestartDelayMs > 0 ? (long)entry.marketRestartDelayMs : (long)(Boolean.TRUE.equals(entry.aggressiveAnarchiaMode) ? 100 : 800);
            delay += (long)state.extraRestartDelay;
            if (!Boolean.TRUE.equals(entry.aggressiveAnarchiaMode)) {
               delay += 200L;
            }

            if (now - state.restartStartTime > delay && now > state.lastActionMs) {
               state.isRestarting = false;
               state.buyingItem = false;
               state.waitingForConfirmMsg = false;
               state.purchasePending = false;
               if (state.active) {
                  sendMarketCommand();
                  state.waitingForMarketOpen = true;
                  state.lastOpenAttemptMs = now;
                  if (entry != null && entry.marketOpenAttempts != null) {
                     state.openAttemptsLeft = entry.marketOpenAttempts;
                  } else {
                     state.openAttemptsLeft = 1;
                  }
               }
            }

         } else if (state.waitingForMarketOpen && class_310.method_1551().field_1755 == null) {
            if (now - state.lastOpenAttemptMs > 2800L) {
               if (state.openAttemptsLeft > 0) {
                  --state.openAttemptsLeft;
                  state.lastOpenAttemptMs = now;
                  sendFeedback("&ePonawiam otwieranie rynku... (" + state.openAttemptsLeft + " prob)", 16777045);
                  sendMarketCommand();
               } else {
                  state.waitingForMarketOpen = false;
                  sendFeedback("&cNie udalo sie otworzyc rynku. Stop.", 16711680);
                  cancel();
               }
            }

         } else if (state.autoSellPauseActive) {
            if (state.marketLimitReached) {
               state.autoSellPauseActive = false;
               restartScan(now, 0, true);
            } else {
               long pauseElapsed = now - state.lastAutoSellPauseMs;
               if (class_310.method_1551().field_1755 != null) {
                  if (pauseElapsed > 500L && pauseElapsed < 600L) {
                     class_310 client = class_310.method_1551();
                     client.execute(() -> {
                        if (client.field_1724 != null) {
                           client.field_1724.method_7346();
                           client.method_1507((class_437)null);
                        }

                     });
                  }

                  if (pauseElapsed > 3000L) {
                     state.autoSellPauseActive = false;
                  }

               } else {
                  if (now >= state.lastInventoryScanMs && pauseElapsed > 1000L) {
                     scanInventoryAndSell();
                  }

                  boolean hasMore = hasItemsToSell();
                  if (!hasMore && state.pendingSellCommand == null && pauseElapsed > 1500L || pauseElapsed > 30000L) {
                     state.autoSellPauseActive = false;
                     state.marketContinuousOpenTime = 0L;
                     sendFeedback("§a[Auto-Sell] §fDone listing items. Resuming scan...", 5635925);
                     restartScan(now, 0, true);
                  }

               }
            }
         } else {
            if (class_310.method_1551().field_1755 == null && !state.waitingForMarketOpen && !state.isRestarting) {
               long sellDelay = state.autoSellPauseActive ? 1000L : 3000L;
               if (now >= state.lastInventoryScanMs + sellDelay && (!state.autoSellPauseActive || now - state.lastAutoSellPauseMs > 1000L)) {
                  scanInventoryAndSell();
               }
            }

         }
      }
   }

   private static void scanInventoryAndSell() {
      if (!state.marketLimitReached) {
         class_310 client = class_310.method_1551();
         if (client.field_1724 != null) {
            class_1661 inv = client.field_1724.method_31548();

            for(int i = 0; i < 36; ++i) {
               class_1799 stack = inv.method_5438(i);
               if (!stack.method_7960()) {
                  String name = ColorUtils.toLegacy(stack.method_7964());
                  String material = class_7923.field_41178.method_10221(stack.method_7909()).toString();
                  int componentCount = stack.method_57353().method_57835();
                  Integer customModelData = null;
                  class_9280 cmdComponent = (class_9280)stack.method_57824(class_9334.field_49637);
                  if (cmdComponent != null && !cmdComponent.comp_3354().isEmpty()) {
                     customModelData = Math.round((Float)cmdComponent.comp_3354().get(0));
                  }

                  List<class_2561> tooltip = stack.method_7950(class_9635.field_51353, (class_1657)null, class_1836.field_41070);
                  List<String> loreLines = new ArrayList();

                  for(class_2561 line : tooltip) {
                     loreLines.add(ColorStripUtils.stripAllColorsAndFormats(line.getString()));
                  }

                  StringBuilder enchantsBuilder = new StringBuilder();
                  class_9304 enchs = (class_9304)stack.method_57824(class_9334.field_49633);
                  if (enchs != null) {
                     for(Object2IntMap.Entry<class_6880<class_1887>> entry : enchs.method_57539()) {
                        String rawEnchId = (String)((class_6880)entry.getKey()).method_40230().map((key) -> key.method_29177().toString()).orElse("unknown");
                        String mapped = EnchantMapper.mapEnchant(rawEnchId, true);
                        int level = entry.getIntValue();
                        if (enchantsBuilder.length() > 0) {
                           enchantsBuilder.append(",");
                        }

                        enchantsBuilder.append(mapped).append(" ").append(level);
                     }
                  }

                  String enchants = enchantsBuilder.toString();
                  PriceEntry match = ClientPriceListManager.findMatchingPriceEntry(name, loreLines, material, enchants, componentCount, customModelData, true);
                  if (match != null) {
                     if (match.sellPrice <= (double)0.0F) {
                        sendFeedback("§c[Auto-Sell] §fItem '" + name + "' has no sellPrice set!", 16733525);
                     } else {
                        int minSell = match.sellCount != null && match.sellCount > 0 ? match.sellCount : (match.requiredCount != null && match.requiredCount > 0 ? match.requiredCount : 1);
                        if (stack.method_7947() >= minSell) {
                           if (i < 9) {
                              client.field_1724.method_31548().field_7545 = i;
                           } else {
                              client.field_1724.method_31548().field_7545 = 0;
                              if (client.field_1761 != null) {
                                 int syncId = client.field_1724.field_7498.field_7763;
                                 client.field_1761.method_2906(syncId, i, 0, class_1713.field_7791, client.field_1724);
                              }
                           }

                           ServerEntry entry = findEntry();
                           boolean useAutoRepair = entry != null && entry.autoRepair != null && entry.autoRepair;
                           boolean needsRepair = useAutoRepair && stack.method_7963() && stack.method_7919() > 0;
                           String sellCmd = "wystaw " + minSell + " " + (int)match.sellPrice;
                           if (needsRepair) {
                              String repairCmd = entry.repairCommand != null ? entry.repairCommand : "repair";
                              if (repairCmd.startsWith("/")) {
                                 repairCmd = repairCmd.substring(1);
                              }

                              client.field_1724.field_3944.method_45730(repairCmd);
                              sendFeedback("&a[Auto-Repair] &fRepairing and listing " + name + "...", 5635925);
                              state.pendingSellCommand = sellCmd;
                              state.pendingSellDelay = 800L;
                           } else {
                              state.pendingSellCommand = sellCmd;
                              state.pendingSellDelay = 150L;
                           }

                           state.lastActionMs = System.currentTimeMillis();
                           state.lastInventoryScanMs = state.lastActionMs + (long)(state.autoSellPauseActive ? 1000 : 3000);
                           state.lastListingItemName = name;
                           state.lastListingPrice = match.sellPrice;
                           state.lastListingAmount = minSell;
                           if (!needsRepair) {
                              sendFeedback("&a[Auto-Sell] &fSelling " + minSell + "x " + name + " for " + (int)match.sellPrice + "$", 5635925);
                           }
                           break;
                        }
                     }
                  }
               }
            }

         }
      }
   }

   public static boolean isItemFailed(int slotId) {
      Long expiry = (Long)state.failureCache.get(slotId);
      if (expiry != null) {
         if (System.currentTimeMillis() < expiry) {
            return true;
         }

         state.failureCache.remove(slotId);
      }

      return false;
   }

   public static void markItemFailed(int slotId) {
      state.failureCache.put(slotId, System.currentTimeMillis() + 5000L);
   }

   public static boolean isItemPurchasedRecent(int slotId) {
      Long expiry = (Long)state.purchasedCache.get(slotId);
      if (expiry != null) {
         if (System.currentTimeMillis() < expiry) {
            return true;
         }

         state.purchasedCache.remove(slotId);
      }

      return false;
   }

   public static void markItemPurchasedRecent(int slotId) {
      state.purchasedCache.put(slotId, System.currentTimeMillis() + 5000L);
   }

   public static boolean isItemTooExpensive(String name, double price) {
      String identifier = name + ":" + (int)price;
      Long expiry = (Long)state.tooExpensiveCache.get(identifier);
      if (expiry != null) {
         if (System.currentTimeMillis() < expiry) {
            return true;
         }

         state.tooExpensiveCache.remove(identifier);
      }

      return false;
   }

   public static void markItemTooExpensive(String name, double price) {
      String identifier = name + ":" + (int)price;
      state.tooExpensiveCache.put(identifier, System.currentTimeMillis() + 120000L);
   }

   private static boolean hasItemsToSell() {
      class_310 client = class_310.method_1551();
      if (client.field_1724 == null) {
         return false;
      } else {
         class_1661 inv = client.field_1724.method_31548();

         for(int i = 0; i < 36; ++i) {
            class_1799 stack = inv.method_5438(i);
            if (!stack.method_7960()) {
               String name = ColorUtils.toLegacy(stack.method_7964());
               String material = class_7923.field_41178.method_10221(stack.method_7909()).toString();
               int componentCount = stack.method_57353().method_57835();
               Integer customModelData = null;
               class_9280 cmdComponent = (class_9280)stack.method_57824(class_9334.field_49637);
               if (cmdComponent != null && !cmdComponent.comp_3354().isEmpty()) {
                  customModelData = Math.round((Float)cmdComponent.comp_3354().get(0));
               }

               List<class_2561> tooltip = stack.method_7950(class_9635.field_51353, (class_1657)null, class_1836.field_41070);
               List<String> loreLines = new ArrayList();

               for(class_2561 line : tooltip) {
                  loreLines.add(ColorStripUtils.stripAllColorsAndFormats(line.getString()));
               }

               StringBuilder enchantsBuilder = new StringBuilder();
               class_9304 enchs = (class_9304)stack.method_57824(class_9334.field_49633);
               if (enchs != null) {
                  for(Object2IntMap.Entry<class_6880<class_1887>> entry : enchs.method_57539()) {
                     String rawEnchId = (String)((class_6880)entry.getKey()).method_40230().map((key) -> key.method_29177().toString()).orElse("unknown");
                     String mapped = EnchantMapper.mapEnchant(rawEnchId, true);
                     int level = entry.getIntValue();
                     if (enchantsBuilder.length() > 0) {
                        enchantsBuilder.append(",");
                     }

                     enchantsBuilder.append(mapped).append(" ").append(level);
                  }
               }

               String enchants = enchantsBuilder.toString();
               PriceEntry match = ClientPriceListManager.findMatchingPriceEntry(name, loreLines, material, enchants, componentCount, customModelData, true);
               if (match != null && match.sellPrice > (double)0.0F) {
                  int minSell = match.sellCount != null && match.sellCount > 0 ? match.sellCount : (match.requiredCount != null && match.requiredCount > 0 ? match.requiredCount : 1);
                  if (stack.method_7947() >= minSell) {
                     return true;
                  }
               }
            }
         }

         return false;
      }
   }

   private static void startThreadedScanner(class_1703 handler) {
      stopThreadedScanner();
      int syncId = handler.field_7763;
      SCAN_FUTURE = SCHEDULER.scheduleWithFixedDelay(() -> {
         try {
            class_310 client = class_310.method_1551();
            if (!state.active || client.field_1724 == null) {
               return;
            }

            class_1703 currentHandler = client.field_1724.field_7512;
            if (currentHandler == null || currentHandler.field_7763 != syncId) {
               return;
            }

            List<class_1735> slots = ((ScreenHandlerAccessor)currentHandler).getSlots();
            Set<Integer> foundInThisScan = new HashSet();

            for(int i = 0; i < Math.min(slots.size(), 45); ++i) {
               class_1735 slot = (class_1735)slots.get(i);
               if (slot != null && slot.method_7681()) {
                  ScanInput input = createScanInput(slot);
                  ScanResult result = ScanEvaluator.evaluate(input, BkRynekClient.serversConfig, BkRynekClient.isSumMode);
                  if (result.highlight && !isItemPurchasedRecent(slot.field_7874)) {
                     foundInThisScan.add(slot.field_7874);
                     if (!state.buyingItem && !state.purchasePending && state.active) {
                        state.refreshBlockedUntil = System.currentTimeMillis() + 10L;
                        state.purchasePending = true;
                        double foundPrice = result.foundPrice;
                        double maxPrice = result.maxPrice;
                        PriceEntry matchedEntry = result.matchedEntry;
                        startRapidBuySpam(syncId, slot.field_7874, 10);
                        client.execute(() -> executePurchase(slot, foundPrice, maxPrice, matchedEntry, syncId, true));
                     }
                  }
               }
            }

            state.currentMatches.clear();
            state.currentMatches.addAll(foundInThisScan);
         } catch (Exception var16) {
         }

      }, 0L, 5L, TimeUnit.MILLISECONDS);
   }

   private static void stopThreadedScanner() {
      if (SCAN_FUTURE != null) {
         SCAN_FUTURE.cancel(false);
         SCAN_FUTURE = null;
      }

   }

   private static ScanInput createScanInput(class_1735 slot) {
      class_1799 stack = slot.method_7677();
      class_2960 id = class_7923.field_41178.method_10221(stack.method_7909());
      String materialId = id.toString();
      List<String> lore = new ArrayList();
      class_9290 loreComp = (class_9290)stack.method_57824(class_9334.field_49632);
      if (loreComp != null) {
         for(class_2561 line : loreComp.comp_2400()) {
            lore.add(ColorStripUtils.stripAllColorsAndFormats(line.getString()));
         }
      }

      int componentCount = stack.method_57353().method_57835();
      Integer customModelData = null;
      class_9280 cmdComponent = (class_9280)stack.method_57824(class_9334.field_49637);
      if (cmdComponent != null && !cmdComponent.comp_3354().isEmpty()) {
         customModelData = Math.round((Float)cmdComponent.comp_3354().get(0));
      }

      StringBuilder enchsStr = new StringBuilder();
      class_9304 enchs = (class_9304)stack.method_57824(class_9334.field_49633);
      if (enchs != null) {
         for(Object2IntMap.Entry<class_6880<class_1887>> entry : enchs.method_57539()) {
            String rawEnchId = (String)((class_6880)entry.getKey()).method_40230().map((key) -> key.method_29177().toString()).orElse("unknown");
            String mapped = EnchantMapper.mapEnchant(rawEnchId, true);
            int level = entry.getIntValue();
            if (enchsStr.length() > 0) {
               enchsStr.append(",");
            }

            enchsStr.append(mapped).append(" ").append(level);
         }
      }

      return new ScanInput(ColorUtils.toLegacy(stack.method_7964()), lore, materialId, enchsStr.toString(), stack.method_7947(), slot.field_7874, componentCount, customModelData);
   }

   private static boolean checkForMatchesAndLock(List<class_1735> slots, class_1703 handler) {
      if (!state.buyingItem && !state.purchasePending && System.currentTimeMillis() >= state.refreshBlockedUntil) {
         return !state.currentMatches.isEmpty();
      } else {
         return false;
      }
   }

   @Environment(EnvType.CLIENT)
   public static class SnipeEntry {
      public final String name;
      public final double price;
      public final int count;
      public final long timestamp;

      public SnipeEntry(String name, double price, int count) {
         this.name = name;
         this.price = price;
         this.count = count;
         this.timestamp = System.currentTimeMillis();
      }
   }

   @Environment(EnvType.CLIENT)
   private static class State {
      PriceEntry matchedEntry = null;
      volatile boolean active = false;
      long buyingStartTime = 0L;
      String startBuyTitle = "";
      volatile boolean buyingItem = false;
      volatile long refreshBlockedUntil = 0L;
      final Object refreshLock = new Object();
      long lastActionMs = 0L;
      long lastClickMs = 0L;
      String lastPageSignature = "";
      boolean waitingForConfirmMsg = false;
      long confirmMsgTimeout = 0L;
      String lastMatchedItemName = "";
      String lastMatchedPrice = "";
      String lastMatchedEnchants = "";
      String lastMatchedLore = "";
      int lastMatchedSlotId = -1;
      int lastMatchedAmount = 0;
      double lastMatchedPriceDouble = (double)0.0F;
      long marketFirstSeenTime = 0L;
      volatile boolean isRestarting = false;
      long restartStartTime = 0L;
      int extraRestartDelay = 0;
      volatile boolean isInsideConfirmScreen = false;
      volatile boolean marketDetectedLogged = false;
      int confirmClickCount = 0;
      long lastSyncId = -1L;
      int lastSyncIdWhenBought = -1;
      long screenFirstSeenTime = 0L;
      boolean sortingConfirmed = false;
      Map<Integer, Long> failureCache = new ConcurrentHashMap();
      Map<Integer, Long> purchasedCache = new ConcurrentHashMap();
      Map<String, Long> tooExpensiveCache = new ConcurrentHashMap();
      boolean waitingForMarketOpen = false;
      int openAttemptsLeft = 0;
      long lastOpenAttemptMs = 0L;
      long stuckInConfirmStartTime = 0L;
      int sessionBought = 0;
      int sessionSold = 0;
      double sessionProfit = (double)0.0F;
      double initialBalance = (double)0.0F;
      double currentBalance = (double)0.0F;
      long sessionStartTime = 0L;
      long lastInventoryScanMs = 0L;
      int sessionListed = 0;
      String lastKnownPrice = "---";
      String lastKnownItem = "None";
      boolean marketLimitReached = false;
      boolean autoSellPauseActive = false;
      long lastAutoSellPauseMs = 0L;
      long marketContinuousOpenTime = 0L;
      long lastSaleWebhookMs = 0L;
      String pendingSellCommand = null;
      long pendingSellDelay = 150L;
      long sortingPauseUntil = 0L;
      String lastListingItemName = "";
      double lastListingPrice = (double)0.0F;
      int lastListingAmount = 0;
      volatile boolean isThreadedInitialClickActive = false;
      volatile boolean isThreadedBuyActive = false;
      volatile boolean isThreadedRefreshActive = false;
      volatile boolean purchasePending = false;
      Set<Integer> currentMatches = ConcurrentHashMap.newKeySet();
      List<SnipeEntry> snipeHistory = new ArrayList();
   }
}
