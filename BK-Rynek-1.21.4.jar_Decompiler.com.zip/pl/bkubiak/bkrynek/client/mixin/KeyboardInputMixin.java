package pl.bkubiak.bkrynek.client.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10185;
import net.minecraft.class_743;
import net.minecraft.class_744;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pl.bkubiak.bkrynek.client.util.LobbyAutomationController;

@Environment(EnvType.CLIENT)
@Mixin({class_743.class})
public class KeyboardInputMixin {
   @Inject(
      method = {"tick"},
      at = {@At("TAIL")}
   )
   private void bkrynek$injectForwardMovement(CallbackInfo ci) {
      if (LobbyAutomationController.shouldForceForward()) {
         class_744 self = (class_744)this;
         if (self.field_54155 != null) {
            self.field_54155 = new class_10185(true, self.field_54155.comp_3160(), self.field_54155.comp_3161(), self.field_54155.comp_3162(), self.field_54155.comp_3163(), self.field_54155.comp_3164(), self.field_54155.comp_3165());
         } else {
            self.field_54155 = new class_10185(true, false, false, false, false, false, false);
         }
      }

   }
}
