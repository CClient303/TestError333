package pl.bkubiak.bkrynek.client.mixin;

import it.unimi.dsi.fastutil.objects.Object2IntMap;
import java.util.ArrayList;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1887;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3936;
import net.minecraft.class_437;
import net.minecraft.class_465;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import net.minecraft.class_9280;
import net.minecraft.class_9304;
import net.minecraft.class_9334;
import net.minecraft.class_1792.class_9635;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import pl.bkubiak.bkrynek.client.BkRynekClient;
import pl.bkubiak.bkrynek.client.gui.QuickAddPriceScreen;
import pl.bkubiak.bkrynek.client.gui.widgets.Panel;
import pl.bkubiak.bkrynek.client.keybinding.ToggleScanner;
import pl.bkubiak.bkrynek.client.util.AlarmSoundPlayer;
import pl.bkubiak.bkrynek.client.util.ColorUtils;
import pl.bkubiak.bkrynek.client.util.LobbyAutomationController;
import pl.bkubiak.bkrynek.client.util.SearchAutomationController;
import pl.bkubiak.bkrynek.client.util.SetupManager;
import pl.bkubiak.bkrynek.core.config.PriceEntry;
import pl.bkubiak.bkrynek.core.manager.ClientPriceListManager;
import pl.bkubiak.bkrynek.core.scan.ScanEvaluator;
import pl.bkubiak.bkrynek.core.scan.ScanInput;
import pl.bkubiak.bkrynek.core.scan.ScanResult;
import pl.bkubiak.bkrynek.core.util.ColorStripUtils;
import pl.bkubiak.bkrynek.core.util.EnchantMapper;

@Environment(EnvType.CLIENT)
@Mixin({class_465.class})
public abstract class HandledScreenMixin {
   @Shadow
   protected int field_2776;
   @Shadow
   protected int field_2800;
   @Shadow
   protected class_1735 field_2787;
   private int lastMatchedCount = 0;
   private class_1799[] lastStacks;
   private ScanResult[] lastResults;
   private int lastScreenSyncIdCache = -1;
   private long lastPriceListVersion = -1L;

   @Inject(
      method = {"render"},
      at = {@At("TAIL")}
   )
   private void onRender(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
      class_1703 handler = ((class_3936)this).method_17577();
      List<class_1735> slots = ((ScreenHandlerAccessor)handler).getSlots();
      class_2561 title = ((class_465)this).method_25440();
      LobbyAutomationController.onScreenRender(title, handler, slots);
      SearchAutomationController.onScreenRender(title, handler, slots);
      if (!SearchAutomationController.isInsideConfirmScreen()) {
         if (ToggleScanner.scanningEnabled) {
            int matchedCount = 0;

            for(class_1735 slot : slots) {
               if (this.processSlot(context, slot)) {
                  ++matchedCount;
               }
            }

            if (BkRynekClient.serversConfig != null && BkRynekClient.serversConfig.soundsEnabled && matchedCount != this.lastMatchedCount && matchedCount > 0) {
               AlarmSoundPlayer.playForMatchCount(BkRynekClient.serversConfig, ClientPriceListManager.getActiveProfile(), matchedCount);
            }

            this.lastMatchedCount = matchedCount;
         }
      }
   }

   @Inject(
      method = {"removed"},
      at = {@At("TAIL")}
   )
   private void onRemoved(CallbackInfo ci) {
      SearchAutomationController.onScreenClosed();
   }

   @Inject(
      method = {"keyPressed"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onKeyPressed(int keyCode, int scanCode, int modifiers, CallbackInfoReturnable<Boolean> cir) {
      if (keyCode == 65 && (modifiers & 2) != 0) {
         if (this.field_2787 != null && this.field_2787.method_7681()) {
            class_1799 stack = this.field_2787.method_7677();
            PriceEntry pe = this.createPriceEntryFromStack(stack);
            class_310 client = class_310.method_1551();
            client.method_1507(new QuickAddPriceScreen(pe, stack, (class_437)this, (saved) -> {
               if (saved && client.field_1724 != null) {
                  client.field_1724.method_7353(ColorUtils.translateColorCodes("&8[&2B&aK &fRynek&8] &aDodano przedmiot do listy! &7(x" + pe.requiredCount + ")"), false);
               }

            }));
            cir.setReturnValue(true);
         }
      } else if (keyCode == 83 && (modifiers & 2) != 0 && SetupManager.isActive()) {
         if (this.field_2787 != null) {
            SetupManager.handleSlotSelect(this.field_2787);
         } else {
            class_310.method_1551().field_1724.method_7353(ColorUtils.translateColorCodes("&8[&2B&aK &fRynek&8] &cNajeźdź kursor na przedmiot przed naciśnięciem Ctrl+S!"), false);
         }

         cir.setReturnValue(true);
      }

   }

   private PriceEntry createPriceEntryFromStack(class_1799 stack) {
      PriceEntry pe = new PriceEntry();
      pe.name = ColorUtils.toLegacy(stack.method_7964());
      List<class_2561> tooltip = stack.method_7950(class_9635.field_51353, (class_1657)null, class_1836.field_41070);
      List<String> loreLines = new ArrayList();

      for(int i = 1; i < tooltip.size(); ++i) {
         String line = ColorStripUtils.stripAllColorsAndFormats(((class_2561)tooltip.get(i)).getString()).trim();
         if (!line.isEmpty()) {
            String lower = line.toLowerCase();
            if (!lower.contains("wystawi") && !lower.contains("cena") && !lower.contains("koszt") && !lower.contains("kliknij") && !lower.contains("zakup") && !lower.contains("wygasnie") && !lower.contains("wygaśnie") && !lower.contains("expire") && !lower.contains("sprzeda") && !lower.contains("seller") && !lower.contains("buy") && !lower.contains("kwota") && !lower.contains("worth") && !lower.contains("time left") && !lower.contains("when in ") && !lower.contains("attack damage") && !lower.contains("durability:") && !lower.contains("projectile:") && !lower.contains("self destruct") && !lower.contains("price:") && !lower.contains("attack speed") && !lower.contains("mining efficiency") && !lower.contains("szyfr") && !lower.matches(".*\\d+[hm]\\s*\\d*[hm]?.*") && !lower.matches("[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}") && !this.isEnchantmentLine(lower)) {
               loreLines.add(line);
            }
         }
      }

      pe.lore = String.join(";", loreLines);
      pe.material = class_7923.field_41178.method_10221(stack.method_7909()).toString();
      StringBuilder enchantsBuilder = new StringBuilder();
      class_9304 enchs = (class_9304)stack.method_57824(class_9334.field_49633);
      if (enchs == null || enchs.method_57543()) {
         enchs = (class_9304)stack.method_57824(class_9334.field_49643);
      }

      if (enchs != null) {
         for(Object2IntMap.Entry<class_6880<class_1887>> entry : enchs.method_57539()) {
            String enchId = (String)((class_6880)entry.getKey()).method_40230().map((key) -> key.method_29177().toString()).orElse("unknown");
            String enchName = EnchantMapper.mapEnchant(enchId, true);
            if (enchName.equals("unknown")) {
               enchName = ((class_1887)((class_6880)entry.getKey()).comp_349()).comp_2686().getString();
            } else if (enchName.contains(" ")) {
               enchName = enchName.substring(0, enchName.lastIndexOf(" ")).trim();
            }

            int level = entry.getIntValue();
            if (enchantsBuilder.length() > 0) {
               enchantsBuilder.append(",");
            }

            enchantsBuilder.append(enchName).append(" ").append(level);
         }
      }

      pe.enchants = enchantsBuilder.toString();
      pe.componentCount = stack.method_57353().method_57835();
      class_9280 cmd = (class_9280)stack.method_57824(class_9334.field_49637);
      pe.customModelData = cmd != null && !cmd.comp_3354().isEmpty() ? Math.round((Float)cmd.comp_3354().get(0)) : null;
      pe.requiredCount = stack.method_7947();
      return pe;
   }

   private boolean processSlot(class_332 context, class_1735 slot) {
      class_1799 stack = slot.method_7677();
      if (!stack.method_7960() && !SearchAutomationController.isItemFailed(slot.field_7874)) {
         long currentVersion = ClientPriceListManager.getVersion();
         boolean cacheInvalid = false;
         if (currentVersion != this.lastPriceListVersion) {
            this.lastPriceListVersion = currentVersion;
            cacheInvalid = true;
         }

         class_1703 handler = ((class_3936)this).method_17577();
         if (this.lastStacks == null || handler.field_7763 != this.lastScreenSyncIdCache || cacheInvalid) {
            this.lastStacks = new class_1799[handler.field_7761.size()];
            this.lastResults = new ScanResult[handler.field_7761.size()];
            this.lastScreenSyncIdCache = handler.field_7763;
         }

         if (slot.field_7874 >= 0 && slot.field_7874 < this.lastStacks.length) {
            class_1799 last = this.lastStacks[slot.field_7874];
            if (last != null && class_1799.method_7973(last, stack)) {
               ScanResult cachedResult = this.lastResults[slot.field_7874];
               if (cachedResult != null) {
                  if (cachedResult.highlight) {
                     this.renderMatch(context, slot, cachedResult);
                     return true;
                  }

                  return false;
               }
            }
         }

         class_2960 id = class_7923.field_41178.method_10221(stack.method_7909());
         String materialId = id.toString();
         String materialNoPrefix = id.method_12832();
         List<PriceEntry> allTargets = (List)ClientPriceListManager.getAllProfiles().get(ClientPriceListManager.getActiveProfile());
         boolean possibleMatch = false;
         if (allTargets != null) {
            for(PriceEntry target : allTargets) {
               if (target.material != null && !target.material.isEmpty()) {
                  String targetMat = target.material;
                  if (targetMat.startsWith("minecraft:")) {
                     targetMat = targetMat.substring(10);
                  }

                  if (!materialId.equalsIgnoreCase(target.material) && !materialNoPrefix.equalsIgnoreCase(targetMat)) {
                     continue;
                  }

                  possibleMatch = true;
                  break;
               }

               possibleMatch = true;
               break;
            }
         }

         if (!possibleMatch) {
            this.updateCache(slot.field_7874, stack, ScanResult.noHighlight());
            return false;
         } else {
            String noColorName = ColorUtils.toLegacy(stack.method_7964());
            List<class_2561> tooltip = stack.method_7950(class_9635.field_51353, (class_1657)null, class_1836.field_41070);
            List<String> loreLines = new ArrayList();

            for(int i = 1; i < tooltip.size(); ++i) {
               String noColor = ColorStripUtils.stripAllColorsAndFormats(((class_2561)tooltip.get(i)).getString()).trim();
               if (!noColor.isEmpty()) {
                  loreLines.add(noColor);
               }
            }

            StringBuilder enchantsBuilder = new StringBuilder();
            class_9304 enchs = (class_9304)stack.method_57824(class_9334.field_49633);
            if (enchs == null || enchs.method_57543()) {
               enchs = (class_9304)stack.method_57824(class_9334.field_49643);
            }

            if (enchs != null) {
               for(Object2IntMap.Entry<class_6880<class_1887>> entry : enchs.method_57539()) {
                  String enchId = (String)((class_6880)entry.getKey()).method_40230().map((key) -> key.method_29177().toString()).orElse("unknown");
                  String enchName = EnchantMapper.mapEnchant(enchId, true);
                  if (enchName.equals("unknown")) {
                     enchName = ((class_1887)((class_6880)entry.getKey()).comp_349()).comp_2686().getString();
                  } else {
                     int lastSpace = enchName.lastIndexOf(32);
                     if (lastSpace != -1) {
                        String lastWord = enchName.substring(lastSpace + 1);
                        if (lastWord.matches("\\d+")) {
                           enchName = enchName.substring(0, lastSpace).trim();
                        }
                     }
                  }

                  int level = entry.getIntValue();
                  if (enchantsBuilder.length() > 0) {
                     enchantsBuilder.append(",");
                  }

                  enchantsBuilder.append(enchName).append(" ").append(level);
               }
            }

            String enchantmentsString = enchantsBuilder.toString();
            if (!enchantmentsString.isEmpty()) {
               loreLines.add(enchantmentsString);
            }

            int stackSize = stack.method_7947();
            int componentCount = stack.method_57353().method_57835();
            class_9280 cmd = (class_9280)stack.method_57824(class_9334.field_49637);
            Integer customModelData = cmd != null && !cmd.comp_3354().isEmpty() ? Math.round((Float)cmd.comp_3354().get(0)) : null;
            ScanInput input = new ScanInput(noColorName, loreLines, materialId, enchantmentsString, stackSize, slot.field_7874, componentCount, customModelData);
            ScanResult result = ScanEvaluator.evaluate(input, BkRynekClient.serversConfig, BkRynekClient.isSumMode);
            this.updateCache(slot.field_7874, stack, result);
            if (result.highlight) {
               this.renderMatch(context, slot, result);
               return true;
            } else {
               return false;
            }
         }
      } else {
         return false;
      }
   }

   private void updateCache(int id, class_1799 stack, ScanResult result) {
      if (this.lastStacks != null && id >= 0 && id < this.lastStacks.length) {
         this.lastStacks[id] = stack.method_7972();
         this.lastResults[id] = result;
      }

   }

   private void renderMatch(class_332 context, class_1735 slot, ScanResult result) {
      if (SearchAutomationController.isActive()) {
         SearchAutomationController.onItemMatch(slot, result.foundPrice, result.maxPrice, result.matchedEntry);
      }

      int realX = this.field_2776 + slot.field_7873;
      int realY = this.field_2800 + slot.field_7872;
      int baseColor = result.color;
      int borderColor = -872415232 | baseColor & 16777215;
      int fillColor = 889192448 | baseColor & 16777215;
      Panel.drawRoundedRect(context, realX, realY, 16, 16, 3, fillColor);
      Panel.drawRoundedRectOutline(context, realX, realY, 16, 16, 3, borderColor);
   }

   private boolean isEnchantmentLine(String lower) {
      return lower.startsWith("protection") || lower.startsWith("fire protection") || lower.startsWith("blast protection") || lower.startsWith("projectile protection") || lower.startsWith("feather falling") || lower.startsWith("respiration") || lower.startsWith("aqua affinity") || lower.startsWith("depth strider") || lower.startsWith("frost walker") || lower.startsWith("soul speed") || lower.startsWith("swift sneak") || lower.startsWith("thorns") || lower.startsWith("sharpness") || lower.startsWith("smite") || lower.startsWith("bane of arthropods") || lower.startsWith("fire aspect") || lower.startsWith("knockback") || lower.startsWith("looting") || lower.startsWith("sweeping edge") || lower.startsWith("efficiency") || lower.startsWith("silk touch") || lower.startsWith("unbreaking") || lower.startsWith("fortune") || lower.startsWith("power") || lower.startsWith("punch") || lower.startsWith("flame") || lower.startsWith("infinity") || lower.startsWith("luck of the sea") || lower.startsWith("lure") || lower.startsWith("multishot") || lower.startsWith("piercing") || lower.startsWith("quick charge") || lower.startsWith("channeling") || lower.startsWith("impaling") || lower.startsWith("loyalty") || lower.startsWith("riptide") || lower.startsWith("mending") || lower.startsWith("curse of binding") || lower.startsWith("curse of vanishing") || lower.startsWith("density") || lower.startsWith("breach") || lower.startsWith("wind burst");
   }
}
