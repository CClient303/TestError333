package pl.bkubiak.bkrynek.client.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_2371;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Environment(EnvType.CLIENT)
@Mixin({class_1703.class})
public interface ScreenHandlerAccessor {
   @Accessor("slots")
   class_2371<class_1735> getSlots();

   @Accessor("revision")
   int getRevision();
}
