package pl.bkubiak.bkrynek.client.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import net.minecraft.class_329;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pl.bkubiak.bkrynek.client.util.SearchAutomationController;

@Environment(EnvType.CLIENT)
@Mixin({class_329.class})
public class InGameHudMixin {
   @Inject(
      method = {"setTitle"},
      at = {@At("HEAD")}
   )
   private void onSetTitle(class_2561 title, CallbackInfo ci) {
      if (title != null) {
         SearchAutomationController.onChatMessage(title, true);
      }

   }

   @Inject(
      method = {"setSubtitle"},
      at = {@At("HEAD")}
   )
   private void onSetSubtitle(class_2561 subtitle, CallbackInfo ci) {
      if (subtitle != null) {
         SearchAutomationController.onChatMessage(subtitle, true);
      }

   }
}
