package pl.bkubiak.bkrynek.client.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1661;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Environment(EnvType.CLIENT)
@Mixin({class_1661.class})
public interface PlayerInventoryAccessor {
   @Accessor("selectedSlot")
   void setSelectedSlot(int var1);
}
