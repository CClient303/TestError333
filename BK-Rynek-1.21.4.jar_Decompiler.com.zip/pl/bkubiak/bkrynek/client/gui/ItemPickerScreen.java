package pl.bkubiak.bkrynek.client.gui;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_437;
import net.minecraft.class_7922;
import net.minecraft.class_7923;
import pl.bkubiak.bkrynek.client.gui.widgets.Button;
import pl.bkubiak.bkrynek.client.gui.widgets.Panel;

@Environment(EnvType.CLIENT)
public class ItemPickerScreen extends class_437 {
   private final class_437 parent;
   private final Consumer<String> onItemSelected;
   private class_342 searchField;
   private List<class_1792> allItems = new ArrayList();
   private List<class_1792> filteredItems = new ArrayList();
   private float scrollOffset = 0.0F;
   private float targetScrollOffset = 0.0F;
   private int selectedIndex = -1;
   private boolean isDraggingScrollbar = false;
   private double dragStartY;
   private float dragStartOffset;
   private int panelX;
   private int panelY;
   private int panelW;
   private int panelH;
   private int listX;
   private int listY;
   private int listW;
   private int listH;
   private int rowHeight = 24;
   private int visibleRows;

   public ItemPickerScreen(class_437 parent, Consumer<String> onItemSelected) {
      super(class_2561.method_30163("Select Item"));
      this.parent = parent;
      this.onItemSelected = onItemSelected;
      this.loadAllItems();
   }

   private void loadAllItems() {
      this.allItems.clear();
      class_7922 var10000 = class_7923.field_41178;
      List var10001 = this.allItems;
      Objects.requireNonNull(var10001);
      var10000.forEach(var10001::add);
      this.allItems.sort(Comparator.comparing((item) -> class_7923.field_41178.method_10221(item).toString()));
      this.filteredItems = new ArrayList(this.allItems);
   }

   protected void method_25426() {
      this.method_37067();
      super.method_25426();
      this.panelW = Math.min(500, this.field_22789 - 40);
      this.panelH = Math.min(400, this.field_22790 - 40);
      this.panelX = (this.field_22789 - this.panelW) / 2;
      this.panelY = (this.field_22790 - this.panelH) / 2;
      int margin = 16;
      this.listX = this.panelX + margin;
      this.listY = this.panelY + 60;
      this.listW = this.panelW - margin * 2;
      this.listH = this.panelH - 100;
      this.visibleRows = this.listH / this.rowHeight;
      this.searchField = new class_342(this.field_22793, this.listX, this.panelY + 30, this.listW, 20, class_2561.method_30163(""));
      this.searchField.method_47404(class_2561.method_30163("§8Search items..."));
      this.searchField.method_1863(this::onSearchChanged);
      this.searchField.method_1880(64);
      this.method_37063(this.searchField);
      this.method_37063(new Button(this.panelX + this.panelW - 20, this.panelY + 4, 16, 16, "X", (btn) -> this.method_25419(), -48060, false));
      this.method_48265(this.searchField);
   }

   private void onSearchChanged(String query) {
      String search = query.toLowerCase().trim();
      this.filteredItems.clear();
      if (search.isEmpty()) {
         this.filteredItems.addAll(this.allItems);
      } else {
         for(class_1792 item : this.allItems) {
            class_2960 id = class_7923.field_41178.method_10221(item);
            String idStr = id.toString().toLowerCase();
            class_1799 stack = new class_1799(item);
            String name = stack.method_7964().getString().toLowerCase();
            String cleanName = name.replaceAll("§[0-9a-fk-or]", "");
            if (idStr.contains(search) || cleanName.contains(search)) {
               this.filteredItems.add(item);
            }
         }
      }

      this.scrollOffset = 0.0F;
      this.targetScrollOffset = 0.0F;
      this.selectedIndex = this.filteredItems.isEmpty() ? -1 : 0;
   }

   public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
      context.method_25294(0, 0, this.field_22789, this.field_22790, -1442840576);
      if (this.field_22789 >= 350 && this.field_22790 >= 250) {
         float scrollDiff = this.targetScrollOffset - this.scrollOffset;
         if (Math.abs(scrollDiff) > 0.1F) {
            this.scrollOffset += scrollDiff * 0.25F;
            if (Math.abs(scrollDiff) < 0.5F) {
               this.scrollOffset = this.targetScrollOffset;
            }
         } else {
            this.scrollOffset = this.targetScrollOffset;
         }

         Panel.drawPanel(context, this.panelX, this.panelY, this.panelW, this.panelH, 10);
         Panel.drawHeader(context, this.panelX, this.panelY, this.panelW, 24);
         Panel.drawTrafficLights(context, this.panelX + 12, this.panelY + 11);
         context.method_51433(this.field_22793, "§7Select Item", this.field_22789 / 2 - 30, this.panelY + 8, -5592406, false);
         String countText = this.filteredItems.size() + " items";
         int countWidth = this.field_22793.method_1727(countText);
         context.method_51433(this.field_22793, countText, this.panelX + this.panelW - countWidth - 30, this.panelY + 8, -10066330, false);
         context.method_44379(this.listX, this.listY, this.listX + this.listW, this.listY + this.listH);
         int totalItems = this.filteredItems.size();
         int maxScroll = Math.max(0, totalItems * this.rowHeight - this.listH);
         this.targetScrollOffset = Math.max(0.0F, Math.min(this.targetScrollOffset, (float)maxScroll));
         int startIndex = (int)(this.scrollOffset / (float)this.rowHeight);
         int endIndex = Math.min(totalItems, startIndex + this.visibleRows + 2);

         for(int i = startIndex; i < endIndex && i < this.filteredItems.size(); ++i) {
            class_1792 item = (class_1792)this.filteredItems.get(i);
            int rowY = this.listY + i * this.rowHeight - (int)this.scrollOffset;
            if (rowY + this.rowHeight >= this.listY && rowY <= this.listY + this.listH) {
               boolean isHovered = mouseX >= this.listX && mouseX <= this.listX + this.listW - 10 && mouseY >= rowY && mouseY < rowY + this.rowHeight;
               boolean isSelected = i == this.selectedIndex;
               if (!isSelected && !isHovered) {
                  if (i % 2 == 0) {
                     context.method_25294(this.listX, rowY, this.listX + this.listW - 10, rowY + this.rowHeight, 285212671);
                  }
               } else {
                  int bgColor = isSelected ? 1613989973 : 1090519039;
                  context.method_25294(this.listX, rowY, this.listX + this.listW - 10, rowY + this.rowHeight, bgColor);
               }

               class_1799 stack = new class_1799(item);
               context.method_51427(stack, this.listX + 4, rowY + 4);
               String itemName = stack.method_7964().getString();
               int maxNameWidth = this.listW - 28;
               if (this.field_22793.method_1727(itemName) > maxNameWidth) {
                  String var10000 = this.field_22793.method_27523(itemName, maxNameWidth - 10);
                  itemName = var10000 + "...";
               }

               context.method_51433(this.field_22793, itemName, this.listX + 24, rowY + 2, -1, false);
               class_2960 id = class_7923.field_41178.method_10221(item);
               context.method_51433(this.field_22793, "§7" + id.toString(), this.listX + 24, rowY + 14, -10066330, false);
               if (isHovered) {
                  this.selectedIndex = i;
               }
            }
         }

         context.method_44380();
         if (totalItems * this.rowHeight > this.listH) {
            int scrollbarX = this.listX + this.listW - 6;
            int scrollbarW = 6;
            float visiblePercent = (float)this.listH / (float)(totalItems * this.rowHeight);
            float scrollPercent = this.scrollOffset / (float)maxScroll;
            boolean scrollHover = mouseX >= scrollbarX && mouseX <= scrollbarX + scrollbarW && mouseY >= this.listY && mouseY <= this.listY + this.listH;
            Panel.drawScrollbar(context, scrollbarX, this.listY, scrollbarW, this.listH, scrollPercent, visiblePercent, scrollHover || this.isDraggingScrollbar);
         }

         super.method_25394(context, mouseX, mouseY, delta);
      } else {
         String msg = "§cWindow too small. Please resize.";
         int msgWidth = this.field_22793.method_1727(msg);
         context.method_51433(this.field_22793, msg, (this.field_22789 - msgWidth) / 2, this.field_22790 / 2, -48060, false);
      }
   }

   public boolean method_25402(double mouseX, double mouseY, int button) {
      if (super.method_25402(mouseX, mouseY, button)) {
         return true;
      } else {
         if (button == 0) {
            int totalItems = this.filteredItems.size();
            int maxScroll = Math.max(0, totalItems * this.rowHeight - this.listH);
            if (maxScroll > 0) {
               int scrollbarX = this.listX + this.listW - 6;
               if (mouseX >= (double)scrollbarX && mouseX <= (double)(scrollbarX + 6) && mouseY >= (double)this.listY && mouseY <= (double)(this.listY + this.listH)) {
                  this.isDraggingScrollbar = true;
                  this.dragStartY = mouseY;
                  this.dragStartOffset = this.scrollOffset;
                  return true;
               }
            }

            if (mouseX >= (double)this.listX && mouseX <= (double)(this.listX + this.listW - 10) && mouseY >= (double)this.listY && mouseY <= (double)(this.listY + this.listH)) {
               int clickedIndex = (int)((mouseY - (double)this.listY + (double)this.scrollOffset) / (double)this.rowHeight);
               if (clickedIndex >= 0 && clickedIndex < this.filteredItems.size()) {
                  this.selectItem(clickedIndex);
                  return true;
               }
            }
         }

         return false;
      }
   }

   public boolean method_25403(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
      if (this.isDraggingScrollbar && button == 0) {
         int totalItems = this.filteredItems.size();
         int maxScroll = Math.max(0, totalItems * this.rowHeight - this.listH);
         double dragDelta = mouseY - this.dragStartY;
         float scrollRatio = (float)dragDelta / (float)this.listH;
         this.targetScrollOffset = this.dragStartOffset + scrollRatio * (float)(totalItems * this.rowHeight);
         this.targetScrollOffset = Math.max(0.0F, Math.min(this.targetScrollOffset, (float)maxScroll));
         this.scrollOffset = this.targetScrollOffset;
         return true;
      } else {
         return super.method_25403(mouseX, mouseY, button, deltaX, deltaY);
      }
   }

   public boolean method_25406(double mouseX, double mouseY, int button) {
      if (button == 0) {
         this.isDraggingScrollbar = false;
      }

      return super.method_25406(mouseX, mouseY, button);
   }

   public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
      if (mouseX >= (double)this.listX && mouseX <= (double)(this.listX + this.listW) && mouseY >= (double)this.listY && mouseY <= (double)(this.listY + this.listH)) {
         int totalItems = this.filteredItems.size();
         int maxScroll = Math.max(0, totalItems * this.rowHeight - this.listH);
         this.targetScrollOffset = (float)((double)this.targetScrollOffset - verticalAmount * (double)15.0F);
         this.targetScrollOffset = Math.max(0.0F, Math.min(this.targetScrollOffset, (float)maxScroll));
         return true;
      } else {
         return super.method_25401(mouseX, mouseY, horizontalAmount, verticalAmount);
      }
   }

   public boolean method_25404(int keyCode, int scanCode, int modifiers) {
      if (keyCode == 257 && this.selectedIndex >= 0 && this.selectedIndex < this.filteredItems.size()) {
         this.selectItem(this.selectedIndex);
         return true;
      } else if (keyCode == 256) {
         this.method_25419();
         return true;
      } else if (keyCode == 264 && this.selectedIndex < this.filteredItems.size() - 1) {
         ++this.selectedIndex;
         this.ensureVisible(this.selectedIndex);
         return true;
      } else if (keyCode == 265 && this.selectedIndex > 0) {
         --this.selectedIndex;
         this.ensureVisible(this.selectedIndex);
         return true;
      } else if (keyCode == 266) {
         this.selectedIndex = Math.min(this.filteredItems.size() - 1, this.selectedIndex + this.visibleRows);
         this.ensureVisible(this.selectedIndex);
         return true;
      } else if (keyCode == 267) {
         this.selectedIndex = Math.max(0, this.selectedIndex - this.visibleRows);
         this.ensureVisible(this.selectedIndex);
         return true;
      } else {
         return super.method_25404(keyCode, scanCode, modifiers);
      }
   }

   private void ensureVisible(int index) {
      int itemY = index * this.rowHeight;
      int maxScroll = Math.max(0, this.filteredItems.size() * this.rowHeight - this.listH);
      if ((float)itemY < this.targetScrollOffset) {
         this.targetScrollOffset = (float)itemY;
      } else if ((float)(itemY + this.rowHeight) > this.targetScrollOffset + (float)this.listH) {
         this.targetScrollOffset = (float)(itemY + this.rowHeight - this.listH);
      }

      this.targetScrollOffset = Math.max(0.0F, Math.min(this.targetScrollOffset, (float)maxScroll));
   }

   private void selectItem(int index) {
      if (index >= 0 && index < this.filteredItems.size()) {
         class_1792 item = (class_1792)this.filteredItems.get(index);
         class_2960 id = class_7923.field_41178.method_10221(item);
         this.onItemSelected.accept(id.toString());
         this.method_25419();
      }

   }

   public void method_25419() {
      class_310.method_1551().method_1507(this.parent);
   }

   public boolean method_25421() {
      return false;
   }
}
