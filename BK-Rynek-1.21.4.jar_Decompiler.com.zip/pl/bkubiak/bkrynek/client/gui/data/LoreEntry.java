package pl.bkubiak.bkrynek.client.gui.data;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class LoreEntry {
   public Integer lineNumber;
   public String content;

   public LoreEntry() {
      this.lineNumber = null;
      this.content = "";
   }

   public LoreEntry(Integer lineNumber, String content) {
      this.lineNumber = lineNumber;
      this.content = content;
   }

   public boolean isEmpty() {
      return this.content == null || this.content.isEmpty();
   }
}
