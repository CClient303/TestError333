package pl.bkubiak.bkrynek.client.gui.data;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class EnchantEntry {
   public String enchantmentId;
   public String enchantmentName;
   public int minLevel;

   public EnchantEntry() {
      this.enchantmentId = "";
      this.enchantmentName = "";
      this.minLevel = 1;
   }

   public EnchantEntry(String enchantmentId, String enchantmentName, int minLevel) {
      this.enchantmentId = enchantmentId;
      this.enchantmentName = enchantmentName;
      this.minLevel = minLevel;
   }

   public boolean isEmpty() {
      return this.enchantmentId == null || this.enchantmentId.isEmpty();
   }
}
