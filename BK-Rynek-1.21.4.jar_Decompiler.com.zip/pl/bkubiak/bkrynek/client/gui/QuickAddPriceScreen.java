package pl.bkubiak.bkrynek.client.gui;

import java.util.function.Consumer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1799;
import net.minecraft.class_1935;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_437;
import net.minecraft.class_7923;
import pl.bkubiak.bkrynek.client.BkRynekClient;
import pl.bkubiak.bkrynek.client.command.ClientCommandRegistration;
import pl.bkubiak.bkrynek.client.config.ConfigLoader;
import pl.bkubiak.bkrynek.client.gui.widgets.Button;
import pl.bkubiak.bkrynek.client.gui.widgets.Panel;
import pl.bkubiak.bkrynek.core.config.PriceEntry;
import pl.bkubiak.bkrynek.core.manager.ClientPriceListManager;
import pl.bkubiak.bkrynek.core.util.Messages;

@Environment(EnvType.CLIENT)
public class QuickAddPriceScreen extends class_437 {
   private final PriceEntry pendingEntry;
   private final class_437 parent;
   private class_342 priceField;
   private final Consumer<Boolean> callback;
   private final class_1799 previewStack;

   public QuickAddPriceScreen(PriceEntry entry, class_1799 stack, class_437 parent, Consumer<Boolean> callback) {
      super(class_2561.method_30163("Quick Add"));
      this.pendingEntry = entry;
      this.previewStack = stack;
      this.parent = parent;
      this.callback = callback;
   }

   protected void method_25426() {
      int w = 200;
      int h = 100;
      int x = (this.field_22789 - w) / 2;
      int y = (this.field_22790 - h) / 2;
      this.priceField = new class_342(this.field_22793, x + 20, y + 45, 160, 16, class_2561.method_30163("Cena"));
      this.priceField.method_1880(15);
      this.priceField.method_1858(true);
      this.priceField.method_1868(-1);
      this.method_25429(this.priceField);
      this.method_37063(this.priceField);
      this.method_48265(this.priceField);
      this.method_37063(new Button(x + 20, y + 70, 75, 18, Messages.get("gui.btn.add"), (button) -> this.saveAndClose(), -12255420, true));
      this.method_37063(new Button(x + 105, y + 70, 75, 18, Messages.get("gui.btn.cancel"), (button) -> {
         this.field_22787.method_1507(this.parent);
         this.callback.accept(false);
      }, -48060, false));
   }

   private void saveAndClose() {
      try {
         String val = this.priceField.method_1882().replace(",", ".");
         if (val.isEmpty()) {
            return;
         }

         this.pendingEntry.maxPrice = Double.parseDouble(val);
         ClientPriceListManager.addPriceEntry(this.pendingEntry);
         ClientCommandRegistration.syncMemoryToConfig();
         ConfigLoader.saveAllConfigs(BkRynekClient.serversConfig);
         this.field_22787.method_1507(this.parent);
         this.callback.accept(true);
      } catch (NumberFormatException var2) {
      }

   }

   public boolean method_25404(int keyCode, int scanCode, int modifiers) {
      if (keyCode != 257 && keyCode != 335) {
         if (keyCode == 256) {
            this.field_22787.method_1507(this.parent);
            this.callback.accept(false);
            return true;
         } else {
            return super.method_25404(keyCode, scanCode, modifiers);
         }
      } else {
         this.saveAndClose();
         return true;
      }
   }

   public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
      context.method_25294(0, 0, this.field_22789, this.field_22790, -1442840576);
      int w = 200;
      int h = 100;
      int x = (this.field_22789 - w) / 2;
      int y = (this.field_22790 - h) / 2;
      Panel.drawPanel(context, x, y, w, h, 6);
      Panel.drawHeader(context, x, y, w, 18);
      context.method_51433(this.field_22793, "Quick Add Price", x + 10, y + 5, -5592406, false);

      try {
         if (this.previewStack != null && !this.previewStack.method_7960()) {
            context.method_51427(this.previewStack, x + 20, y + 24);
            context.method_51433(this.field_22793, "§a" + this.pendingEntry.name, x + 42, y + 28, -1, false);
         } else if (this.pendingEntry.material != null) {
            class_1799 stack = new class_1799((class_1935)class_7923.field_41178.method_63535(class_2960.method_60654(this.pendingEntry.material)));
            context.method_51427(stack, x + 20, y + 24);
            context.method_51433(this.field_22793, "§a" + this.pendingEntry.name, x + 42, y + 28, -1, false);
         } else {
            context.method_51433(this.field_22793, "§a" + this.pendingEntry.name, x + 20, y + 28, -1, false);
         }
      } catch (Exception var10) {
         context.method_51433(this.field_22793, "§a" + this.pendingEntry.name, x + 20, y + 28, -1, false);
      }

      super.method_25394(context, mouseX, mouseY, delta);
   }
}
