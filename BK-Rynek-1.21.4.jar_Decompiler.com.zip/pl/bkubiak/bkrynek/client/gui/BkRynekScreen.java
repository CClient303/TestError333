package pl.bkubiak.bkrynek.client.gui;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_156;
import net.minecraft.class_1799;
import net.minecraft.class_1935;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_437;
import net.minecraft.class_7923;
import net.minecraft.class_9280;
import net.minecraft.class_9334;
import pl.bkubiak.bkrynek.client.BkRynekClient;
import pl.bkubiak.bkrynek.client.command.ClientCommandRegistration;
import pl.bkubiak.bkrynek.client.gui.widgets.Button;
import pl.bkubiak.bkrynek.client.gui.widgets.Panel;
import pl.bkubiak.bkrynek.client.gui.widgets.Slider;
import pl.bkubiak.bkrynek.client.gui.widgets.ToggleButton;
import pl.bkubiak.bkrynek.client.keybinding.ToggleScanner;
import pl.bkubiak.bkrynek.client.util.SearchAutomationController;
import pl.bkubiak.bkrynek.client.util.ToastManager;
import pl.bkubiak.bkrynek.core.config.CoreConfigLoader;
import pl.bkubiak.bkrynek.core.config.PriceEntry;
import pl.bkubiak.bkrynek.core.config.ServerEntry;
import pl.bkubiak.bkrynek.core.manager.ClientPriceListManager;
import pl.bkubiak.bkrynek.core.util.PriceFormatter;

@Environment(EnvType.CLIENT)
public class BkRynekScreen extends class_437 {
   private int panelX;
   private int panelY;
   private int panelW;
   private int panelH;
   private int leftPanelW;
   private int margin = 12;
   private double scrollOffset = (double)0.0F;
   private int rowHeight = 26;
   private boolean isScrolling = false;
   private ServerEntry currentServer;
   private boolean showSellTab = false;
   private class_342 searchField;
   private String searchQuery = "";

   public BkRynekScreen() {
      super(class_2561.method_30163("BK-Rynek - Dashboard"));
   }

   protected void method_25426() {
      super.method_25426();
      this.currentServer = BkRynekClient.findServerEntry(BkRynekClient.getServerAddress());
      this.panelW = Math.min(500, this.field_22789 - 20);
      this.panelH = Math.min(300, (int)((double)this.field_22790 * 0.9));
      this.panelX = (this.field_22789 - this.panelW) / 2;
      this.panelY = (this.field_22790 - this.panelH) / 2;
      this.leftPanelW = (int)((double)this.panelW * 0.4);
      int leftX = this.panelX + this.margin;
      int leftY = this.panelY + 45;
      int fieldW = this.leftPanelW - this.margin * 2;
      this.method_37063(new Button(leftX, leftY, (fieldW - 6) / 2, 20, "START", (btn) -> {
         SearchAutomationController.start(-1);
         this.method_25419();
      }, -12255420, -1, true));
      this.method_37063(new Button(leftX + (fieldW - 6) / 2 + 6, leftY, (fieldW - 6) / 2, 20, "STOP", (btn) -> SearchAutomationController.cancel(), -48060, -1, true));
      this.method_37063(new Button(leftX, leftY + 25, (fieldW - 6) / 2, 18, "[ Settings ]", (btn) -> this.openSettings(), -11141121, -1, true));
      this.method_37063(new Button(leftX + (fieldW - 6) / 2 + 6, leftY + 25, (fieldW - 6) / 2, 18, "[ HUD ]", (btn) -> this.field_22787.method_1507(new HudEditScreen(this)), -22016, -1, true));
      this.method_37063(new Button(leftX, leftY + 48, fieldW, 18, "RESET SESSION STATS", (btn) -> SearchAutomationController.resetSessionStats(), -22016, -1, true));
      leftY += 75;
      int toggleW = (fieldW - 6) / 2;
      this.method_37063(new ToggleButton(leftX, leftY, toggleW, 18, () -> BkRynekClient.isSniperMode ? "SNIPER" : "SCANNER", (btn) -> BkRynekClient.isSniperMode = !BkRynekClient.isSniperMode, () -> BkRynekClient.isSniperMode ? -22016 : -11141121));
      this.method_37063(new ToggleButton(leftX + toggleW + 6, leftY, toggleW, 18, () -> BkRynekClient.isSumMode ? "SUM" : "UNIT", (btn) -> BkRynekClient.isSumMode = !BkRynekClient.isSumMode, () -> BkRynekClient.isSumMode ? -171 : -12255420));
      leftY += 45;
      if (this.currentServer != null) {
         this.method_37063(new Slider(leftX, leftY, fieldW, 14, "Refresh Rate", this.currentServer.marketNextDelayMs != null ? (double)this.currentServer.marketNextDelayMs : (double)300.0F, (double)50.0F, (double)2000.0F, "ms", (v) -> this.currentServer.marketNextDelayMs = v.intValue()));
         leftY += 32;
         this.method_37063(new Slider(leftX, leftY, fieldW, 14, "Confirm Delay", this.currentServer.marketConfirmDelayMs != null ? (double)this.currentServer.marketConfirmDelayMs : (double)250.0F, (double)20.0F, (double)1000.0F, "ms", (v) -> this.currentServer.marketConfirmDelayMs = v.intValue()));
         int labelWidth = this.field_22793.method_1727("Confirm Delay");
         int var10003 = leftX + labelWidth + 4;
         int var10004 = leftY - 12;
         int var10007 = this.currentServer.marketConfirmAttempts != null ? this.currentServer.marketConfirmAttempts : 1;
         this.method_37063(new Button(var10003, var10004, 24, 11, "x" + var10007, (btn) -> {
            int current = this.currentServer.marketConfirmAttempts != null ? this.currentServer.marketConfirmAttempts : 1;
            int next = current % 5 + 1;
            this.currentServer.marketConfirmAttempts = next;
            ((Button)btn).update("x" + next);
         }, -22016, -1, false));
         leftY += 32;
         this.method_37063(new Slider(leftX, leftY, fieldW, 14, "Restart Delay", this.currentServer.marketRestartDelayMs != null ? (double)this.currentServer.marketRestartDelayMs : (double)500.0F, (double)100.0F, (double)5000.0F, "ms", (v) -> this.currentServer.marketRestartDelayMs = v.intValue()));
         int restartLabelWidth = this.field_22793.method_1727("Restart Delay");
         var10003 = leftX + restartLabelWidth + 4;
         var10004 = leftY - 12;
         var10007 = this.currentServer.marketOpenAttempts != null ? this.currentServer.marketOpenAttempts : 1;
         this.method_37063(new Button(var10003, var10004, 24, 11, "x" + var10007, (btn) -> {
            int current = this.currentServer.marketOpenAttempts != null ? this.currentServer.marketOpenAttempts : 1;
            int next = current % 5 + 1;
            this.currentServer.marketOpenAttempts = next;
            ((Button)btn).update("x" + next);
         }, -22016, -1, false));
         leftY += 32;
         this.method_37063(new Slider(leftX, leftY, fieldW, 14, "Action Delay", this.currentServer.marketActionDelayMs != null ? (double)this.currentServer.marketActionDelayMs : (double)50.0F, (double)0.0F, (double)500.0F, "ms", (v) -> this.currentServer.marketActionDelayMs = v.intValue()));
      }

      int rightX = this.panelX + this.leftPanelW + this.margin;
      int rightY = this.panelY + 56;
      int rightW = this.panelW - this.leftPanelW - this.margin * 2;
      this.searchField = new class_342(this.field_22793, rightX, rightY, rightW, 16, class_2561.method_30163(""));
      this.searchField.method_47404(class_2561.method_30163("§8Search items..."));
      this.searchField.method_1858(false);
      this.searchField.method_1852(this.searchQuery);
      this.searchField.method_1863((s) -> {
         this.searchQuery = s;
         this.scrollOffset = (double)0.0F;
      });
      this.method_37063(this.searchField);
      int tabY = rightY + 24;
      int tabW = (rightW - 4) / 2;
      this.method_37063(new ToggleButton(rightX, tabY, tabW, 16, () -> "BUYING", (btn) -> {
         this.showSellTab = false;
         this.scrollOffset = (double)0.0F;
      }, () -> !this.showSellTab ? -12255420 : -10066330));
      this.method_37063(new ToggleButton(rightX + tabW + 4, tabY, tabW, 16, () -> "SELLING", (btn) -> {
         this.showSellTab = true;
         this.scrollOffset = (double)0.0F;
      }, () -> this.showSellTab ? -22016 : -10066330));
      this.method_37063(new Button(this.panelX + this.panelW - 90, this.panelY + this.panelH - 25, 80, 18, "+ ADD ITEM", (btn) -> {
         PriceEntry template = new PriceEntry();
         template.buyEnabled = !this.showSellTab;
         template.sellEnabled = this.showSellTab;
         this.field_22787.method_1507(new AddItemScreen(this, template, (success) -> this.method_25426()));
      }, -12255420, false));
      this.method_37063(new Button(this.panelX + this.panelW - 16, this.panelY + 4, 12, 12, "X", (btn) -> this.method_25419(), -48060, false));
   }

   public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
      context.method_25294(0, 0, this.field_22789, this.field_22790, -1442840576);
      Panel.drawPanel(context, this.panelX, this.panelY, this.panelW, this.panelH, 10);
      Panel.drawHeader(context, this.panelX, this.panelY, this.panelW, 24);
      Panel.drawTrafficLights(context, this.panelX + 10, this.panelY + 11);
      context.method_25294(this.panelX + this.leftPanelW, this.panelY + 24, this.panelX + this.leftPanelW + 1, this.panelY + this.panelH - 5, -13421773);
      context.method_51433(this.field_22793, "BK-RYNEK v2.6", this.panelX + 45, this.panelY + 8, -1, false);
      boolean isActive = ToggleScanner.scanningEnabled;
      String statusText = isActive ? "• ACTIVE" : "• READY";
      int statusColor = isActive ? -12255420 : -10066330;
      context.method_51433(this.field_22793, statusText, this.panelX + this.panelW - 80, this.panelY + 11, statusColor, false);
      Panel.drawSectionHeader(context, this.panelX + this.margin, this.panelY + 30, this.leftPanelW - this.margin * 2, "CONFIG");
      Panel.drawSectionHeader(context, this.panelX + this.leftPanelW + this.margin, this.panelY + 30, this.panelW - this.leftPanelW - this.margin * 2, "ITEM REGISTRY");
      this.renderItemList(context, mouseX, mouseY);
      int footerY = this.panelY + this.panelH - 24;
      String footerText = "bkubiak.dev/mods";
      int textWidth = this.field_22793.method_1727(footerText);
      int linkX = this.panelX + this.margin;
      int linkY = footerY + 5;
      boolean linkHovered = mouseX >= linkX && mouseX <= linkX + textWidth && mouseY >= linkY && mouseY <= linkY + 9;
      int linkColor = linkHovered ? -1 : -10066330;
      context.method_51433(this.field_22793, footerText, linkX, linkY, linkColor, false);
      if (linkHovered) {
         context.method_25294(linkX, linkY + 9, linkX + textWidth, linkY + 10, linkColor);
      }

      super.method_25394(context, mouseX, mouseY, delta);
   }

   private void renderItemList(class_332 context, int mouseX, int mouseY) {
      int listX = this.panelX + this.leftPanelW + this.margin;
      int listY = this.panelY + 106;
      int listW = this.panelW - this.leftPanelW - this.margin * 2;
      int listH = this.panelH - 140;
      context.method_25294(listX, this.panelY + 73, listX + listW, this.panelY + 74, 369098751);
      String profileName = ClientPriceListManager.getActiveProfile();
      List<PriceEntry> allEntries = (List)ClientPriceListManager.getAllProfiles().get(profileName);
      List<PriceEntry> entries = this.getFilteredEntries(allEntries);
      if (entries != null && !entries.isEmpty()) {
         int totalHeight = entries.size() * this.rowHeight;
         if (this.scrollOffset < (double)0.0F) {
            this.scrollOffset = (double)0.0F;
         }

         if (totalHeight > listH) {
            if (this.scrollOffset > (double)(totalHeight - listH)) {
               this.scrollOffset = (double)(totalHeight - listH);
            }
         } else {
            this.scrollOffset = (double)0.0F;
         }

         context.method_44379(listX, listY, listX + listW, listY + listH);

         for(int i = 0; i < entries.size(); ++i) {
            PriceEntry entry = (PriceEntry)entries.get(i);
            int rowY = listY + i * this.rowHeight - (int)this.scrollOffset;
            if (rowY + this.rowHeight >= listY && rowY <= listY + listH) {
               boolean hovered = mouseX >= listX && mouseX <= listX + listW && mouseY >= rowY && mouseY < rowY + this.rowHeight;
               if (hovered) {
                  context.method_25294(listX, rowY, listX + listW, rowY + this.rowHeight, 369098751);
               } else if (i % 2 == 0) {
                  context.method_25294(listX, rowY, listX + listW, rowY + this.rowHeight, 150994943);
               }

               class_1799 stack = this.createItemStack(entry);
               if (stack != null) {
                  context.method_51427(stack, listX + 2, rowY + 5);
               }

               String name = entry.name != null && !entry.name.isEmpty() ? entry.name : "§7" + entry.material;
               context.method_51433(this.field_22793, name, listX + 22, rowY + 4, -1, false);
               double price = this.showSellTab ? entry.sellPrice : entry.maxPrice;
               int qty = this.showSellTab ? (entry.sellCount != null ? entry.sellCount : 1) : (entry.requiredCount != null ? entry.requiredCount : 1);
               int color = this.showSellTab ? -22016 : -12255420;
               String var10000 = this.showSellTab ? "§6" : "§a";
               String priceText = var10000 + PriceFormatter.formatPrice(price);
               if (qty > 1) {
                  priceText = priceText + " §8(min " + qty + ")";
               }

               context.method_51433(this.field_22793, priceText, listX + 22, rowY + 14, color, false);
               if (hovered) {
                  context.method_51433(this.field_22793, "§c✖", listX + listW - 15, rowY + 8, -48060, false);
               }
            }
         }

         context.method_44380();
         if (totalHeight > listH) {
            float vp = (float)listH / (float)totalHeight;
            float sp = (float)this.scrollOffset / (float)(totalHeight - listH);
            boolean barHovered = mouseX >= this.panelX + this.panelW - 10 && mouseX <= this.panelX + this.panelW && mouseY >= listY && mouseY <= listY + listH;
            Panel.drawScrollbar(context, this.panelX + this.panelW - 5, listY, 3, listH, sp, vp, barHovered || this.isScrolling);
         }

      } else {
         context.method_51433(this.field_22793, "No " + (this.showSellTab ? "sell" : "buy") + " items.", listX, listY + 10, -10066330, false);
      }
   }

   private class_1799 createItemStack(PriceEntry entry) {
      if (entry != null && entry.material != null) {
         try {
            class_2960 id = class_2960.method_60654(entry.material);
            if (class_7923.field_41178.method_10250(id)) {
               class_1799 stack = new class_1799((class_1935)class_7923.field_41178.method_63535(id));
               if (entry.customModelData != null) {
                  try {
                     stack.method_57379(class_9334.field_49637, new class_9280(List.of(entry.customModelData.floatValue()), List.of(), List.of(), List.of()));
                  } catch (Exception var5) {
                  }
               }

               return stack;
            }
         } catch (Exception var6) {
         }

         return null;
      } else {
         return null;
      }
   }

   public boolean method_25402(double mouseX, double mouseY, int button) {
      int footerY = this.panelY + this.panelH - 24;
      String footerText = "bkubiak.dev/mods";
      int textWidth = this.field_22793.method_1727(footerText);
      int linkX = this.panelX + this.margin;
      int linkY = footerY + 5;
      if (mouseX >= (double)linkX && mouseX <= (double)(linkX + textWidth) && mouseY >= (double)linkY && mouseY <= (double)(linkY + 9)) {
         class_156.method_668().method_670("https://bkubiak.dev/mods");
         return true;
      } else if (super.method_25402(mouseX, mouseY, button)) {
         return true;
      } else {
         int listX = this.panelX + this.leftPanelW + this.margin;
         int listY = this.panelY + 106;
         int listW = this.panelW - this.leftPanelW - this.margin * 2;
         int listH = this.panelH - 140;
         if (this.searchField != null && this.searchField.method_25402(mouseX, mouseY, button)) {
            this.method_25395(this.searchField);
            return true;
         } else {
            String profileName = ClientPriceListManager.getActiveProfile();
            List<PriceEntry> allEntries = (List)ClientPriceListManager.getAllProfiles().get(profileName);
            List<PriceEntry> entries = this.getFilteredEntries(allEntries);
            if (entries != null && !entries.isEmpty()) {
               int totalHeight = entries.size() * this.rowHeight;
               if (totalHeight > listH && mouseX >= (double)(this.panelX + this.panelW - 12) && mouseX <= (double)(this.panelX + this.panelW) && mouseY >= (double)listY && mouseY <= (double)(listY + listH)) {
                  this.isScrolling = true;
                  return true;
               }
            }

            if (entries != null) {
               for(int i = 0; i < entries.size(); ++i) {
                  int rowY = listY + i * this.rowHeight - (int)this.scrollOffset;
                  if (mouseY >= (double)listY && mouseY < (double)(listY + listH) && mouseX >= (double)listX && mouseX <= (double)(listX + listW) && mouseY >= (double)rowY && mouseY < (double)(rowY + this.rowHeight)) {
                     if (mouseX >= (double)(listX + listW - 20)) {
                        ClientPriceListManager.removePriceEntry((PriceEntry)entries.get(i));
                        ClientCommandRegistration.syncMemoryToConfig();
                        CoreConfigLoader.saveFullConfigObject(BkRynekClient.serversConfig);
                        this.method_25426();
                     } else {
                        this.field_22787.method_1507(new AddItemScreen(this, (PriceEntry)entries.get(i), (success) -> this.method_25426()));
                     }

                     return true;
                  }
               }
            }

            return false;
         }
      }
   }

   public boolean method_25406(double mouseX, double mouseY, int button) {
      this.isScrolling = false;
      return super.method_25406(mouseX, mouseY, button);
   }

   public boolean method_25404(int keyCode, int scanCode, int modifiers) {
      if (this.searchField != null && this.searchField.method_25404(keyCode, scanCode, modifiers)) {
         return true;
      } else {
         return this.searchField != null && this.searchField.method_25370() && keyCode != 256 ? true : super.method_25404(keyCode, scanCode, modifiers);
      }
   }

   public boolean method_25400(char chr, int modifiers) {
      return this.searchField != null && this.searchField.method_25400(chr, modifiers) ? true : super.method_25400(chr, modifiers);
   }

   public boolean method_25403(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
      if (this.isScrolling) {
         int listH = this.panelH - 140;
         String profileName = ClientPriceListManager.getActiveProfile();
         List<PriceEntry> allEntries = (List)ClientPriceListManager.getAllProfiles().get(profileName);
         List<PriceEntry> entries = this.getFilteredEntries(allEntries);
         if (entries != null) {
            int totalHeight = entries.size() * this.rowHeight;
            if (totalHeight > listH) {
               int thumbHeight = Math.max(10, (int)((float)listH * ((float)listH / (float)totalHeight)));
               double travelDistance = (double)(listH - thumbHeight);
               double contentDistance = (double)(totalHeight - listH);
               double ratio = travelDistance > (double)0.0F ? contentDistance / travelDistance : contentDistance / (double)listH;
               this.scrollOffset += deltaY * ratio;
               if (this.scrollOffset < (double)0.0F) {
                  this.scrollOffset = (double)0.0F;
               }

               if (this.scrollOffset > (double)(totalHeight - listH)) {
                  this.scrollOffset = (double)(totalHeight - listH);
               }
            }
         }

         return true;
      } else {
         return super.method_25403(mouseX, mouseY, button, deltaX, deltaY);
      }
   }

   public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
      String profileName = ClientPriceListManager.getActiveProfile();
      List<PriceEntry> allEntries = (List)ClientPriceListManager.getAllProfiles().get(profileName);
      List<PriceEntry> entries = this.getFilteredEntries(allEntries);
      if (entries != null) {
         int listH = this.panelH - 140;
         int totalHeight = entries.size() * this.rowHeight;
         if (totalHeight > listH) {
            double speed = (double)15.0F;
            this.scrollOffset -= verticalAmount * speed;
            if (this.scrollOffset < (double)0.0F) {
               this.scrollOffset = (double)0.0F;
            }

            if (this.scrollOffset > (double)(totalHeight - listH)) {
               this.scrollOffset = (double)(totalHeight - listH);
            }

            return true;
         }
      }

      return super.method_25401(mouseX, mouseY, horizontalAmount, verticalAmount);
   }

   private List<PriceEntry> getFilteredEntries(List<PriceEntry> all) {
      if (all == null) {
         return Collections.emptyList();
      } else {
         String query = this.searchQuery.toLowerCase();
         return (List)all.stream().filter((pe) -> {
            boolean entryBuy = pe.buyEnabled != null ? pe.buyEnabled : true;
            boolean entrySell = pe.sellEnabled != null ? pe.sellEnabled : false;
            if (this.showSellTab) {
               if (!entrySell) {
                  return false;
               }
            } else if (!entryBuy) {
               return false;
            }

            if (query.isEmpty()) {
               return true;
            } else {
               String name = pe.name != null ? pe.name.toLowerCase() : "";
               String material = pe.material != null ? pe.material.toLowerCase() : "";
               return name.contains(query) || material.contains(query);
            }
         }).collect(Collectors.toList());
      }
   }

   private void openSettings() {
      if (SearchAutomationController.isActive()) {
         SearchAutomationController.cancel();
         ToastManager.show("§eAutomation stopped for config editing", 16763904);
      }

      ClientCommandRegistration.syncMemoryToConfig();
      this.method_25419();
      class_310.method_1551().method_1507(new ConfigEditorScreen());
   }

   public void method_25419() {
      if (BkRynekClient.serversConfig != null) {
         ClientCommandRegistration.syncMemoryToConfig();
      }

      super.method_25419();
   }

   public boolean method_25421() {
      return false;
   }
}
