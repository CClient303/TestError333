package pl.bkubiak.bkrynek.client.gui;

import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import pl.bkubiak.bkrynek.client.BkRynekClient;
import pl.bkubiak.bkrynek.client.gui.widgets.Panel;
import pl.bkubiak.bkrynek.client.util.SearchAutomationController;
import pl.bkubiak.bkrynek.core.util.PriceFormatter;

@Environment(EnvType.CLIENT)
public class SearchHudOverlay {
   private static final int HEIGHT = 72;

   public static void render(class_332 context) {
      if (SearchAutomationController.isActive()) {
         class_310 client = class_310.method_1551();
         class_327 tr = client.field_1772;
         String status = SearchAutomationController.getCurrentStatus();
         double curBal = SearchAutomationController.getCurrentBalance();
         double profit = SearchAutomationController.getSessionProfit();
         String saldoText = PriceFormatter.formatPrice(Math.abs(profit));
         if (profit < (double)0.0F) {
            saldoText = "-" + saldoText;
         } else if (profit > (double)0.0F) {
            saldoText = "+" + saldoText;
         }

         long elapsedSecs = (System.currentTimeMillis() - SearchAutomationController.getSessionStartTime()) / 1000L;
         String timeStr = String.format("%02d:%02d", elapsedSecs / 60L, elapsedSecs % 60L);
         int dynamicWidth = 150;
         int hudHeight = 86;
         int hudX = BkRynekClient.serversConfig.hudX;
         int hudY = BkRynekClient.serversConfig.hudY;
         Panel.drawRoundedRect(context, hudX, hudY, dynamicWidth, hudHeight, 4, -301002990);
         Panel.drawCircle(context, hudX + 10, hudY + 10, 3, status.equals("BUYING") ? -48060 : -12255420);
         context.method_51433(tr, "BK-Rynek", hudX + 18, hudY + 7, -1, false);
         context.method_51433(tr, timeStr, hudX + dynamicWidth - tr.method_1727(timeStr) - 8, hudY + 7, -10066330, false);
         int boxW = (dynamicWidth - 32) / 3;
         int boxY = hudY + 22;
         long marketOpenTime = SearchAutomationController.getMarketContinuousOpenTime();
         int footY = hudY + hudHeight - 14;
         if (marketOpenTime > 0L) {
            long now = System.currentTimeMillis();
            float progress = Math.min(1.0F, (float)(now - marketOpenTime) / 5000.0F);
            int barW = (int)((float)dynamicWidth * progress);
            if (barW > 0) {
               context.method_25294(hudX, hudY + hudHeight - 1, hudX + barW, hudY + hudHeight, -12255420);
            }

            if (progress < 1.0F) {
               String waitStr = String.format("%.1fs / 5s", (float)(now - marketOpenTime) / 1000.0F);
               context.method_51433(tr, waitStr, hudX + dynamicWidth - tr.method_1727(waitStr) - 8, footY, -10066330, false);
            }
         }

         drawStatBox(context, hudX + 8, boxY, boxW, 24, "Bought", String.valueOf(SearchAutomationController.getSessionBought()), -12255420);
         drawStatBox(context, hudX + 8 + boxW + 8, boxY, boxW, 24, "Sold", String.valueOf(SearchAutomationController.getSessionSold()), -22016);
         drawStatBox(context, hudX + dynamicWidth - boxW - 8, boxY, boxW, 24, "Listed", String.valueOf(SearchAutomationController.getSessionListed()), -11141121);
         int saldoY = hudY + 52;
         Panel.drawRoundedRect(context, hudX + 8, saldoY, dynamicWidth - 16, 14, 2, 369098751);
         context.method_51433(tr, "Profit:", hudX + 14, saldoY + 4, -5592406, false);
         int saldoColor = profit >= (double)0.0F ? -12255420 : -48060;
         context.method_51433(tr, saldoText, hudX + dynamicWidth - tr.method_1727(saldoText) - 14, saldoY + 4, saldoColor, false);
         footY = hudY + hudHeight - 14;
         String walletText = PriceFormatter.formatPrice(curBal);
         context.method_51433(tr, "$ Wallet: " + walletText, hudX + 8, footY, -22016, false);
         renderSnipeLog(context, tr);
      }
   }

   private static void renderSnipeLog(class_332 context, class_327 tr) {
      int x = BkRynekClient.serversConfig.logX;
      int y = BkRynekClient.serversConfig.logY;
      if (x == 0 && y == 0) {
         x = BkRynekClient.serversConfig.hudX;
         y = BkRynekClient.serversConfig.hudY + 72 + 20;
      }

      List<SearchAutomationController.SnipeEntry> history = SearchAutomationController.getSnipeHistory();
      if (history != null && !history.isEmpty()) {
         int width = 160;
         int rowHeight = 12;
         int logHeight = 22 + history.size() * rowHeight;
         Panel.drawRoundedRect(context, x, y, width, logHeight, 4, -301266162);
         context.method_51433(tr, "✦ SNIPE LOG", x + 8, y + 6, -1392384, false);
         long now = System.currentTimeMillis();

         for(int i = 0; i < history.size(); ++i) {
            SearchAutomationController.SnipeEntry entry = (SearchAutomationController.SnipeEntry)history.get(i);
            int rowY = y + 18 + i * rowHeight;
            long diff = (now - entry.timestamp) / 1000L;
            String var10000 = diff < 60L ? diff + "s" : (diff < 3600L ? diff / 60L + "m" : diff / 3600L + "h");
            String timeAgo = var10000 + " ago";
            int timeW = tr.method_1727(timeAgo);
            String countStr = " x" + entry.count;
            int countW = tr.method_1727(countStr);
            String price = "$" + PriceFormatter.formatPrice(entry.price);
            int priceW = tr.method_1727(price);
            int maxNameW = width - 16 - priceW - timeW - countW - 8;
            String name = entry.name;
            if (tr.method_1727(name) > maxNameW) {
               while(name.length() > 0 && tr.method_1727(name + "...") > maxNameW) {
                  name = name.substring(0, name.length() - 1);
               }

               name = name + "...";
            }

            context.method_51433(tr, name, x + 8, rowY, -1, false);
            context.method_51433(tr, countStr, x + 8 + tr.method_1727(name), rowY, -22016, false);
            context.method_51433(tr, price, x + 8 + tr.method_1727(name) + countW + 4, rowY, -12255420, false);
            context.method_51433(tr, timeAgo, x + width - timeW - 8, rowY, -5592406, false);
         }

      }
   }

   private static void drawStatBox(class_332 ctx, int x, int y, int w, int h, String label, String value, int accent) {
      Panel.drawRoundedRect(ctx, x, y, w, h, 2, 150994943);
      ctx.method_25294(x, y + 2, x + 2, y + h - 2, accent);
      class_327 tr = class_310.method_1551().field_1772;
      ctx.method_51433(tr, value, x + 6, y + 4, -1, false);
      ctx.method_51433(tr, label, x + 6, y + 14, -10066330, false);
   }
}
