package pl.bkubiak.bkrynek.client.gui.widgets;

import java.util.function.Supplier;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_4185;

@Environment(EnvType.CLIENT)
public class ToggleButton extends class_4185 {
   private final Supplier<String> textSupplier;
   private final Supplier<Integer> colorSupplier;

   public ToggleButton(int x, int y, int width, int height, Supplier<String> textSupplier, class_4185.class_4241 onPress, Supplier<Integer> colorSupplier) {
      super(x, y, width, height, class_2561.method_30163(""), onPress, field_40754);
      this.textSupplier = textSupplier;
      this.colorSupplier = colorSupplier;
   }

   protected void method_48579(class_332 context, int mouseX, int mouseY, float delta) {
      int color = (Integer)this.colorSupplier.get();
      String txt = (String)this.textSupplier.get();
      class_327 tr = class_310.method_1551().field_1772;
      boolean hovered = this.method_49606();
      Panel.drawRoundedRect(context, this.method_46426() + 2, this.method_46427() + this.field_22759 - 2, this.field_22758 - 4, 1, 1, color);
      int textColor = hovered ? -1 : -855638017;
      int textX = this.method_46426() + (this.field_22758 - tr.method_1727(txt)) / 2;
      int textY = this.method_46427() + (this.field_22759 - 8) / 2;
      context.method_51433(tr, txt, textX, textY, textColor, false);
   }
}
