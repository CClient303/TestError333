package pl.bkubiak.bkrynek.client.gui.widgets;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;

@Environment(EnvType.CLIENT)
public final class Panel {
   private Panel() {
   }

   public static void drawPanel(class_332 ctx, int x, int y, int w, int h, int r) {
      drawRoundedRect(ctx, x, y, w, h, r, -233894129);
      drawRoundedRectOutline(ctx, x, y, w, h, r, -14540254);
   }

   public static void drawHeader(class_332 ctx, int x, int y, int w, int h) {
      drawRoundedRect(ctx, x + 6, y + 1, w - 12, h - 1, 3, -15395563);
      ctx.method_25294(x + 1, y + h, x + w - 1, y + h + 1, -13421773);
   }

   public static void drawTrafficLights(class_332 ctx, int x, int y) {
      drawCircle(ctx, x, y, 2, -48060);
      drawCircle(ctx, x + 6, y, 2, -188);
      drawCircle(ctx, x + 12, y, 2, -12255420);
   }

   public static void drawCard(class_332 ctx, int x, int y, int w, int h, String title, String desc, float fade) {
      int baseAlpha = (int)(fade * 255.0F);
      int cardBg = baseAlpha << 24 | 1381653;
      int border = baseAlpha << 24 | 3355443;
      drawRoundedRect(ctx, x, y, w, h, 3, cardBg);
      drawRoundedRectOutline(ctx, x, y, w, h, 3, border);
      class_327 tr = class_310.method_1551().field_1772;
      int mainColor = baseAlpha << 24 | 16777215;
      int dimColor = baseAlpha << 24 | 6710886;
      ctx.method_51433(tr, title, x + 6, y + 6, mainColor, false);
      ctx.method_51433(tr, desc, x + 6, y + 17, dimColor, false);
   }

   public static void drawSectionHeader(class_332 ctx, int x, int y, int w, String label) {
      class_327 tr = class_310.method_1551().field_1772;
      ctx.method_51433(tr, label, x, y, -5592406, false);
      ctx.method_25294(x, y + 12, x + w, y + 13, 301989887);
   }

   public static void drawScrollbar(class_332 ctx, int x, int y, int w, int h, float scrollPercentage, float visiblePercentage, boolean hovered) {
      ctx.method_25294(x, y, x + w, y + h, 805306368);
      int thumbHeight = Math.max(10, (int)((float)h * visiblePercentage));
      int thumbY = y + (int)((float)(h - thumbHeight) * scrollPercentage);
      int thumbColor = hovered ? -5592406 : -2138535800;
      ctx.method_25294(x, thumbY, x + w, thumbY + thumbHeight, thumbColor);
   }

   public static void drawRoundedRect(class_332 context, int x, int y, int w, int h, int r, int color) {
      context.method_25294(x + r, y, x + w - r, y + h, color);
      context.method_25294(x, y + r, x + w, y + h - r, color);
      drawCircleQuarter(context, x + r, y + r, r, 0, color);
      drawCircleQuarter(context, x + w - r, y + r, r, 1, color);
      drawCircleQuarter(context, x + r, y + h - r, r, 2, color);
      drawCircleQuarter(context, x + w - r, y + h - r, r, 3, color);
   }

   public static void drawRoundedRectOutline(class_332 context, int x, int y, int w, int h, int r, int color) {
      context.method_25294(x + r, y, x + w - r, y + 1, color);
      context.method_25294(x + r, y + h - 1, x + w - r, y + h, color);
      context.method_25294(x, y + r, x + 1, y + h - r, color);
      context.method_25294(x + w - 1, y + r, x + w, y + h - r, color);
      drawCircleQuarterOutline(context, x + r, y + r, r, 0, color);
      drawCircleQuarterOutline(context, x + w - r, y + r, r, 1, color);
      drawCircleQuarterOutline(context, x + r, y + h - r, r, 2, color);
      drawCircleQuarterOutline(context, x + w - r, y + h - r, r, 3, color);
   }

   public static void drawCircleQuarter(class_332 context, int centerX, int centerY, int radius, int quarter, int color) {
      int r2 = radius * radius;

      for(int i = 1; i <= radius; ++i) {
         for(int j = 1; j <= radius; ++j) {
            if (i * i + j * j < r2) {
               drawCornerPixelSimple(context, centerX, centerY, i, j, quarter, color);
            }
         }
      }

   }

   public static void drawCircleQuarterOutline(class_332 context, int centerX, int centerY, int radius, int quarter, int color) {
      int r2 = radius * radius;

      for(int i = 0; i <= radius; ++i) {
         int j = (int)Math.round(Math.sqrt((double)Math.max(0, r2 - i * i)));
         if (i <= radius && j <= radius) {
            drawCornerPixelSimple(context, centerX, centerY, i, j, quarter, color);
            drawCornerPixelSimple(context, centerX, centerY, j, i, quarter, color);
         }
      }

   }

   private static void drawCornerPixelSimple(class_332 context, int cx, int cy, int dx, int dy, int q, int c) {
      int px = 0;
      int py = 0;
      if (q == 0) {
         px = cx - dx;
         py = cy - dy;
      } else if (q == 1) {
         px = cx + dx - 1;
         py = cy - dy;
      } else if (q == 2) {
         px = cx - dx;
         py = cy + dy - 1;
      } else if (q == 3) {
         px = cx + dx - 1;
         py = cy + dy - 1;
      }

      context.method_25294(px, py, px + 1, py + 1, c);
   }

   public static void drawCircle(class_332 context, int x, int y, int radius, int color) {
      int r2 = radius * radius;

      for(int dx = -radius; dx <= radius; ++dx) {
         for(int dy = -radius; dy <= radius; ++dy) {
            if (dx * dx + dy * dy < r2) {
               context.method_25294(x + dx, y + dy, x + dx + 1, y + dy + 1, color);
            }
         }
      }

   }
}
