package pl.bkubiak.bkrynek.client.gui.widgets;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_4185;

@Environment(EnvType.CLIENT)
public class TabButton extends class_4185 {
   private final boolean active;
   private float hoverAnim = 0.0F;

   public TabButton(int x, int y, int width, int height, String text, boolean active, class_4185.class_4241 onPress) {
      super(x, y, width, height, class_2561.method_30163(text), onPress, field_40754);
      this.active = active;
   }

   protected void method_48579(class_332 context, int mouseX, int mouseY, float delta) {
      if (this.method_49606() && this.hoverAnim < 1.0F) {
         this.hoverAnim = Math.min(1.0F, this.hoverAnim + delta * 0.2F);
      } else if (!this.method_49606() && this.hoverAnim > 0.0F) {
         this.hoverAnim = Math.max(0.0F, this.hoverAnim - delta * 0.15F);
      }

      int textColor = this.active ? -1 : Colors.interpolate(-10066330, -5592406, this.hoverAnim);
      class_327 tr = class_310.method_1551().field_1772;
      int tx = this.method_46426() + (this.field_22758 - tr.method_27525(this.method_25369())) / 2;
      int ty = this.method_46427() + (this.field_22759 - 8) / 2;
      context.method_51439(tr, this.method_25369(), tx, ty, textColor, false);
      if (this.active || this.hoverAnim > 0.0F) {
         float lineFade = this.active ? 1.0F : this.hoverAnim;
         int lineAlpha = (int)(lineFade * 255.0F);
         int lineColor = lineAlpha << 24 | 16777215;
         context.method_25294(this.method_46426(), this.method_46427() + this.field_22759 - 1, this.method_46426() + this.field_22758, this.method_46427() + this.field_22759, lineColor);
      }

   }
}
