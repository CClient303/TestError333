package pl.bkubiak.bkrynek.client.gui.widgets;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_437;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.system.MemoryUtil;

@Environment(EnvType.CLIENT)
public class MultiLineEditor {
   private final List<String> lines;
   private final int x;
   private final int y;
   private final int width;
   private final int height;
   private int cursorLine = 0;
   private int cursorColumn = 0;
   private int scrollOffset = 0;
   private boolean focused = false;
   private long lastCursorBlink = 0L;
   private boolean cursorVisible = true;
   private int selectionStartLine = -1;
   private int selectionStartColumn = -1;
   private int selectionEndLine = -1;
   private int selectionEndColumn = -1;
   private boolean isDragging = false;
   private boolean isDraggingScrollbar = false;
   private static final int LINE_HEIGHT = 12;
   private static final int GUTTER_WIDTH = 50;
   private static final int PADDING = 8;
   private List<String> undoStack = new ArrayList();
   private int undoIndex = -1;

   public MultiLineEditor(int x, int y, int width, int height, String initialText) {
      this.x = x;
      this.y = y;
      this.width = width;
      this.height = height;
      this.lines = new ArrayList();
      if (initialText != null && !initialText.isEmpty()) {
         String[] splitLines = initialText.split("\\n", -1);

         for(String line : splitLines) {
            this.lines.add(line);
         }
      } else {
         this.lines.add("");
      }

      this.saveUndoState();
   }

   public void render(class_332 context, class_327 textRenderer, int mouseX, int mouseY) {
      Panel.drawRoundedRect(context, this.x, this.y, this.width, this.height, 4, -233894129);
      context.method_25294(this.x, this.y, this.x + 50, this.y + this.height, 536870912);
      context.method_25294(this.x + 50, this.y, this.x + 50 + 1, this.y + this.height, -13421773);
      int visibleLines = (this.height - 16) / 12;
      int maxScroll = Math.max(0, this.lines.size() - visibleLines);
      this.scrollOffset = class_3532.method_15340(this.scrollOffset, 0, maxScroll);

      for(int i = 0; i < Math.min(visibleLines + 1, this.lines.size() - this.scrollOffset); ++i) {
         int lineIndex = i + this.scrollOffset;
         int lineY = this.y + 8 + i * 12;
         String lineNum = String.valueOf(lineIndex + 1);
         int numX = this.x + 50 - textRenderer.method_1727(lineNum) - 8;
         context.method_51433(textRenderer, lineNum, numX, lineY, -10066330, false);
      }

      context.method_44379(this.x + 50 + 1, this.y, this.x + this.width, this.y + this.height);

      for(int i = 0; i < Math.min(visibleLines + 1, this.lines.size() - this.scrollOffset); ++i) {
         int lineIndex = i + this.scrollOffset;
         int lineY = this.y + 8 + i * 12;
         if (this.focused && lineIndex == this.cursorLine && !this.hasSelection()) {
            context.method_25294(this.x + 50 + 1, lineY - 1, this.x + this.width, lineY + 12 - 1, 369098751);
         }

         if (this.hasSelection() && lineIndex >= this.getSelectionMinLine() && lineIndex <= this.getSelectionMaxLine()) {
            int selStart = 0;
            int selEnd = ((String)this.lines.get(lineIndex)).length();
            if (lineIndex == this.getSelectionMinLine()) {
               selStart = this.getSelectionMinColumn();
            }

            if (lineIndex == this.getSelectionMaxLine()) {
               selEnd = this.getSelectionMaxColumn();
            }

            String lineText = (String)this.lines.get(lineIndex);
            int startX = this.x + 50 + 8 + textRenderer.method_1727(lineText.substring(0, Math.min(selStart, lineText.length())));
            int endX = this.x + 50 + 8 + textRenderer.method_1727(lineText.substring(0, Math.min(selEnd, lineText.length())));
            context.method_25294(startX, lineY - 1, endX, lineY + 12 - 1, 1079356159);
         }

         String lineText = (String)this.lines.get(lineIndex);
         context.method_51433(textRenderer, lineText, this.x + 50 + 8, lineY, -1, false);
         if (this.focused && lineIndex == this.cursorLine && this.cursorVisible && !this.hasSelection()) {
            long now = System.currentTimeMillis();
            if (now - this.lastCursorBlink > 530L) {
               this.cursorVisible = !this.cursorVisible;
               this.lastCursorBlink = now;
            }

            int cursorX = this.x + 50 + 8 + textRenderer.method_1727(lineText.substring(0, Math.min(this.cursorColumn, lineText.length())));
            context.method_25294(cursorX, lineY - 1, cursorX + 1, lineY + 12 - 2, -1);
         }
      }

      context.method_44380();
      Panel.drawRoundedRectOutline(context, this.x, this.y, this.width, this.height, 4, this.focused ? -11141121 : -14540254);
      if (this.lines.size() > visibleLines) {
         int scrollbarX = this.x + this.width - 6;
         int scrollbarY = this.y + 4;
         int scrollbarHeight = this.height - 8;
         float scrollPercentage = (float)this.scrollOffset / (float)Math.max(1, this.lines.size() - visibleLines);
         float visiblePercentage = (float)visibleLines / (float)this.lines.size();
         Panel.drawScrollbar(context, scrollbarX, scrollbarY, 4, scrollbarHeight, scrollPercentage, visiblePercentage, false);
      }

   }

   public boolean mouseClicked(int mouseX, int mouseY, int button) {
      if (mouseX >= this.x && mouseX <= this.x + this.width && mouseY >= this.y && mouseY <= this.y + this.height) {
         this.focused = true;
         int visibleLines = (this.height - 16) / 12;
         if (this.lines.size() > visibleLines) {
            int scrollbarX = this.x + this.width - 6;
            if (mouseX >= scrollbarX && mouseX <= scrollbarX + 4) {
               this.isDraggingScrollbar = true;
               this.updateScrollFromMouseY(mouseY, visibleLines);
               return true;
            }
         }

         int relativeY = mouseY - this.y - 8;
         int clickedLine = relativeY / 12 + this.scrollOffset;
         clickedLine = class_3532.method_15340(clickedLine, 0, this.lines.size() - 1);
         int relativeX = mouseX - this.x - 50 - 8;
         class_327 tr = class_310.method_1551().field_1772;
         String lineText = (String)this.lines.get(clickedLine);
         int clickedColumn = 0;

         for(int i = 0; i <= lineText.length(); clickedColumn = i++) {
            int w = tr.method_1727(lineText.substring(0, i));
            if (w > relativeX) {
               break;
            }
         }

         this.cursorLine = clickedLine;
         this.cursorColumn = Math.min(clickedColumn, lineText.length());
         if (!class_437.method_25442()) {
            this.clearSelection();
            this.isDragging = true;
            this.selectionStartLine = this.cursorLine;
            this.selectionStartColumn = this.cursorColumn;
         }

         this.resetCursorBlink();
         return true;
      } else {
         this.focused = false;
         return false;
      }
   }

   public boolean mouseDragged(int mouseX, int mouseY) {
      if (this.isDraggingScrollbar) {
         int visibleLines = (this.height - 16) / 12;
         this.updateScrollFromMouseY(mouseY, visibleLines);
         return true;
      } else if (this.isDragging && this.focused) {
         int relativeY = mouseY - this.y - 8;
         int dragLine = relativeY / 12 + this.scrollOffset;
         dragLine = class_3532.method_15340(dragLine, 0, this.lines.size() - 1);
         int relativeX = mouseX - this.x - 50 - 8;
         class_327 tr = class_310.method_1551().field_1772;
         String lineText = (String)this.lines.get(dragLine);
         int dragColumn = 0;

         for(int i = 0; i <= lineText.length(); dragColumn = i++) {
            int w = tr.method_1727(lineText.substring(0, i));
            if (w > relativeX) {
               break;
            }
         }

         this.cursorLine = dragLine;
         this.cursorColumn = Math.min(dragColumn, lineText.length());
         this.selectionEndLine = this.cursorLine;
         this.selectionEndColumn = this.cursorColumn;
         return true;
      } else {
         return false;
      }
   }

   public boolean mouseReleased(int mouseX, int mouseY, int button) {
      this.isDragging = false;
      this.isDraggingScrollbar = false;
      return false;
   }

   public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
      if (mouseX >= (double)this.x && mouseX <= (double)(this.x + this.width) && mouseY >= (double)this.y && mouseY <= (double)(this.y + this.height)) {
         this.scrollOffset -= (int)verticalAmount * 3;
         int visibleLines = (this.height - 16) / 12;
         int maxScroll = Math.max(0, this.lines.size() - visibleLines);
         this.scrollOffset = class_3532.method_15340(this.scrollOffset, 0, maxScroll);
         return true;
      } else {
         return false;
      }
   }

   public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
      if (!this.focused) {
         return false;
      } else {
         boolean ctrl = class_437.method_25441();
         boolean shift = class_437.method_25442();
         String currentLine = (String)this.lines.get(this.cursorLine);
         if (ctrl && keyCode == 65) {
            this.selectAll();
            return true;
         } else {
            boolean movingCursor = false;
            int newLine = this.cursorLine;
            int newColumn = this.cursorColumn;
            switch (keyCode) {
               case 262:
                  if (newColumn < currentLine.length()) {
                     ++newColumn;
                  } else if (newLine < this.lines.size() - 1) {
                     ++newLine;
                     newColumn = 0;
                  }

                  movingCursor = true;
                  break;
               case 263:
                  if (newColumn > 0) {
                     --newColumn;
                  } else if (newLine > 0) {
                     --newLine;
                     newColumn = ((String)this.lines.get(newLine)).length();
                  }

                  movingCursor = true;
                  break;
               case 264:
                  if (newLine < this.lines.size() - 1) {
                     ++newLine;
                     newColumn = Math.min(newColumn, ((String)this.lines.get(newLine)).length());
                  }

                  movingCursor = true;
                  break;
               case 265:
                  if (newLine > 0) {
                     --newLine;
                     newColumn = Math.min(newColumn, ((String)this.lines.get(newLine)).length());
                  }

                  movingCursor = true;
               case 266:
               case 267:
               default:
                  break;
               case 268:
                  newColumn = 0;
                  movingCursor = true;
                  break;
               case 269:
                  newColumn = currentLine.length();
                  movingCursor = true;
            }

            if (movingCursor) {
               if (shift) {
                  if (!this.hasSelection()) {
                     this.selectionStartLine = this.cursorLine;
                     this.selectionStartColumn = this.cursorColumn;
                  }

                  this.cursorLine = newLine;
                  this.cursorColumn = newColumn;
                  this.selectionEndLine = this.cursorLine;
                  this.selectionEndColumn = this.cursorColumn;
               } else {
                  this.clearSelection();
                  this.cursorLine = newLine;
                  this.cursorColumn = newColumn;
               }

               this.ensureCursorVisible();
               this.resetCursorBlink();
               return true;
            } else {
               switch (keyCode) {
                  case 67:
                     if (ctrl) {
                        String textToCopy = this.hasSelection() ? this.getSelectedText() : (String)this.lines.get(this.cursorLine);
                        if (textToCopy != null && !textToCopy.isEmpty()) {
                           long windowHandle = class_310.method_1551().method_22683().method_4490();
                           ByteBuffer buffer = MemoryUtil.memUTF8(textToCopy);

                           try {
                              GLFW.glfwSetClipboardString(windowHandle, buffer);
                           } finally {
                              MemoryUtil.memFree(buffer);
                           }
                        }

                        return true;
                     }
                     break;
                  case 86:
                     if (ctrl) {
                        this.saveUndoState();
                        if (this.hasSelection()) {
                           this.deleteSelection();
                        }

                        String clipboardText = GLFW.glfwGetClipboardString(class_310.method_1551().method_22683().method_4490());
                        if (clipboardText != null && !clipboardText.isEmpty()) {
                           String[] pasteLines = clipboardText.split("\\r?\\n", -1);
                           if (pasteLines.length == 1) {
                              String updatedLine = ((String)this.lines.get(this.cursorLine)).substring(0, this.cursorColumn) + clipboardText + ((String)this.lines.get(this.cursorLine)).substring(this.cursorColumn);
                              this.lines.set(this.cursorLine, updatedLine);
                              this.cursorColumn += clipboardText.length();
                           } else {
                              currentLine = (String)this.lines.get(this.cursorLine);
                              String before = currentLine.substring(0, this.cursorColumn);
                              String after = currentLine.substring(this.cursorColumn);
                              this.lines.set(this.cursorLine, before + pasteLines[0]);

                              for(int i = 1; i < pasteLines.length - 1; ++i) {
                                 this.lines.add(this.cursorLine + i, pasteLines[i]);
                              }

                              int lastLineIndex = pasteLines.length - 1;
                              if (lastLineIndex > 0) {
                                 this.lines.add(this.cursorLine + lastLineIndex, pasteLines[lastLineIndex] + after);
                                 this.cursorLine += lastLineIndex;
                                 this.cursorColumn = pasteLines[lastLineIndex].length();
                              } else {
                                 this.cursorColumn += pasteLines[0].length();
                              }
                           }

                           this.resetCursorBlink();
                        }

                        return true;
                     }
                     break;
                  case 88:
                     if (ctrl && this.hasSelection()) {
                        this.saveUndoState();
                        GLFW.glfwSetClipboardString(class_310.method_1551().method_22683().method_4490(), this.getSelectedText());
                        this.deleteSelection();
                        return true;
                     }
                     break;
                  case 89:
                     if (ctrl) {
                        this.redo();
                        return true;
                     }
                     break;
                  case 90:
                     if (ctrl) {
                        this.undo();
                        return true;
                     }
                     break;
                  case 257:
                     this.saveUndoState();
                     if (this.hasSelection()) {
                        this.deleteSelection();
                     }

                     String before = ((String)this.lines.get(this.cursorLine)).substring(0, this.cursorColumn);
                     String after = ((String)this.lines.get(this.cursorLine)).substring(this.cursorColumn);
                     this.lines.set(this.cursorLine, before);
                     this.lines.add(this.cursorLine + 1, after);
                     ++this.cursorLine;
                     this.cursorColumn = 0;
                     this.ensureCursorVisible();
                     this.resetCursorBlink();
                     return true;
                  case 258:
                     this.saveUndoState();
                     if (this.hasSelection()) {
                        this.deleteSelection();
                     }

                     String tab = "  ";
                     List var30 = this.lines;
                     int var33 = this.cursorLine;
                     String var36 = ((String)this.lines.get(this.cursorLine)).substring(0, this.cursorColumn);
                     var30.set(var33, var36 + tab + ((String)this.lines.get(this.cursorLine)).substring(this.cursorColumn));
                     this.cursorColumn += tab.length();
                     this.resetCursorBlink();
                     return true;
                  case 259:
                     this.saveUndoState();
                     if (this.hasSelection()) {
                        this.deleteSelection();
                     } else if (this.cursorColumn > 0) {
                        List var29 = this.lines;
                        int var32 = this.cursorLine;
                        String var35 = ((String)this.lines.get(this.cursorLine)).substring(0, this.cursorColumn - 1);
                        var29.set(var32, var35 + ((String)this.lines.get(this.cursorLine)).substring(this.cursorColumn));
                        --this.cursorColumn;
                     } else if (this.cursorLine > 0) {
                        String prevLine = (String)this.lines.get(this.cursorLine - 1);
                        this.cursorColumn = prevLine.length();
                        this.lines.set(this.cursorLine - 1, prevLine + (String)this.lines.get(this.cursorLine));
                        this.lines.remove(this.cursorLine);
                        --this.cursorLine;
                     }

                     this.resetCursorBlink();
                     return true;
                  case 261:
                     this.saveUndoState();
                     if (this.hasSelection()) {
                        this.deleteSelection();
                     } else if (this.cursorColumn < ((String)this.lines.get(this.cursorLine)).length()) {
                        List var10000 = this.lines;
                        int var10001 = this.cursorLine;
                        String var10002 = ((String)this.lines.get(this.cursorLine)).substring(0, this.cursorColumn);
                        var10000.set(var10001, var10002 + ((String)this.lines.get(this.cursorLine)).substring(this.cursorColumn + 1));
                     } else if (this.cursorLine < this.lines.size() - 1) {
                        List var28 = this.lines;
                        int var31 = this.cursorLine;
                        String var34 = (String)this.lines.get(this.cursorLine);
                        var28.set(var31, var34 + (String)this.lines.get(this.cursorLine + 1));
                        this.lines.remove(this.cursorLine + 1);
                     }

                     this.resetCursorBlink();
                     return true;
               }

               return false;
            }
         }
      }
   }

   public boolean charTyped(char chr, int modifiers) {
      if (!this.focused) {
         return false;
      } else {
         this.saveUndoState();
         if (this.hasSelection()) {
            this.deleteSelection();
         }

         String line = (String)this.lines.get(this.cursorLine);
         this.lines.set(this.cursorLine, line.substring(0, this.cursorColumn) + chr + line.substring(this.cursorColumn));
         ++this.cursorColumn;
         this.resetCursorBlink();
         return true;
      }
   }

   private void selectAll() {
      this.selectionStartLine = 0;
      this.selectionStartColumn = 0;
      this.selectionEndLine = this.lines.size() - 1;
      this.selectionEndColumn = ((String)this.lines.get(this.lines.size() - 1)).length();
      this.cursorLine = this.selectionEndLine;
      this.cursorColumn = this.selectionEndColumn;
   }

   private boolean hasSelection() {
      return this.selectionStartLine >= 0 && this.selectionEndLine >= 0 && (this.selectionStartLine != this.selectionEndLine || this.selectionStartColumn != this.selectionEndColumn);
   }

   private void clearSelection() {
      this.selectionStartLine = -1;
      this.selectionStartColumn = -1;
      this.selectionEndLine = -1;
      this.selectionEndColumn = -1;
   }

   private int getSelectionMinLine() {
      if (this.selectionStartLine < this.selectionEndLine) {
         return this.selectionStartLine;
      } else {
         return this.selectionStartLine > this.selectionEndLine ? this.selectionEndLine : Math.min(this.selectionStartLine, this.selectionEndLine);
      }
   }

   private int getSelectionMaxLine() {
      if (this.selectionStartLine > this.selectionEndLine) {
         return this.selectionStartLine;
      } else {
         return this.selectionStartLine < this.selectionEndLine ? this.selectionEndLine : Math.max(this.selectionStartLine, this.selectionEndLine);
      }
   }

   private int getSelectionMinColumn() {
      if (this.selectionStartLine < this.selectionEndLine) {
         return this.selectionStartColumn;
      } else {
         return this.selectionStartLine > this.selectionEndLine ? this.selectionEndColumn : Math.min(this.selectionStartColumn, this.selectionEndColumn);
      }
   }

   private int getSelectionMaxColumn() {
      if (this.selectionStartLine > this.selectionEndLine) {
         return this.selectionStartColumn;
      } else {
         return this.selectionStartLine < this.selectionEndLine ? this.selectionEndColumn : Math.max(this.selectionStartColumn, this.selectionEndColumn);
      }
   }

   private String getSelectedText() {
      if (!this.hasSelection()) {
         return "";
      } else {
         int minLine = this.getSelectionMinLine();
         int maxLine = this.getSelectionMaxLine();
         int minCol = this.getSelectionMinColumn();
         int maxCol = this.getSelectionMaxColumn();
         if (minLine == maxLine) {
            return ((String)this.lines.get(minLine)).substring(minCol, maxCol);
         } else {
            StringBuilder result = new StringBuilder();
            result.append(((String)this.lines.get(minLine)).substring(minCol)).append("\r\n");

            for(int i = minLine + 1; i < maxLine; ++i) {
               result.append((String)this.lines.get(i)).append("\r\n");
            }

            result.append(((String)this.lines.get(maxLine)).substring(0, maxCol));
            return result.toString();
         }
      }
   }

   private void deleteSelection() {
      if (this.hasSelection()) {
         int minLine = this.getSelectionMinLine();
         int maxLine = this.getSelectionMaxLine();
         int minCol = this.getSelectionMinColumn();
         int maxCol = this.getSelectionMaxColumn();
         if (minLine == maxLine) {
            String line = (String)this.lines.get(minLine);
            List var10000 = this.lines;
            String var10002 = line.substring(0, minCol);
            var10000.set(minLine, var10002 + line.substring(maxCol));
         } else {
            String newLine = ((String)this.lines.get(minLine)).substring(0, minCol) + ((String)this.lines.get(maxLine)).substring(maxCol);
            this.lines.set(minLine, newLine);

            for(int i = maxLine; i > minLine; --i) {
               this.lines.remove(i);
            }
         }

         this.cursorLine = minLine;
         this.cursorColumn = minCol;
         this.clearSelection();
      }
   }

   private void updateScrollFromMouseY(int mouseY, int visibleLines) {
      int scrollbarY = this.y + 4;
      int scrollbarHeight = this.height - 8;
      float mousePercentage = (float)(mouseY - scrollbarY) / (float)scrollbarHeight;
      mousePercentage = class_3532.method_15363(mousePercentage, 0.0F, 1.0F);
      int maxScroll = Math.max(0, this.lines.size() - visibleLines);
      this.scrollOffset = (int)(mousePercentage * (float)maxScroll);
      this.scrollOffset = class_3532.method_15340(this.scrollOffset, 0, maxScroll);
   }

   private void ensureCursorVisible() {
      int visibleLines = (this.height - 16) / 12;
      if (this.cursorLine < this.scrollOffset) {
         this.scrollOffset = this.cursorLine;
      } else if (this.cursorLine >= this.scrollOffset + visibleLines) {
         this.scrollOffset = this.cursorLine - visibleLines + 1;
      }

   }

   private void resetCursorBlink() {
      this.cursorVisible = true;
      this.lastCursorBlink = System.currentTimeMillis();
   }

   private void saveUndoState() {
      while(this.undoStack.size() > this.undoIndex + 1) {
         this.undoStack.remove(this.undoStack.size() - 1);
      }

      this.undoStack.add(this.getText());
      ++this.undoIndex;
      if (this.undoStack.size() > 50) {
         this.undoStack.remove(0);
         --this.undoIndex;
      }

   }

   private void undo() {
      if (this.undoIndex > 0) {
         --this.undoIndex;
         this.setText((String)this.undoStack.get(this.undoIndex));
      }

   }

   private void redo() {
      if (this.undoIndex < this.undoStack.size() - 1) {
         ++this.undoIndex;
         this.setText((String)this.undoStack.get(this.undoIndex));
      }

   }

   public String getText() {
      return String.join("\n", this.lines);
   }

   public void setText(String text) {
      this.lines.clear();
      if (text != null && !text.isEmpty()) {
         String[] splitLines = text.split("\n", -1);

         for(String line : splitLines) {
            this.lines.add(line);
         }
      } else {
         this.lines.add("");
      }

      this.cursorLine = 0;
      this.cursorColumn = 0;
      this.scrollOffset = 0;
      this.clearSelection();
   }

   public int getCursorLine() {
      return this.cursorLine;
   }

   public void setCursorLine(int line) {
      this.cursorLine = class_3532.method_15340(line, 0, this.lines.size() - 1);
   }

   public int getCursorColumn() {
      return this.cursorColumn;
   }

   public void setCursorColumn(int col) {
      if (this.cursorLine >= 0 && this.cursorLine < this.lines.size()) {
         this.cursorColumn = class_3532.method_15340(col, 0, ((String)this.lines.get(this.cursorLine)).length());
      } else {
         this.cursorColumn = 0;
      }

   }

   public int getScrollOffset() {
      return this.scrollOffset;
   }

   public void setScrollOffset(int offset) {
      this.scrollOffset = offset;
   }

   public void setFocused(boolean focused) {
      this.focused = focused;
      if (focused) {
         this.resetCursorBlink();
      }

   }

   public boolean isFocused() {
      return this.focused;
   }
}
