package pl.bkubiak.bkrynek.client.gui.widgets;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_4185;

@Environment(EnvType.CLIENT)
public class Button extends class_4185 {
   private final int accentColor;
   private final int textColor;
   private final boolean filled;
   private String displayText;
   private float hoverAnimation;
   private float clickAnimation;
   private boolean solid;
   private boolean invisible;

   public Button(int x, int y, int width, int height, String text, class_4185.class_4241 onPress, int accentColor, boolean filled) {
      this(x, y, width, height, text, onPress, accentColor, -1, filled);
   }

   public Button(int x, int y, int width, int height, String text, class_4185.class_4241 onPress, int accentColor, int textColor, boolean filled) {
      super(x, y, width, height, class_2561.method_30163(text), onPress, field_40754);
      this.hoverAnimation = 0.0F;
      this.clickAnimation = 0.0F;
      this.solid = false;
      this.invisible = false;
      this.accentColor = accentColor;
      this.textColor = textColor;
      this.filled = filled;
      this.displayText = text;
   }

   public Button setSolid(boolean solid) {
      this.solid = solid;
      return this;
   }

   public Button setInvisible(boolean invisible) {
      this.invisible = invisible;
      return this;
   }

   public void update(String newText) {
      this.displayText = newText;
   }

   public void method_25348(double mouseX, double mouseY) {
      super.method_25348(mouseX, mouseY);
      this.clickAnimation = 1.0F;
   }

   protected void method_48579(class_332 context, int mouseX, int mouseY, float delta) {
      if (!this.invisible) {
         if (this.method_49606() && this.hoverAnimation < 1.0F) {
            this.hoverAnimation = class_3532.method_15363(this.hoverAnimation + delta * 0.3F, 0.0F, 1.0F);
         } else if (!this.method_49606() && this.hoverAnimation > 0.0F) {
            this.hoverAnimation = class_3532.method_15363(this.hoverAnimation - delta * 0.2F, 0.0F, 1.0F);
         }

         if (this.clickAnimation > 0.0F) {
            this.clickAnimation = Math.max(0.0F, this.clickAnimation - delta * 0.4F);
         }

         if (this.solid && this.field_22758 <= 14 && this.field_22759 <= 14) {
            Panel.drawCircle(context, this.method_46426() + this.field_22758 / 2, this.method_46427() + this.field_22759 / 2, this.field_22758 / 2, this.accentColor);
         } else {
            int bgColor;
            int borderColor;
            int finalTextColor;
            if (this.filled) {
               bgColor = this.method_49606() ? -14540254 : -15592942;
               if (this.textColor == -1) {
                  borderColor = Colors.interpolate(this.accentColor, -1, this.hoverAnimation * 0.3F);
                  finalTextColor = Colors.interpolate(-1, this.accentColor, this.hoverAnimation * 0.2F);
               } else {
                  borderColor = Colors.interpolate(-14145496, this.accentColor, this.hoverAnimation * 0.4F);
                  int baseText = this.textColor != -1 ? this.textColor : this.accentColor;
                  finalTextColor = Colors.interpolate(baseText, -1, this.hoverAnimation * 0.3F);
               }
            } else {
               bgColor = this.method_49606() ? -14342875 : -15592942;
               borderColor = Colors.interpolate(-14540254, this.accentColor, this.hoverAnimation);
               int baseText = this.textColor != -1 ? this.textColor : this.accentColor;
               finalTextColor = Colors.interpolate(baseText, -1, this.hoverAnimation);
            }

            if (this.clickAnimation > 0.0F) {
               bgColor = Colors.interpolate(bgColor, -1, this.clickAnimation * 0.2F);
            }

            int radius = Math.min(6, Math.min(this.method_25368(), this.method_25364()) / 2);
            if (this.field_22758 <= 14 && this.field_22759 <= 14) {
               Panel.drawCircle(context, this.method_46426() + this.field_22758 / 2, this.method_46427() + this.field_22759 / 2, this.field_22758 / 2, bgColor);
               Panel.drawCircle(context, this.method_46426() + this.field_22758 / 2, this.method_46427() + this.field_22759 / 2, this.field_22758 / 2, borderColor);
            } else {
               Panel.drawRoundedRect(context, this.method_46426(), this.method_46427(), this.field_22758, this.field_22759, radius, bgColor);
               Panel.drawRoundedRectOutline(context, this.method_46426(), this.method_46427(), this.field_22758, this.field_22759, radius, borderColor);
            }

            class_327 tr = class_310.method_1551().field_1772;
            int textWidth = tr.method_1727(this.displayText);
            int tx = this.method_46426() + (this.method_25368() - textWidth) / 2;
            int ty = this.method_46427() + (this.field_22759 - 8) / 2;
            if (this.field_22759 <= 14) {
               ++ty;
            }

            context.method_51433(tr, this.displayText, tx, ty, finalTextColor, false);
         }
      }
   }
}
