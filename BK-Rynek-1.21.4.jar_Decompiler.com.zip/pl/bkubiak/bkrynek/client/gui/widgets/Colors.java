package pl.bkubiak.bkrynek.client.gui.widgets;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class Colors {
   public static final int COLOR_OVERLAY = -1442840576;
   public static final int COLOR_PANEL_BG = -233894129;
   public static final int COLOR_PANEL_SHADOW = 1610612736;
   public static final int COLOR_CARD_BG = -15395563;
   public static final int COLOR_BORDER_OUTER = -14540254;
   public static final int COLOR_BORDER_INNER = -13421773;
   public static final int COLOR_BORDER_ACCENT = -12303292;
   public static final int COLOR_HEADER_BG = -15395563;
   public static final int COLOR_HEADER_LINE = -13421773;
   public static final int TEXT_MAIN = -1;
   public static final int TEXT_DIM = -5592406;
   public static final int TEXT_VERY_DIM = -10066330;
   public static final int TEXT_PLACEHOLDER = -11184811;
   public static final int COLOR_STATUS_ON = -12255420;
   public static final int COLOR_STATUS_OFF = -48060;
   public static final int COLOR_STATUS_WARN = -171;
   public static final int COLOR_ACCENT = -1;
   public static final int COLOR_ACCENT_GREEN = -16720555;
   public static final int COLOR_ACCENT_BLUE = -11171585;
   public static final int COLOR_ACCENT_ORANGE = -22016;
   public static final int COLOR_ACCENT_CYAN = -11141121;
   public static final int COLOR_ROW_EVEN = 285212671;
   public static final int COLOR_ROW_ODD = 0;
   public static final int COLOR_ROW_HOVER = 1090519039;
   public static final int COLOR_ROW_SELECTED = 1613989973;
   public static final int COLOR_ROW_LINE = -15066598;
   public static final int COLOR_BTN_BG = -15592942;
   public static final int COLOR_BTN_BG_HOVER = -14540254;
   public static final int COLOR_BTN_BORDER = -14145496;
   public static final int COLOR_SCROLLBAR_BG = 805306368;
   public static final int COLOR_SCROLLBAR_THUMB = -2138535800;
   public static final int COLOR_SCROLLBAR_THUMB_HOVER = -5592406;
   public static final int COLOR_TRAFFIC_RED = -48060;
   public static final int COLOR_TRAFFIC_YELLOW = -188;
   public static final int COLOR_TRAFFIC_GREEN = -12255420;

   private Colors() {
   }

   public static int interpolate(int color1, int color2, float ratio) {
      float r = (1.0F - ratio) * (float)(color1 >> 16 & 255) + ratio * (float)(color2 >> 16 & 255);
      float g = (1.0F - ratio) * (float)(color1 >> 8 & 255) + ratio * (float)(color2 >> 8 & 255);
      float b = (1.0F - ratio) * (float)(color1 & 255) + ratio * (float)(color2 & 255);
      float a = (1.0F - ratio) * (float)(color1 >> 24 & 255) + ratio * (float)(color2 >> 24 & 255);
      return (int)a << 24 | (int)r << 16 | (int)g << 8 | (int)b;
   }
}
