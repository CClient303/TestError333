package pl.bkubiak.bkrynek.client.gui.widgets;

import com.mojang.blaze3d.systems.RenderSystem;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1799;
import net.minecraft.class_1935;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_364;
import net.minecraft.class_4068;
import net.minecraft.class_6379;
import net.minecraft.class_6382;
import net.minecraft.class_7923;
import net.minecraft.class_9280;
import net.minecraft.class_9334;
import net.minecraft.class_6379.class_6380;
import pl.bkubiak.bkrynek.client.gui.AddItemScreen;
import pl.bkubiak.bkrynek.client.gui.BkRynekScreen;
import pl.bkubiak.bkrynek.core.config.PriceEntry;
import pl.bkubiak.bkrynek.core.manager.ClientPriceListManager;
import pl.bkubiak.bkrynek.core.util.PriceFormatter;

@Environment(EnvType.CLIENT)
public class PriceListWidget implements class_4068, class_364, class_6379 {
   private final BkRynekScreen parent;
   private final int x;
   private final int y;
   private final int w;
   private final int h;
   private final int rowHeight = 26;
   private double scrollOffset = (double)0.0F;

   public PriceListWidget(BkRynekScreen parent, int x, int y, int w, int h) {
      this.parent = parent;
      this.x = x;
      this.y = y;
      this.w = w;
      this.h = h;
   }

   public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
      class_327 textRenderer = class_310.method_1551().field_1772;
      String profileName = ClientPriceListManager.getActiveProfile();
      List<PriceEntry> entries = (List)ClientPriceListManager.getAllProfiles().get(profileName);
      if (entries != null && !entries.isEmpty()) {
         int totalHeight = entries.size() * 26;
         if (this.scrollOffset < (double)0.0F) {
            this.scrollOffset = (double)0.0F;
         }

         if (totalHeight > this.h) {
            if (this.scrollOffset > (double)(totalHeight - this.h)) {
               this.scrollOffset = (double)(totalHeight - this.h);
            }
         } else {
            this.scrollOffset = (double)0.0F;
         }

         context.method_51452();
         context.method_44379(this.x, this.y, this.x + this.w, this.y + this.h);

         for(int i = 0; i < entries.size(); ++i) {
            PriceEntry entry = (PriceEntry)entries.get(i);
            int rowY = this.y + i * 26 - (int)this.scrollOffset;
            if (rowY + 26 >= this.y && rowY <= this.y + this.h) {
               boolean hovered = mouseX >= this.x && mouseX <= this.x + this.w && mouseY >= rowY && mouseY < rowY + 26;
               if (hovered) {
                  context.method_25294(this.x, rowY, this.x + this.w, rowY + 26, 822083583);
               } else if (i % 2 == 0) {
                  context.method_25294(this.x, rowY, this.x + this.w, rowY + 26, 352321536);
               }

               RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
               class_1799 stack = this.createItemStack(entry);
               if (stack != null) {
                  context.method_51427(stack, this.x + 2, rowY + 5);
               }

               String name = entry.name != null && !entry.name.isEmpty() ? entry.name : "§7" + entry.material;
               context.method_51433(textRenderer, name, this.x + 22, rowY + 4, -1, true);
               context.method_51433(textRenderer, "§a" + PriceFormatter.formatPrice(entry.maxPrice), this.x + 22, rowY + 14, -12255420, true);
               if (hovered) {
                  context.method_51433(textRenderer, "§c✖", this.x + this.w - 15, rowY + 8, -48060, true);
               }
            }
         }

         context.method_51452();
         context.method_44380();
         if (totalHeight > this.h) {
            float vp = (float)this.h / (float)totalHeight;
            float sp = (float)this.scrollOffset / (float)(totalHeight - this.h);
            Panel.drawScrollbar(context, this.x + this.w + 5, this.y, 3, this.h, sp, vp, false);
         }

      } else {
         context.method_51433(textRenderer, "No items in registry.", this.x, this.y + 10, -10066330, false);
      }
   }

   private class_1799 createItemStack(PriceEntry entry) {
      if (entry != null && entry.material != null) {
         try {
            class_2960 id = class_2960.method_60654(entry.material);
            if (class_7923.field_41178.method_10250(id)) {
               class_1799 stack = new class_1799((class_1935)class_7923.field_41178.method_63535(id));
               if (entry.customModelData != null) {
                  stack.method_57379(class_9334.field_49637, new class_9280(List.of(entry.customModelData.floatValue()), List.of(), List.of(), List.of()));
               }

               return stack;
            }
         } catch (Exception var4) {
         }

         return null;
      } else {
         return null;
      }
   }

   public boolean method_25402(double mouseX, double mouseY, int button) {
      String profileName = ClientPriceListManager.getActiveProfile();
      List<PriceEntry> entries = (List)ClientPriceListManager.getAllProfiles().get(profileName);
      if (entries != null) {
         for(int i = 0; i < entries.size(); ++i) {
            int rowY = this.y + i * 26 - (int)this.scrollOffset;
            if (mouseY >= (double)this.y && mouseY < (double)(this.y + this.h) && mouseX >= (double)this.x && mouseX <= (double)(this.x + this.w) && mouseY >= (double)rowY && mouseY < (double)(rowY + 26)) {
               if (mouseX >= (double)(this.x + this.w - 20)) {
                  ClientPriceListManager.removePriceEntry((PriceEntry)entries.get(i));
                  this.parent.method_25423(class_310.method_1551(), this.parent.field_22789, this.parent.field_22790);
               } else {
                  class_310.method_1551().method_1507(new AddItemScreen(this.parent, (PriceEntry)entries.get(i), (success) -> this.parent.method_25423(class_310.method_1551(), this.parent.field_22789, this.parent.field_22790)));
               }

               return true;
            }
         }
      }

      return false;
   }

   public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
      String profileName = ClientPriceListManager.getActiveProfile();
      List<PriceEntry> entries = (List)ClientPriceListManager.getAllProfiles().get(profileName);
      if (entries != null) {
         int totalHeight = entries.size() * 26;
         if (totalHeight > this.h) {
            this.scrollOffset -= verticalAmount * (double)15.0F;
            if (this.scrollOffset < (double)0.0F) {
               this.scrollOffset = (double)0.0F;
            }

            if (this.scrollOffset > (double)(totalHeight - this.h)) {
               this.scrollOffset = (double)(totalHeight - this.h);
            }

            return true;
         }
      }

      return false;
   }

   public class_6379.class_6380 method_37018() {
      return class_6380.field_33785;
   }

   public void method_37020(class_6382 builder) {
   }

   public void method_25365(boolean focused) {
   }

   public boolean method_25370() {
      return false;
   }
}
