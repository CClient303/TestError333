package pl.bkubiak.bkrynek.client.gui.widgets;

import java.util.function.Consumer;
import java.util.function.Function;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_4185;

@Environment(EnvType.CLIENT)
public class Slider extends class_4185 {
   private final double min;
   private final double max;
   private double value;
   private final String label;
   private final String suffix;
   private final Consumer<Double> onChanged;
   private Function<Double, class_2561> messageProvider;
   private boolean dragging = false;

   public Slider(int x, int y, int width, int height, String label, double initialValue, double min, double max, String suffix, Consumer<Double> onChanged) {
      super(x, y, width, height, class_2561.method_30163(label), (b) -> {
      }, field_40754);
      this.label = label;
      this.min = min;
      this.max = max;
      this.value = class_3532.method_15350(initialValue, min, max);
      this.suffix = suffix;
      this.onChanged = onChanged;
   }

   public void setUpdateMessage(Function<Double, class_2561> provider) {
      this.messageProvider = provider;
      this.method_25355((class_2561)provider.apply(this.value));
   }

   protected void method_48579(class_332 context, int mouseX, int mouseY, float delta) {
      Panel.drawRoundedRect(context, this.method_46426(), this.method_46427() + this.field_22759 / 2 - 1, this.field_22758, 2, 1, -14540254);
      double progress = (this.value - this.min) / (this.max - this.min);
      int progressW = (int)(progress * (double)this.field_22758);
      Panel.drawRoundedRect(context, this.method_46426(), this.method_46427() + this.field_22759 / 2 - 1, progressW, 2, 1, -11141121);
      int knobSize = 8;
      int knobX = this.method_46426() + (int)(progress * (double)(this.field_22758 - knobSize));
      int knobY = this.method_46427() + (this.field_22759 - knobSize) / 2;
      int knobColor = !this.method_49606() && !this.dragging ? -5592406 : -1;
      Panel.drawCircle(context, knobX + knobSize / 2, knobY + knobSize / 2, knobSize / 2, knobColor);
      if (this.dragging) {
         Panel.drawCircle(context, knobX + knobSize / 2, knobY + knobSize / 2, knobSize / 2 + 2, 1157627903);
      }

      class_327 tr = class_310.method_1551().field_1772;
      String valStr = this.messageProvider != null ? ((class_2561)this.messageProvider.apply(this.value)).getString() : (int)this.value + this.suffix;
      context.method_51433(tr, this.label, this.method_46426(), this.method_46427() - 10, -10066330, false);
      context.method_51433(tr, valStr, this.method_46426() + this.field_22758 - tr.method_1727(valStr), this.method_46427() - 10, -11141121, false);
   }

   public void method_25348(double mouseX, double mouseY) {
      this.dragging = true;
      this.updateFromMouse(mouseX);
   }

   public void method_25357(double mouseX, double mouseY) {
      this.dragging = false;
   }

   protected void method_25349(double mouseX, double mouseY, double deltaX, double deltaY) {
      if (this.dragging) {
         this.updateFromMouse(mouseX);
      }

   }

   private void updateFromMouse(double mouseX) {
      double progress = class_3532.method_15350((mouseX - (double)this.method_46426()) / (double)this.method_25368(), (double)0.0F, (double)1.0F);
      double newValue = this.min + progress * (this.max - this.min);
      if (newValue != this.value) {
         this.value = newValue;
         if (this.messageProvider != null) {
            this.method_25355((class_2561)this.messageProvider.apply(this.value));
         }

         this.onChanged.accept(this.value);
      }

   }
}
