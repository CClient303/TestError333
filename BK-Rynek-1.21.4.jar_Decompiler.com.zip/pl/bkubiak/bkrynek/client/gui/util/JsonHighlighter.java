package pl.bkubiak.bkrynek.client.gui.util;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class JsonHighlighter {
   private static final Pattern STRING_PATTERN = Pattern.compile("\"([^\"\\\\]|\\\\.)*\"");
   private static final Pattern NUMBER_PATTERN = Pattern.compile("\\b-?\\d+(\\.\\d+)?([eE][+-]?\\d+)?\\b");
   private static final Pattern BOOLEAN_NULL_PATTERN = Pattern.compile("\\b(true|false|null)\\b");
   private static final Pattern KEY_PATTERN = Pattern.compile("\"([^\"\\\\]|\\\\.)*\"\\s*:");

   public static List<ColoredSegment> highlightLine(String line) {
      List<ColoredSegment> segments = new ArrayList();
      if (line != null && !line.isEmpty()) {
         boolean[] colored = new boolean[line.length()];
         List<Token> tokens = new ArrayList();
         Matcher keyMatcher = KEY_PATTERN.matcher(line);

         while(keyMatcher.find()) {
            tokens.add(new Token(keyMatcher.start(), keyMatcher.end(), -11141121, 3));
         }

         Matcher stringMatcher = STRING_PATTERN.matcher(line);

         while(stringMatcher.find()) {
            tokens.add(new Token(stringMatcher.start(), stringMatcher.end(), -16720555, 2));
         }

         Matcher numberMatcher = NUMBER_PATTERN.matcher(line);

         while(numberMatcher.find()) {
            tokens.add(new Token(numberMatcher.start(), numberMatcher.end(), -11171585, 1));
         }

         Matcher boolMatcher = BOOLEAN_NULL_PATTERN.matcher(line);

         while(boolMatcher.find()) {
            tokens.add(new Token(boolMatcher.start(), boolMatcher.end(), -22016, 1));
         }

         tokens.sort((a, b) -> a.priority != b.priority ? b.priority - a.priority : a.start - b.start);

         for(Token token : tokens) {
            boolean canApply = true;

            for(int i = token.start; i < token.end; ++i) {
               if (colored[i]) {
                  canApply = false;
                  break;
               }
            }

            if (canApply) {
               for(int i = token.start; i < token.end; ++i) {
                  colored[i] = true;
               }

               token.applied = true;
            }
         }

         int currentStart = 0;
         int currentColor = -5592406;

         for(int i = 0; i < line.length(); ++i) {
            Token tokenAtPos = null;

            for(Token token : tokens) {
               if (token.applied && i >= token.start && i < token.end) {
                  tokenAtPos = token;
                  break;
               }
            }

            int newColor = tokenAtPos != null ? tokenAtPos.color : -5592406;
            if (newColor != currentColor) {
               if (i > currentStart) {
                  segments.add(new ColoredSegment(line.substring(currentStart, i), currentColor));
               }

               currentStart = i;
               currentColor = newColor;
            }
         }

         if (currentStart < line.length()) {
            segments.add(new ColoredSegment(line.substring(currentStart), currentColor));
         }

         if (segments.isEmpty()) {
            segments.add(new ColoredSegment(line, -5592406));
         }

         return segments;
      } else {
         segments.add(new ColoredSegment("", -1));
         return segments;
      }
   }

   @Environment(EnvType.CLIENT)
   public static class ColoredSegment {
      public final String text;
      public final int color;

      public ColoredSegment(String text, int color) {
         this.text = text;
         this.color = color;
      }
   }

   @Environment(EnvType.CLIENT)
   private static class Token {
      int start;
      int end;
      int color;
      int priority;
      boolean applied = false;

      Token(int start, int end, int color, int priority) {
         this.start = start;
         this.end = end;
         this.color = color;
         this.priority = priority;
      }
   }
}
