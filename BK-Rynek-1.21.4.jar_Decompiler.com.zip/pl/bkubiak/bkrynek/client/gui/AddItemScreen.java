package pl.bkubiak.bkrynek.client.gui;

import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_437;
import net.minecraft.class_7923;
import net.minecraft.class_9280;
import pl.bkubiak.bkrynek.client.BkRynekClient;
import pl.bkubiak.bkrynek.client.command.ClientCommandRegistration;
import pl.bkubiak.bkrynek.client.config.ConfigLoader;
import pl.bkubiak.bkrynek.client.gui.data.EnchantEntry;
import pl.bkubiak.bkrynek.client.gui.data.LoreEntry;
import pl.bkubiak.bkrynek.client.gui.widgets.Button;
import pl.bkubiak.bkrynek.client.gui.widgets.Panel;
import pl.bkubiak.bkrynek.core.config.PriceEntry;
import pl.bkubiak.bkrynek.core.manager.ClientPriceListManager;
import pl.bkubiak.bkrynek.core.util.EnchantMapper;

@Environment(EnvType.CLIENT)
public class AddItemScreen extends class_437 {
   private final class_437 parent;
   private final Consumer<Boolean> onComplete;
   private final PriceEntry editingEntry;
   private final boolean isEditMode;
   private class_342 nameField;
   private class_342 quantityField;
   private class_342 sellQuantityField;
   private class_342 maxPriceField;
   private class_342 sellPriceField;
   private class_342 minDaysLeftField;
   private String selectedMaterial = "";
   private class_1799 selectedItemStack = null;
   private Integer customModelData = null;
   private boolean buyEnabled = true;
   private boolean sellEnabled = false;
   private List<LoreEntry> loreEntries = new ArrayList();
   private List<EnchantEntry> enchantEntries = new ArrayList();
   private boolean loreExpanded = false;
   private boolean enchantExpanded = false;
   private int loreScrollOffset = 0;
   private int maxVisibleLore = 5;
   private int enchantScrollOffset = 0;
   private int maxVisibleEnchant = 5;
   private List<EnchantEntry> bannedEnchantEntries = new ArrayList();
   private boolean bannedExpanded = false;
   private int bannedScrollOffset = 0;
   private int maxVisibleBanned = 3;
   private int panelX;
   private int panelY;
   private int panelW;
   private int panelH;
   private int contentX;
   private int contentY;
   private int contentW;
   private int margin = 16;

   public AddItemScreen(class_437 parent, PriceEntry existing, Consumer<Boolean> onComplete) {
      super(class_2561.method_30163(existing == null ? "Add Item" : "Edit Item"));
      this.parent = parent;
      this.onComplete = onComplete;
      this.editingEntry = existing;
      this.isEditMode = existing != null && existing.material != null && !existing.material.isEmpty();
      if (this.isEditMode && existing != null) {
         this.buyEnabled = existing.buyEnabled != null ? existing.buyEnabled : true;
         this.sellEnabled = existing.sellEnabled != null ? existing.sellEnabled : false;
         this.selectedMaterial = existing.material != null ? existing.material : "";
         this.customModelData = existing.customModelData;
         if (!this.selectedMaterial.isEmpty()) {
            this.selectedItemStack = this.createItemStack(this.selectedMaterial);
         }

         if (existing.lore != null && !existing.lore.isEmpty()) {
            String[] parts = existing.lore.split("[;|]");

            for(String part : parts) {
               String trimmed = part.trim();
               if (!trimmed.isEmpty()) {
                  this.loreEntries.add(new LoreEntry((Integer)null, trimmed));
               }
            }
         }

         if (existing.enchants != null && !existing.enchants.isEmpty()) {
            this.parseEnchantString(existing.enchants, this.enchantEntries);
         }

         if (existing.excludedEnchants != null && !existing.excludedEnchants.isEmpty()) {
            this.parseEnchantString(existing.excludedEnchants, this.bannedEnchantEntries);
         }

         this.sellQuantityField = null;
      }

   }

   private boolean shouldShowMinDays() {
      if (this.isEditMode && this.editingEntry != null && this.editingEntry.minDaysLeft != null) {
         return true;
      } else {
         String checkName = null;
         if (this.isEditMode && this.editingEntry != null && this.editingEntry.name != null) {
            checkName = this.editingEntry.name.toLowerCase();
         } else if (this.nameField != null) {
            checkName = this.nameField.method_1882().toLowerCase();
         }

         if (checkName != null) {
            checkName = checkName.replaceAll("[§&][0-9a-fk-or]", "").trim().toLowerCase();
         }

         if (checkName == null || !checkName.startsWith("pet ") && !checkName.startsWith("kostium ")) {
            for(LoreEntry le : this.loreEntries) {
               if (le.content != null) {
                  String lower = le.content.toLowerCase();
                  if (lower.contains("wygaśnie:") || lower.contains("wygasnie:") || lower.contains("szyfr")) {
                     return true;
                  }
               }
            }

            return false;
         } else {
            return true;
         }
      }
   }

   private class_1799 createItemStack(String material) {
      try {
         class_2960 id = class_2960.method_60654(material);
         if (class_7923.field_41178.method_10250(id)) {
            class_1792 item = (class_1792)class_7923.field_41178.method_63535(id);
            class_1799 stack = new class_1799(item);
            if (this.customModelData != null) {
               try {
                  System.out.println("DEBUG: CustomModelDataComponent Constructors: ");

                  for(Constructor<?> c : class_9280.class.getConstructors()) {
                     System.out.println(" - " + c.toString());
                  }
               } catch (Exception e) {
                  e.printStackTrace();
               }
            }

            return stack;
         }
      } catch (Exception var10) {
      }

      return null;
   }

   protected void method_25426() {
      this.method_37067();
      super.method_25426();
      int baseHeight = 280;
      int availableHeight = this.field_22790 - 330;
      int maxRows = Math.max(2, this.availableForLists(availableHeight));
      if (this.loreExpanded && this.enchantExpanded && this.bannedExpanded) {
         this.maxVisibleLore = Math.max(1, maxRows / 3);
         this.maxVisibleEnchant = Math.max(1, maxRows / 3);
         this.maxVisibleBanned = Math.max(1, maxRows / 3);
      } else if (this.loreExpanded && this.enchantExpanded) {
         this.maxVisibleLore = Math.max(2, maxRows / 2);
         this.maxVisibleEnchant = Math.max(2, maxRows / 2);
      } else if (this.loreExpanded && this.bannedExpanded) {
         this.maxVisibleLore = Math.max(2, maxRows / 2);
         this.maxVisibleBanned = Math.max(2, maxRows / 2);
      } else if (this.enchantExpanded && this.bannedExpanded) {
         this.maxVisibleEnchant = Math.max(2, maxRows / 2);
         this.maxVisibleBanned = Math.max(2, maxRows / 2);
      } else if (this.loreExpanded) {
         this.maxVisibleLore = maxRows;
      } else if (this.enchantExpanded) {
         this.maxVisibleEnchant = maxRows;
      } else if (this.bannedExpanded) {
         this.maxVisibleBanned = maxRows;
      }

      int visibleLoreCount = this.loreExpanded ? Math.min(this.loreEntries.size(), this.maxVisibleLore) : 0;
      int loreHeight = this.loreExpanded ? visibleLoreCount * 25 + (this.loreEntries.size() > this.maxVisibleLore ? 24 : 0) + 20 : 20;
      int visibleEnchantCount = this.enchantExpanded ? Math.min(this.enchantEntries.size(), this.maxVisibleEnchant) : 0;
      int enchantHeight = this.enchantExpanded ? visibleEnchantCount * 25 + (this.enchantEntries.size() > this.maxVisibleEnchant ? 24 : 0) + 20 : 20;
      int visibleBannedCount = this.bannedExpanded ? Math.min(this.bannedEnchantEntries.size(), this.maxVisibleBanned) : 0;
      int bannedHeight = this.bannedExpanded ? visibleBannedCount * 25 + (this.bannedEnchantEntries.size() > this.maxVisibleBanned ? 24 : 0) + 20 : 20;
      int dynamicHeight = baseHeight + loreHeight + enchantHeight + bannedHeight + 40;
      this.panelW = Math.min(450, this.field_22789 - 40);
      this.panelH = Math.min(Math.max(250, dynamicHeight), this.field_22790 - 40);
      this.panelX = (this.field_22789 - this.panelW) / 2;
      this.panelY = (this.field_22790 - this.panelH) / 2;
      this.contentX = this.panelX + this.margin;
      this.contentY = this.panelY + 30;
      this.contentW = this.panelW - this.margin * 2;
      int fieldY = this.contentY + 10;
      int fieldH = 18;
      int labelW = 80;
      int fieldW = this.contentW - labelW - 10;
      this.method_37063(new Button(this.contentX + labelW, fieldY, fieldW, 20, this.selectedMaterial.isEmpty() ? "§7Select item..." : this.getItemDisplayName(), (btn) -> this.openItemPicker(), -11171585, false));
      fieldY += 32;
      int typeX = this.contentX + labelW;
      this.method_37063((new Button(typeX, fieldY + 4, 10, 10, "", (btn) -> {
         this.buyEnabled = !this.buyEnabled;
         this.method_25426();
      }, this.buyEnabled ? -12255420 : -5592406, true)).setSolid(true));
      this.method_37063((new Button(typeX + 14, fieldY, 40, 18, "BUY", (btn) -> {
         this.buyEnabled = !this.buyEnabled;
         this.method_25426();
      }, 0, this.buyEnabled ? -12255420 : -5592406, false)).setInvisible(true));
      typeX += 70;
      this.method_37063((new Button(typeX, fieldY + 4, 10, 10, "", (btn) -> {
         this.sellEnabled = !this.sellEnabled;
         this.method_25426();
      }, this.sellEnabled ? -22016 : -5592406, true)).setSolid(true));
      this.method_37063((new Button(typeX + 14, fieldY, 40, 18, "SELL", (btn) -> {
         this.sellEnabled = !this.sellEnabled;
         this.method_25426();
      }, 0, this.sellEnabled ? -22016 : -5592406, false)).setInvisible(true));
      fieldY += 28;
      this.nameField = new class_342(this.field_22793, this.contentX + labelW, fieldY, fieldW, fieldH, class_2561.method_30163(""));
      this.nameField.method_47404(class_2561.method_30163("§8Display name override"));
      this.nameField.method_1880(64);
      if (this.isEditMode && this.editingEntry != null && this.editingEntry.name != null) {
         this.nameField.method_1852(this.editingEntry.name);
      }

      this.method_37063(this.nameField);
      fieldY += 28;
      this.quantityField = new class_342(this.field_22793, this.contentX + 80, fieldY, 35, fieldH, class_2561.method_30163(""));
      this.quantityField.method_47404(class_2561.method_30163("1"));
      this.quantityField.method_1880(3);
      if (this.isEditMode && this.editingEntry != null) {
         this.quantityField.method_1852(String.valueOf(this.editingEntry.requiredCount != null && this.editingEntry.requiredCount > 0 ? this.editingEntry.requiredCount : 1));
      } else {
         this.quantityField.method_1852("1");
      }

      this.method_37063(this.quantityField);
      this.method_37063(new Button(this.contentX + 80 + 37, fieldY, 18, 18, "+", (btn) -> this.adjustQuantity(this.quantityField, 1), -5592406, false));
      int sellQtyLabelX = this.contentX + 150;
      int sellQtyX = sellQtyLabelX + 80;
      this.sellQuantityField = new class_342(this.field_22793, sellQtyX, fieldY, 35, fieldH, class_2561.method_30163(""));
      this.sellQuantityField.method_47404(class_2561.method_30163("1"));
      this.sellQuantityField.method_1880(3);
      if (this.isEditMode && this.editingEntry != null) {
         this.sellQuantityField.method_1852(String.valueOf(this.editingEntry.sellCount != null && this.editingEntry.sellCount > 0 ? this.editingEntry.sellCount : 1));
      } else {
         this.sellQuantityField.method_1852("1");
      }

      this.method_37063(this.sellQuantityField);
      this.method_37063(new Button(sellQtyX + 37, fieldY, 18, 18, "+", (btn) -> this.adjustQuantity(this.sellQuantityField, 1), -5592406, false));
      fieldY += 28;
      this.maxPriceField = new class_342(this.field_22793, this.contentX + labelW, fieldY, fieldW, fieldH, class_2561.method_30163(""));
      this.maxPriceField.method_47404(class_2561.method_30163("e.g. 1000"));
      this.maxPriceField.method_1880(15);
      if (this.isEditMode && this.editingEntry != null) {
         this.maxPriceField.method_1852(String.valueOf((int)this.editingEntry.maxPrice));
      }

      this.method_37063(this.maxPriceField);
      fieldY += 28;
      this.sellPriceField = new class_342(this.field_22793, this.contentX + labelW, fieldY, fieldW, fieldH, class_2561.method_30163(""));
      this.sellPriceField.method_47404(class_2561.method_30163("e.g. 1100"));
      this.sellPriceField.method_1880(15);
      if (this.isEditMode && this.editingEntry != null) {
         this.sellPriceField.method_1852(String.valueOf((int)this.editingEntry.sellPrice));
      }

      this.method_37063(this.sellPriceField);
      fieldY += 28;
      if (this.shouldShowMinDays()) {
         this.minDaysLeftField = new class_342(this.field_22793, this.contentX + labelW, fieldY, fieldW, fieldH, class_2561.method_30163(""));
         this.minDaysLeftField.method_47404(class_2561.method_30163("Min days left (e.g. 5)"));
         this.minDaysLeftField.method_1880(3);
         if (this.isEditMode && this.editingEntry != null && this.editingEntry.minDaysLeft != null) {
            this.minDaysLeftField.method_1852(String.valueOf(this.editingEntry.minDaysLeft));
         }

         this.method_37063(this.minDaysLeftField);
         fieldY += 28;
      } else {
         this.minDaysLeftField = null;
      }

      fieldY += 12;
      String loreArrow = this.loreExpanded ? "▼" : "▶";
      String loreCount = this.loreEntries.isEmpty() ? "" : " §8(" + this.loreEntries.size() + ")";
      this.method_37063(new Button(this.contentX, fieldY - 5, this.contentW - 55, 16, "§6" + loreArrow + " §aLORE MATCHING" + loreCount, (btn) -> {
         this.loreExpanded = !this.loreExpanded;
         this.loreScrollOffset = 0;
         this.method_25426();
      }, -1, false));
      this.method_37063(new Button(this.contentX + this.contentW - 35, fieldY - 5, 35, 16, "+ Add", (btn) -> this.addLoreEntry(), -12255420, false));
      fieldY += 18;
      if (this.loreExpanded) {
         int visibleCount = Math.min(this.loreEntries.size(), this.maxVisibleLore);
         int maxScroll = Math.max(0, this.loreEntries.size() - this.maxVisibleLore);
         this.loreScrollOffset = Math.min(this.loreScrollOffset, maxScroll);
         if (this.loreScrollOffset > 0) {
            this.method_37063(new Button(this.contentX + this.contentW / 2 - 40, fieldY - 2, 80, 10, "§7▲ Scroll Up ▲", (btn) -> {
               --this.loreScrollOffset;
               this.method_25426();
            }, 0, false));
            fieldY += 12;
         }

         for(int i = this.loreScrollOffset; i < this.loreScrollOffset + visibleCount && i < this.loreEntries.size(); ++i) {
            this.addLoreEntryWidgets(i, fieldY);
            fieldY += 25;
         }

         if (this.loreScrollOffset + visibleCount < this.loreEntries.size()) {
            this.method_37063(new Button(this.contentX + this.contentW / 2 - 40, fieldY, 80, 10, "§7▼ Scroll (" + (this.loreEntries.size() - this.loreScrollOffset - visibleCount) + " more) ▼", (btn) -> {
               ++this.loreScrollOffset;
               this.method_25426();
            }, 0, false));
            fieldY += 12;
         }
      }

      fieldY += 15;
      String enchantArrow = this.enchantExpanded ? "▼" : "▶";
      String enchantCount = this.enchantEntries.isEmpty() ? "" : " §8(" + this.enchantEntries.size() + ")";
      this.method_37063(new Button(this.contentX, fieldY - 5, this.contentW - 55, 16, "§b" + enchantArrow + " §dENCHANT MATCHING" + enchantCount, (btn) -> {
         this.enchantExpanded = !this.enchantExpanded;
         this.enchantScrollOffset = 0;
         this.method_25426();
      }, -1, false));
      this.method_37063(new Button(this.contentX + this.contentW - 35, fieldY - 5, 35, 16, "+ Add", (btn) -> this.addEnchantEntry(), -11141121, false));
      fieldY += 18;
      if (this.enchantExpanded) {
         int visibleCount = Math.min(this.enchantEntries.size(), this.maxVisibleEnchant);
         int maxScroll = Math.max(0, this.enchantEntries.size() - this.maxVisibleEnchant);
         this.enchantScrollOffset = Math.min(this.enchantScrollOffset, maxScroll);
         if (this.enchantScrollOffset > 0) {
            this.method_37063(new Button(this.contentX + this.contentW / 2 - 40, fieldY - 2, 80, 10, "§7▲ Scroll Up ▲", (btn) -> {
               --this.enchantScrollOffset;
               this.method_25426();
            }, 0, false));
            fieldY += 12;
         }

         for(int i = this.enchantScrollOffset; i < this.enchantScrollOffset + visibleCount && i < this.enchantEntries.size(); ++i) {
            this.addEnchantEntryWidgets(i, fieldY);
            fieldY += 25;
         }

         if (this.enchantScrollOffset + visibleCount < this.enchantEntries.size()) {
            this.method_37063(new Button(this.contentX + this.contentW / 2 - 40, fieldY, 80, 10, "§7▼ Scroll (" + (this.enchantEntries.size() - this.enchantScrollOffset - visibleCount) + " more) ▼", (btn) -> {
               ++this.enchantScrollOffset;
               this.method_25426();
            }, 0, false));
            fieldY += 12;
         }
      }

      fieldY += 15;
      String bannedArrow = this.bannedExpanded ? "▼" : "▶";
      String bannedCount = this.bannedEnchantEntries.isEmpty() ? "" : " §8(" + this.bannedEnchantEntries.size() + ")";
      this.method_37063(new Button(this.contentX, fieldY - 5, this.contentW - 55, 16, "§c" + bannedArrow + " §4BANNED ENCHANTS" + bannedCount, (btn) -> {
         this.bannedExpanded = !this.bannedExpanded;
         this.bannedScrollOffset = 0;
         this.method_25426();
      }, -1, false));
      this.method_37063(new Button(this.contentX + this.contentW - 35, fieldY - 5, 35, 16, "+ Add", (btn) -> this.addBannedEnchantEntry(), -48060, false));
      fieldY += 18;
      if (this.bannedExpanded) {
         int visibleCount = Math.min(this.bannedEnchantEntries.size(), this.maxVisibleBanned);
         int maxScroll = Math.max(0, this.bannedEnchantEntries.size() - this.maxVisibleBanned);
         this.bannedScrollOffset = Math.min(this.bannedScrollOffset, maxScroll);
         if (this.bannedScrollOffset > 0) {
            this.method_37063(new Button(this.contentX + this.contentW / 2 - 40, fieldY - 2, 80, 10, "§7▲ Scroll Up ▲", (btn) -> {
               --this.bannedScrollOffset;
               this.method_25426();
            }, 0, false));
            fieldY += 12;
         }

         for(int i = this.bannedScrollOffset; i < this.bannedScrollOffset + visibleCount && i < this.bannedEnchantEntries.size(); ++i) {
            this.addBannedEnchantEntryWidgets(i, fieldY);
            fieldY += 25;
         }

         if (this.bannedScrollOffset + visibleCount < this.bannedEnchantEntries.size()) {
            this.method_37063(new Button(this.contentX + this.contentW / 2 - 40, fieldY, 80, 10, "§7▼ Scroll (" + (this.bannedEnchantEntries.size() - this.bannedScrollOffset - visibleCount) + " more) ▼", (btn) -> {
               ++this.bannedScrollOffset;
               this.method_25426();
            }, 0, false));
            fieldY += 12;
         }
      }

      fieldY += 15;
      int btnY = this.panelY + this.panelH - 35;
      int btnW = (this.contentW - 10) / 2;
      this.method_37063(new Button(this.contentX, btnY, btnW, 24, this.isEditMode ? "§fUpdate" : "§fSave", (btn) -> this.saveAndClose(), -12255420, true));
      this.method_37063(new Button(this.contentX + btnW + 10, btnY, btnW, 24, "§fCancel", (btn) -> this.method_25419(), -48060, true));
      this.method_37063(new Button(this.panelX + this.panelW - 20, this.panelY + 4, 16, 16, "X", (btn) -> this.method_25419(), -48060, false));
   }

   private void addLoreEntryWidgets(int index, int y) {
      LoreEntry entry = (LoreEntry)this.loreEntries.get(index);
      class_342 lineField = new class_342(this.field_22793, this.contentX, y, 30, 18, class_2561.method_30163(""));
      lineField.method_47404(class_2561.method_30163("§8#"));
      lineField.method_1880(2);
      if (entry.lineNumber != null) {
         lineField.method_1852(String.valueOf(entry.lineNumber));
      }

      lineField.method_1863((text) -> {
         try {
            ((LoreEntry)this.loreEntries.get(index)).lineNumber = text.isEmpty() ? null : Integer.parseInt(text);
         } catch (Exception var4) {
            ((LoreEntry)this.loreEntries.get(index)).lineNumber = null;
         }

      });
      this.method_37063(lineField);
      class_342 contentField = new class_342(this.field_22793, this.contentX + 35, y, this.contentW - 75, 18, class_2561.method_30163(""));
      contentField.method_47404(class_2561.method_30163("§8Lore content..."));
      contentField.method_1880(128);
      contentField.method_1852(entry.content != null ? entry.content : "");
      contentField.method_1863((text) -> ((LoreEntry)this.loreEntries.get(index)).content = text);
      this.method_37063(contentField);
      this.method_37063(new Button(this.contentX + this.contentW - 35, y, 18, 18, "§c✖", (btn) -> this.removeLoreEntry(index), -48060, false));
   }

   private void addEnchantEntryWidgets(int index, int y) {
      EnchantEntry entry = (EnchantEntry)this.enchantEntries.get(index);
      String enchantName = entry.enchantmentName.isEmpty() ? "Select..." : entry.enchantmentName;
      this.method_37063(new Button(this.contentX, y, this.contentW - 90, 18, "§d" + enchantName, (btn) -> this.openEnchantPicker(index, false), -11141121, false));
      class_342 levelField = new class_342(this.field_22793, this.contentX + this.contentW - 85, y, 30, 18, class_2561.method_30163(""));
      levelField.method_47404(class_2561.method_30163("§8Lv"));
      levelField.method_1880(2);
      levelField.method_1852(String.valueOf(entry.minLevel));
      levelField.method_1863((text) -> {
         try {
            ((EnchantEntry)this.enchantEntries.get(index)).minLevel = Math.max(1, Integer.parseInt(text));
         } catch (Exception var4) {
            ((EnchantEntry)this.enchantEntries.get(index)).minLevel = 1;
         }

      });
      this.method_37063(levelField);
      this.method_37063(new Button(this.contentX + this.contentW - 35, y, 18, 18, "§c✖", (btn) -> this.removeEnchantEntry(index), -48060, false));
   }

   private void addBannedEnchantEntryWidgets(int index, int y) {
      EnchantEntry entry = (EnchantEntry)this.bannedEnchantEntries.get(index);
      String enchantName = entry.enchantmentName.isEmpty() ? "Select banned..." : entry.enchantmentName;
      this.method_37063(new Button(this.contentX, y, this.contentW - 35, 18, "§c" + enchantName, (btn) -> this.openEnchantPicker(index, true), -48060, false));
      this.method_37063(new Button(this.contentX + this.contentW - 35, y, 18, 18, "§c✖", (btn) -> this.removeBannedEnchantEntry(index), -48060, false));
   }

   private void openItemPicker() {
      class_310.method_1551().method_1507(new ItemPickerScreen(this, (itemId) -> {
         this.selectedMaterial = itemId;
         this.selectedItemStack = this.createItemStack(itemId);
         this.method_25426();
      }));
   }

   private void openEnchantPicker(int index, boolean banned) {
      class_310.method_1551().method_1507(new EnchantPickerScreen(this, (entry) -> {
         if (banned) {
            if (index < this.bannedEnchantEntries.size()) {
               this.bannedEnchantEntries.set(index, entry);
               this.method_25426();
            }
         } else if (index < this.enchantEntries.size()) {
            this.enchantEntries.set(index, entry);
            this.method_25426();
         }

      }));
   }

   private void addLoreEntry() {
      this.loreEntries.add(new LoreEntry());
      this.method_25426();
   }

   private void removeLoreEntry(int index) {
      if (index >= 0 && index < this.loreEntries.size()) {
         this.loreEntries.remove(index);
         this.method_25426();
      }

   }

   private void addEnchantEntry() {
      this.enchantEntries.add(new EnchantEntry());
      this.method_25426();
   }

   private void removeEnchantEntry(int index) {
      if (index >= 0 && index < this.enchantEntries.size()) {
         this.enchantEntries.remove(index);
         this.method_25426();
      }

   }

   private void addBannedEnchantEntry() {
      this.bannedEnchantEntries.add(new EnchantEntry());
      this.method_25426();
   }

   private void removeBannedEnchantEntry(int index) {
      if (index >= 0 && index < this.bannedEnchantEntries.size()) {
         this.bannedEnchantEntries.remove(index);
         this.method_25426();
      }

   }

   private void adjustQuantity(class_342 field, int delta) {
      try {
         int current = Integer.parseInt(field.method_1882());
         int newVal = Math.max(1, Math.min(999, current + delta));
         field.method_1852(String.valueOf(newVal));
      } catch (Exception var5) {
         field.method_1852("1");
      }

   }

   private void parseEnchantString(String enchantsStr, List<EnchantEntry> list) {
      String[] parts = enchantsStr.split(",");

      for(String part : parts) {
         String trimmed = part.trim();
         if (!trimmed.isEmpty()) {
            int level = 1;
            String name = trimmed;
            int lastSpace = trimmed.lastIndexOf(32);
            if (lastSpace != -1) {
               try {
                  level = Integer.parseInt(trimmed.substring(lastSpace + 1).trim());
                  name = trimmed.substring(0, lastSpace).trim();
               } catch (Exception var14) {
               }
            } else {
               int i;
               for(i = trimmed.length() - 1; i >= 0 && Character.isDigit(trimmed.charAt(i)); --i) {
               }

               if (i < trimmed.length() - 1 && i >= 0) {
                  name = trimmed.substring(0, i + 1);

                  try {
                     level = Integer.parseInt(trimmed.substring(i + 1));
                  } catch (Exception var15) {
                     level = 1;
                  }
               }
            }

            list.add(new EnchantEntry(name, name, level));
         }
      }

   }

   private String getItemDisplayName() {
      return this.selectedItemStack != null ? this.selectedItemStack.method_7964().getString() : this.selectedMaterial;
   }

   public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
      context.method_25294(0, 0, this.field_22789, this.field_22790, -1442840576);
      Panel.drawPanel(context, this.panelX, this.panelY, this.panelW, this.panelH, 10);
      Panel.drawHeader(context, this.panelX, this.panelY, this.panelW, 24);
      Panel.drawTrafficLights(context, this.panelX + 12, this.panelY + 11);
      String title = this.isEditMode ? "Edit Item" : "Add Item";
      context.method_51433(this.field_22793, title, this.field_22789 / 2 - this.field_22793.method_1727(title) / 2, this.panelY + 8, -1, false);
      if (this.selectedItemStack != null) {
         context.method_51427(this.selectedItemStack, this.contentX + 80 + 4, this.contentY + 10 + 2);
      }

      int labelY = this.contentY + 10;
      int labelWidth = 80;
      context.method_51433(this.field_22793, "Item:", this.contentX, labelY + 6, -5592406, false);
      labelY += 32;
      context.method_51433(this.field_22793, "Type:", this.contentX, labelY + 4, -5592406, false);
      int typeLabelX = this.contentX + labelWidth;
      context.method_51433(this.field_22793, "BUY", typeLabelX + 14, labelY + 5, this.buyEnabled ? -12255420 : -5592406, false);
      context.method_51433(this.field_22793, "SELL", typeLabelX + 84, labelY + 5, this.sellEnabled ? -22016 : -5592406, false);
      labelY += 28;
      context.method_51433(this.field_22793, "Name:", this.contentX, labelY + 4, -5592406, false);
      labelY += 28;
      context.method_51433(this.field_22793, "Buy Min:", this.contentX, labelY + 4, -5592406, false);
      context.method_51433(this.field_22793, "Sell Min:", this.contentX + 150, labelY + 4, -5592406, false);
      labelY += 28;
      context.method_51433(this.field_22793, "Buy Price:", this.contentX, labelY + 4, -5592406, false);
      labelY += 28;
      context.method_51433(this.field_22793, "Sell Price:", this.contentX, labelY + 4, -5592406, false);
      labelY += 28;
      if (this.shouldShowMinDays()) {
         context.method_51433(this.field_22793, "Min Days:", this.contentX, labelY + 4, -5592406, false);
         labelY += 28;
      }

      labelY += 12;
      super.method_25394(context, mouseX, mouseY, delta);
   }

   private void saveAndClose() {
      if (!this.selectedMaterial.isEmpty()) {
         double maxPrice;
         try {
            maxPrice = Double.parseDouble(this.maxPriceField.method_1882());
         } catch (Exception var19) {
            maxPrice = (double)0.0F;
         }

         double sellPrice;
         try {
            sellPrice = Double.parseDouble(this.sellPriceField.method_1882());
         } catch (Exception var18) {
            sellPrice = (double)0.0F;
         }

         int buyQty;
         try {
            buyQty = Integer.parseInt(this.quantityField.method_1882());
         } catch (Exception var17) {
            buyQty = 1;
         }

         int sellQty;
         try {
            sellQty = Integer.parseInt(this.sellQuantityField.method_1882());
         } catch (Exception var16) {
            sellQty = 1;
         }

         Integer minDays = null;
         if (this.minDaysLeftField != null) {
            try {
               minDays = this.minDaysLeftField.method_1882().isEmpty() ? null : Integer.parseInt(this.minDaysLeftField.method_1882());
            } catch (Exception var15) {
               minDays = null;
            }
         }

         StringBuilder loreBuilder = new StringBuilder();
         boolean skipNext = false;

         for(LoreEntry entry : this.loreEntries) {
            String content = entry.content;
            if (content != null && !content.isEmpty()) {
               if (skipNext) {
                  skipNext = false;
               } else {
                  String lowerContent = content.toLowerCase();
                  if (!lowerContent.contains("wygaśnie:") && !lowerContent.contains("wygasnie za") && !lowerContent.contains("wygasnie:")) {
                     if (lowerContent.contains("szyfr")) {
                        skipNext = true;
                     } else if (!lowerContent.matches("[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}")) {
                        if (loreBuilder.length() > 0) {
                           loreBuilder.append(";");
                        }

                        loreBuilder.append(content);
                     }
                  }
               }
            }
         }

         StringBuilder enchantBuilder = new StringBuilder();

         for(EnchantEntry entry : this.enchantEntries) {
            if (!entry.isEmpty()) {
               if (enchantBuilder.length() > 0) {
                  enchantBuilder.append(",");
               }

               String fullName = EnchantMapper.mapEnchant(entry.enchantmentId + entry.minLevel, true);
               enchantBuilder.append(fullName);
            }
         }

         StringBuilder bannedBuilder = new StringBuilder();

         for(EnchantEntry entry : this.bannedEnchantEntries) {
            if (!entry.isEmpty()) {
               if (bannedBuilder.length() > 0) {
                  bannedBuilder.append(",");
               }

               String baseName = EnchantMapper.mapEnchant(entry.enchantmentId + " 1", true);
               if (baseName.contains(" 1")) {
                  baseName = baseName.replace(" 1", "").trim();
               }

               bannedBuilder.append(baseName);
            }
         }

         if (this.isEditMode && this.editingEntry != null) {
            this.editingEntry.material = this.selectedMaterial;
            this.editingEntry.name = this.nameField.method_1882();
            this.editingEntry.requiredCount = buyQty;
            this.editingEntry.sellCount = sellQty;
            this.editingEntry.maxPrice = maxPrice;
            this.editingEntry.sellPrice = sellPrice;
            this.editingEntry.buyEnabled = this.buyEnabled;
            this.editingEntry.sellEnabled = this.sellEnabled;
            this.editingEntry.lore = loreBuilder.toString();
            this.editingEntry.enchants = enchantBuilder.toString();
            this.editingEntry.excludedEnchants = bannedBuilder.toString();
            this.editingEntry.minDaysLeft = minDays;
            this.editingEntry.customModelData = this.customModelData;
         } else {
            PriceEntry newEntry = new PriceEntry();
            newEntry.material = this.selectedMaterial;
            newEntry.name = this.nameField.method_1882();
            newEntry.requiredCount = buyQty;
            newEntry.sellCount = sellQty;
            newEntry.maxPrice = maxPrice;
            newEntry.sellPrice = sellPrice;
            newEntry.buyEnabled = this.buyEnabled;
            newEntry.sellEnabled = this.sellEnabled;
            newEntry.lore = loreBuilder.toString();
            newEntry.enchants = enchantBuilder.toString();
            newEntry.excludedEnchants = bannedBuilder.toString();
            newEntry.minDaysLeft = minDays;
            newEntry.customModelData = this.customModelData;
            ClientPriceListManager.addPriceEntry(newEntry);
         }

         ClientCommandRegistration.syncMemoryToConfig();
         ConfigLoader.saveAllConfigs(BkRynekClient.serversConfig);
         if (this.onComplete != null) {
            this.onComplete.accept(true);
         }

         this.method_25419();
      }
   }

   public void method_25419() {
      class_310.method_1551().method_1507(this.parent);
   }

   public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
      if (this.loreExpanded && this.loreEntries.size() > this.maxVisibleLore) {
         int maxScroll = this.loreEntries.size() - this.maxVisibleLore;
         if (verticalAmount < (double)0.0F) {
            this.loreScrollOffset = Math.min(this.loreScrollOffset + 1, maxScroll);
         } else if (verticalAmount > (double)0.0F) {
            this.loreScrollOffset = Math.max(this.loreScrollOffset - 1, 0);
         }

         this.method_25426();
         return true;
      } else if (this.enchantExpanded && this.enchantEntries.size() > this.maxVisibleEnchant) {
         int maxScroll = this.enchantEntries.size() - this.maxVisibleEnchant;
         if (verticalAmount < (double)0.0F) {
            this.enchantScrollOffset = Math.min(this.enchantScrollOffset + 1, maxScroll);
         } else if (verticalAmount > (double)0.0F) {
            this.enchantScrollOffset = Math.max(this.enchantScrollOffset - 1, 0);
         }

         this.method_25426();
         return true;
      } else if (this.bannedExpanded && this.bannedEnchantEntries.size() > this.maxVisibleBanned) {
         int maxScroll = this.bannedEnchantEntries.size() - this.maxVisibleBanned;
         if (verticalAmount < (double)0.0F) {
            this.bannedScrollOffset = Math.min(this.bannedScrollOffset + 1, maxScroll);
         } else if (verticalAmount > (double)0.0F) {
            this.bannedScrollOffset = Math.max(this.bannedScrollOffset - 1, 0);
         }

         this.method_25426();
         return true;
      } else {
         return super.method_25401(mouseX, mouseY, horizontalAmount, verticalAmount);
      }
   }

   private int availableForLists(int totalHeight) {
      return Math.max(1, totalHeight / 25);
   }

   public boolean method_25421() {
      return false;
   }
}
