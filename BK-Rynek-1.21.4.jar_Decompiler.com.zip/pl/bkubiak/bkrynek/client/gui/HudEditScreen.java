package pl.bkubiak.bkrynek.client.gui;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;
import pl.bkubiak.bkrynek.client.BkRynekClient;
import pl.bkubiak.bkrynek.client.config.ConfigLoader;
import pl.bkubiak.bkrynek.client.gui.widgets.Panel;

@Environment(EnvType.CLIENT)
public class HudEditScreen extends class_437 {
   private final class_437 parent;
   private boolean draggingHud = false;
   private boolean draggingLog = false;
   private int dragOffsetX = 0;
   private int dragOffsetY = 0;
   private static final int HUD_WIDTH = 150;
   private static final int HUD_HEIGHT = 86;
   private static final int LOG_WIDTH = 160;
   private static final int LOG_HEIGHT = 70;

   public HudEditScreen(class_437 parent) {
      super(class_2561.method_30163("HUD Editor"));
      this.parent = parent;
   }

   public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
      this.method_25420(context, mouseX, mouseY, delta);
      int hudX = BkRynekClient.serversConfig.hudX;
      int hudY = BkRynekClient.serversConfig.hudY;
      int logX = BkRynekClient.serversConfig.logX;
      int logY = BkRynekClient.serversConfig.logY;
      int centerX = this.field_22789 / 2;
      int centerY = this.field_22790 / 2;
      int curX = this.draggingLog ? logX : hudX;
      int curY = this.draggingLog ? logY : hudY;
      int curW = this.draggingLog ? 160 : 150;
      int curH = this.draggingLog ? 70 : 86;
      if (Math.abs(curX + curW / 2 - centerX) < 2) {
         context.method_25294(centerX, 0, centerX + 1, this.field_22790, -855660032);
      }

      if (Math.abs(curY + curH / 2 - centerY) < 2) {
         context.method_25294(0, centerY, this.field_22789, centerY + 1, -855660032);
      }

      Panel.drawRoundedRect(context, hudX - 2, hudY - 2, 154, 90, 4, 1157627903);
      Panel.drawRoundedRect(context, hudX, hudY, 150, 86, 4, -301002990);
      context.method_25300(this.field_22793, "§b[HUD STATS]", hudX + 75, hudY + 12, -1);
      context.method_25300(this.field_22793, String.format("§7X:%d Y:%d", hudX, hudY), hudX + 75, hudY + 28, -1);
      Panel.drawRoundedRect(context, logX - 2, logY - 2, 164, 74, 4, 1157627903);
      Panel.drawRoundedRect(context, logX, logY, 160, 70, 4, -301002990);
      context.method_25300(this.field_22793, "§e[SNIPE LOG]", logX + 80, logY + 12, -1);
      context.method_25300(this.field_22793, String.format("§7X:%d Y:%d", logX, logY), logX + 80, logY + 28, -1);
      context.method_25300(this.field_22793, "HUD Edycja: Przeciągnij elementy myszką", this.field_22789 / 2, 20, -1);
      context.method_25300(this.field_22793, "§eKliknij poza elementami, aby zapisać i zamknąć", this.field_22789 / 2, 32, -5592406);
      super.method_25394(context, mouseX, mouseY, delta);
   }

   public boolean method_25402(double mouseX, double mouseY, int button) {
      int hudX = BkRynekClient.serversConfig.hudX;
      int hudY = BkRynekClient.serversConfig.hudY;
      int logX = BkRynekClient.serversConfig.logX;
      int logY = BkRynekClient.serversConfig.logY;
      if (mouseX >= (double)hudX && mouseX <= (double)(hudX + 150) && mouseY >= (double)hudY && mouseY <= (double)(hudY + 86)) {
         this.draggingHud = true;
         this.dragOffsetX = (int)mouseX - hudX;
         this.dragOffsetY = (int)mouseY - hudY;
         return true;
      } else if (mouseX >= (double)logX && mouseX <= (double)(logX + 160) && mouseY >= (double)logY && mouseY <= (double)(logY + 70)) {
         this.draggingLog = true;
         this.dragOffsetX = (int)mouseX - logX;
         this.dragOffsetY = (int)mouseY - logY;
         return true;
      } else {
         this.method_25419();
         return true;
      }
   }

   public boolean method_25406(double mouseX, double mouseY, int button) {
      this.draggingHud = false;
      this.draggingLog = false;
      return super.method_25406(mouseX, mouseY, button);
   }

   public boolean method_25403(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
      if (!this.draggingHud && !this.draggingLog) {
         return super.method_25403(mouseX, mouseY, button, deltaX, deltaY);
      } else {
         int curW = this.draggingLog ? 160 : 150;
         int curH = this.draggingLog ? 70 : 86;
         int newX = (int)mouseX - this.dragOffsetX;
         int newY = (int)mouseY - this.dragOffsetY;
         int centerX = this.field_22789 / 2;
         int centerY = this.field_22790 / 2;
         int snapRange = 8;
         if (Math.abs(newX + curW / 2 - centerX) < snapRange) {
            newX = centerX - curW / 2;
         }

         if (newX < snapRange) {
            newX = 0;
         }

         if (newX > this.field_22789 - curW - snapRange) {
            newX = this.field_22789 - curW;
         }

         if (Math.abs(newY + curH / 2 - centerY) < snapRange) {
            newY = centerY - curH / 2;
         }

         if (newY < snapRange) {
            newY = 0;
         }

         if (newY > this.field_22790 - curH - snapRange) {
            newY = this.field_22790 - curH;
         }

         if (this.draggingHud) {
            BkRynekClient.serversConfig.hudX = newX;
            BkRynekClient.serversConfig.hudY = newY;
         } else {
            BkRynekClient.serversConfig.logX = newX;
            BkRynekClient.serversConfig.logY = newY;
         }

         return true;
      }
   }

   public void method_25419() {
      ConfigLoader.saveAllConfigs(BkRynekClient.serversConfig);
      this.field_22787.method_1507(this.parent);
   }
}
