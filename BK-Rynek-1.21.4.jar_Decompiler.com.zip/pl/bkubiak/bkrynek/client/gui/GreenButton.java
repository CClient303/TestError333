package pl.bkubiak.bkrynek.client.gui;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_4185;

@Environment(EnvType.CLIENT)
public class GreenButton extends class_4185 {
   protected int borderColor;

   public GreenButton(int x, int y, int width, int height, String text, class_4185.class_4241 onPress, int borderColor) {
      super(x, y, width, height, class_2561.method_30163(text), onPress, field_40754);
      this.borderColor = borderColor;
   }

   public void update(String text, int color) {
      this.method_25355(class_2561.method_30163(text));
      this.borderColor = color;
   }

   protected void method_48579(class_332 context, int mouseX, int mouseY, float delta) {
      int bgColor = this.method_49606() ? -15058406 : -16115190;
      context.method_25294(this.method_46426(), this.method_46427(), this.method_46426() + this.field_22758, this.method_46427() + this.field_22759, bgColor);
      int colorToDraw = this.borderColor;
      context.method_25294(this.method_46426(), this.method_46427(), this.method_46426() + this.field_22758, this.method_46427() + 1, colorToDraw);
      context.method_25294(this.method_46426(), this.method_46427() + this.field_22759 - 1, this.method_46426() + this.field_22758, this.method_46427() + this.field_22759, colorToDraw);
      context.method_25294(this.method_46426(), this.method_46427(), this.method_46426() + 1, this.method_46427() + this.field_22759, colorToDraw);
      context.method_25294(this.method_46426() + this.field_22758 - 1, this.method_46427(), this.method_46426() + this.field_22758, this.method_46427() + this.field_22759, colorToDraw);
      class_327 tr = class_310.method_1551().field_1772;
      class_2561 msg = this.method_25369();
      int textWidth = tr.method_27525(msg);
      int textX = this.method_46426() + (this.field_22758 - textWidth) / 2;
      int textY = this.method_46427() + (this.field_22759 - 8) / 2;
      int textColor = this.method_49606() ? -1 : colorToDraw;
      context.method_27535(tr, msg, textX, textY, textColor);
   }
}
