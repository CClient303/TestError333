package pl.bkubiak.bkrynek.client.gui;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonParser;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_364;
import net.minecraft.class_437;
import pl.bkubiak.bkrynek.client.BkRynekClient;
import pl.bkubiak.bkrynek.client.command.ClientCommandRegistration;
import pl.bkubiak.bkrynek.client.gui.widgets.Button;
import pl.bkubiak.bkrynek.client.gui.widgets.MultiLineEditor;
import pl.bkubiak.bkrynek.client.gui.widgets.Panel;
import pl.bkubiak.bkrynek.client.gui.widgets.TabButton;
import pl.bkubiak.bkrynek.client.gui.widgets.ToggleButton;
import pl.bkubiak.bkrynek.client.util.ToastManager;
import pl.bkubiak.bkrynek.core.config.CoreConfigLoader;
import pl.bkubiak.bkrynek.core.config.ServerEntry;
import pl.bkubiak.bkrynek.core.config.ServersConfig;
import pl.bkubiak.bkrynek.core.manager.ClientPriceListManager;

@Environment(EnvType.CLIENT)
public class ConfigEditorScreen extends class_437 {
   private Tab currentTab;
   private MultiLineEditor editor;
   private String originalJson;
   private boolean jsonValid;
   private String validationError;
   private class_342 webhookUrlField;
   private ToggleButton webhookBuyToggle;
   private ToggleButton webhookSellToggle;
   private class_342 loginCommandField;
   private ToggleButton premiumAccountToggle;
   private ToggleButton autoReconnectToggle;
   private double presetScrollOffset;
   private Button saveButton;
   private Button revertButton;
   private Button defaultsButton;
   private Button cancelButton;
   private static final int PADDING = 20;
   private static final int HEADER_HEIGHT = 35;
   private static final int FOOTER_HEIGHT = 45;

   public ConfigEditorScreen() {
      super(class_2561.method_43470("Config Editor"));
      this.currentTab = ConfigEditorScreen.Tab.EDITOR;
      this.jsonValid = true;
      this.validationError = "";
      this.presetScrollOffset = (double)0.0F;
   }

   protected void method_25426() {
      super.method_25426();
      ClientCommandRegistration.syncMemoryToConfig();
      if (this.originalJson == null) {
         this.originalJson = (new GsonBuilder()).setPrettyPrinting().create().toJson(BkRynekClient.serversConfig);
      }

      int tabW = 80;
      int tabH = 18;
      int tabX = 260;
      this.method_37063(new TabButton(tabX, 30, tabW, tabH, "JSON", this.currentTab == ConfigEditorScreen.Tab.EDITOR, (btn) -> this.switchTab(ConfigEditorScreen.Tab.EDITOR)));
      this.method_37063(new TabButton(tabX + tabW + 5, 30, tabW, tabH, "WEBHOOK", this.currentTab == ConfigEditorScreen.Tab.WEBHOOK, (btn) -> this.switchTab(ConfigEditorScreen.Tab.WEBHOOK)));
      this.method_37063(new TabButton(tabX + (tabW + 5) * 2, 30, tabW, tabH, "PRESETS", this.currentTab == ConfigEditorScreen.Tab.PRESETS, (btn) -> this.switchTab(ConfigEditorScreen.Tab.PRESETS)));
      this.method_37063(new TabButton(tabX + (tabW + 5) * 3, 30, tabW, tabH, "RECONNECT", this.currentTab == ConfigEditorScreen.Tab.RECONNECT, (btn) -> this.switchTab(ConfigEditorScreen.Tab.RECONNECT)));
      int editorX = 20;
      int editorY = 55;
      int editorW = this.field_22789 - 40;
      int editorH = this.field_22790 - 40 - 35 - 45;
      String currentText = this.editor != null ? this.editor.getText() : this.originalJson;
      int oldCursorLine = this.editor != null ? this.editor.getCursorLine() : 0;
      int oldCursorCol = this.editor != null ? this.editor.getCursorColumn() : 0;
      int oldScroll = this.editor != null ? this.editor.getScrollOffset() : 0;
      this.editor = new MultiLineEditor(editorX, editorY, editorW, editorH, currentText);
      this.editor.setCursorLine(oldCursorLine);
      this.editor.setCursorColumn(oldCursorCol);
      this.editor.setScrollOffset(oldScroll);
      if (this.currentTab == ConfigEditorScreen.Tab.EDITOR) {
         this.editor.setFocused(true);
      } else if (this.currentTab == ConfigEditorScreen.Tab.WEBHOOK) {
         this.initWebhookUI();
      } else if (this.currentTab == ConfigEditorScreen.Tab.PRESETS) {
         this.initPresetsUI();
      } else if (this.currentTab == ConfigEditorScreen.Tab.RECONNECT) {
         this.initReconnectUI();
      }

      int buttonY = this.field_22790 - 20 - 30;
      int buttonW = 80;
      this.saveButton = new Button(this.field_22789 - 20 - buttonW, buttonY, buttonW, 24, "Save", (btn) -> this.saveAndReload(), -16720555, -1, true);
      this.revertButton = new Button(this.field_22789 - 20 - buttonW * 2 - 10, buttonY, buttonW, 24, "Revert", (btn) -> this.revert(), -22016, -1, true);
      this.defaultsButton = new Button(this.field_22789 - 20 - buttonW * 2 - 10 - 110 - 10, buttonY, 110, 24, "Load Defaults", (btn) -> this.loadDefaults(), -11141121, -1, true);
      this.cancelButton = new Button(20, buttonY, buttonW, 24, "Cancel", (btn) -> this.method_25419(), -48060, -1, true);
      this.method_37063(this.saveButton);
      this.method_37063(this.revertButton);
      this.method_37063(this.defaultsButton);
      this.method_37063(this.cancelButton);
      this.validateJson();
   }

   private void initWebhookUI() {
      int contentX = 60;
      int fieldY = 125;
      this.webhookUrlField = new class_342(this.field_22793, contentX, fieldY, 300, 16, class_2561.method_30163(""));
      this.webhookUrlField.method_1880(512);
      this.webhookUrlField.method_1852(BkRynekClient.serversConfig.discordWebhookUrl);
      this.method_37063(this.webhookUrlField);
      int toggleY = fieldY + 40;
      this.webhookBuyToggle = new ToggleButton(contentX, toggleY, 80, 18, () -> BkRynekClient.serversConfig.webhookBuyEnabled ? "§a✔§f BUY" : "§c✖§f BUY", (btn) -> BkRynekClient.serversConfig.webhookBuyEnabled = !BkRynekClient.serversConfig.webhookBuyEnabled, () -> BkRynekClient.serversConfig.webhookBuyEnabled ? -12255420 : -48060);
      this.method_37063(this.webhookBuyToggle);
      this.webhookSellToggle = new ToggleButton(contentX + 90, toggleY, 80, 18, () -> BkRynekClient.serversConfig.webhookSellEnabled ? "§a✔§f SELL" : "§c✖§f SELL", (btn) -> BkRynekClient.serversConfig.webhookSellEnabled = !BkRynekClient.serversConfig.webhookSellEnabled, () -> BkRynekClient.serversConfig.webhookSellEnabled ? -12255420 : -48060);
      this.method_37063(this.webhookSellToggle);
      this.method_37063(new ToggleButton(contentX + 180, toggleY, 80, 18, () -> BkRynekClient.serversConfig.webhookListingEnabled ? "§a✔§f LISTING" : "§c✖§f LISTING", (btn) -> BkRynekClient.serversConfig.webhookListingEnabled = !BkRynekClient.serversConfig.webhookListingEnabled, () -> BkRynekClient.serversConfig.webhookListingEnabled ? -12255420 : -48060));
   }

   private void initReconnectUI() {
      int contentX = 60;
      int contentY = 80;
      ServerEntry entry = BkRynekClient.findServerEntry(BkRynekClient.getServerAddress());
      if (entry != null) {
         int settingsY = contentY + 60;
         this.premiumAccountToggle = new ToggleButton(contentX, settingsY, 150, 20, () -> entry.usePremiumAccount ? "§a✔§f PREMIUM MODE" : "§c✖§f NON-PREMIUM", (btn) -> entry.usePremiumAccount = !entry.usePremiumAccount, () -> entry.usePremiumAccount ? -12255420 : -22016);
         this.method_37063(this.premiumAccountToggle);
         this.autoReconnectToggle = new ToggleButton(contentX + 160, settingsY, 150, 20, () -> entry.autoReconnect ? "§a✔§f RECONNECT" : "§c✖§f RECONNECT", (btn) -> entry.autoReconnect = !entry.autoReconnect, () -> entry.autoReconnect ? -12255420 : -48060);
         this.method_37063(this.autoReconnectToggle);
         int loginY = contentY + 110;
         this.loginCommandField = new class_342(this.field_22793, contentX, loginY, 400, 16, class_2561.method_30163(""));
         this.loginCommandField.method_1880(256);
         this.loginCommandField.method_1852(entry.loginCommand);
         this.method_37063(this.loginCommandField);
      }
   }

   private void initPresetsUI() {
   }

   private void syncFieldsToConfig() {
      if (this.currentTab == ConfigEditorScreen.Tab.EDITOR) {
         this.validateJson();
         if (this.jsonValid) {
            ServersConfig cfg = this.parseCurrentConfig();
            if (cfg != null) {
               BkRynekClient.serversConfig = cfg;
            }
         }
      } else if (this.currentTab == ConfigEditorScreen.Tab.RECONNECT) {
         ServerEntry entry = BkRynekClient.findServerEntry(BkRynekClient.getServerAddress());
         if (entry != null && this.loginCommandField != null) {
            entry.loginCommand = this.loginCommandField.method_1882();
         }
      } else if (this.currentTab == ConfigEditorScreen.Tab.WEBHOOK && this.webhookUrlField != null) {
         BkRynekClient.serversConfig.discordWebhookUrl = this.webhookUrlField.method_1882();
      }

   }

   private void switchTab(Tab newTab) {
      this.syncFieldsToConfig();
      if (this.currentTab == ConfigEditorScreen.Tab.EDITOR && !this.jsonValid) {
         ToastManager.show("§cFix JSON errors before switching!", 16711680);
      } else {
         if (newTab == ConfigEditorScreen.Tab.EDITOR) {
            this.syncConfigToEditor();
         }

         this.currentTab = newTab;
         this.method_41843();
      }
   }

   private void syncConfigToEditor() {
      if (this.editor != null) {
         this.editor.setText((new GsonBuilder()).setPrettyPrinting().create().toJson(BkRynekClient.serversConfig));
      }

   }

   private ServersConfig parseCurrentConfig() {
      try {
         return (ServersConfig)(new Gson()).fromJson(this.editor.getText(), ServersConfig.class);
      } catch (Exception var2) {
         return null;
      }
   }

   public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
      context.method_25296(0, 0, this.field_22789, this.field_22790, -872415232, -587202560);
      Panel.drawRoundedRect(context, 20, 20, this.field_22789 - 40, 35, 6, -15395563);
      context.method_51433(this.field_22793, "SETTINGS", 30, 32, -1, false);
      context.method_51433(this.field_22793, "§7" + this.currentTab.name(), 100, 32, -5592406, false);
      if (this.currentTab == ConfigEditorScreen.Tab.EDITOR) {
         if (this.editor != null) {
            this.editor.render(context, this.field_22793, mouseX, mouseY);
         }

         int footerY = this.field_22790 - 20 - 45;
         Panel.drawRoundedRect(context, 20, footerY, this.field_22789 - 40, 45, 6, -15395563);
         String statusIcon = this.jsonValid ? "✔" : "✖";
         int statusColor = this.jsonValid ? -12255420 : -48060;
         context.method_51433(this.field_22793, statusIcon, 32, footerY + 10, statusColor, false);
         context.method_51433(this.field_22793, this.jsonValid ? "Valid JSON" : "Invalid JSON", 45, footerY + 10, statusColor, false);
         if (!this.jsonValid && !this.validationError.isEmpty()) {
            context.method_51433(this.field_22793, "§c" + this.validationError, 32, footerY + 22, -5592406, false);
         }

         this.saveButton.field_22763 = this.jsonValid;
      } else if (this.currentTab == ConfigEditorScreen.Tab.WEBHOOK) {
         this.renderWebhookTab(context);
         this.saveButton.field_22763 = true;
      } else if (this.currentTab == ConfigEditorScreen.Tab.PRESETS) {
         this.renderPresetsTab(context, mouseX, mouseY);
         this.saveButton.field_22763 = true;
      } else {
         this.renderReconnectTab(context);
         this.saveButton.field_22763 = true;
      }

      super.method_25394(context, mouseX, mouseY, delta);
   }

   private void renderWebhookTab(class_332 context) {
      int editorH = this.field_22790 - 40 - 35 - 45;
      Panel.drawPanel(context, 20, 55, this.field_22789 - 40, editorH, 6);
      int contentX = 60;
      int contentY = 80;
      context.method_51433(this.field_22793, "DISCORD WEBHOOK CONFIGURATION", contentX, contentY, -11141121, false);
      context.method_51433(this.field_22793, "§7Paste your Discord webhook URL here to receive notifications.", contentX, contentY + 15, -5592406, false);
      context.method_51433(this.field_22793, "WEBHOOK URL:", contentX, contentY + 45, -1, false);
   }

   private void renderReconnectTab(class_332 context) {
      int editorH = this.field_22790 - 40 - 35 - 45;
      Panel.drawPanel(context, 20, 55, this.field_22789 - 40, editorH, 6);
      int contentX = 60;
      int contentY = 80;
      context.method_51433(this.field_22793, "RECONNECT SETTINGS:", contentX, contentY, -16720555, false);
      context.method_51433(this.field_22793, "§7Mod will automatically reconnect and perform sequences.", contentX, contentY + 14, -5592406, false);
      context.method_51433(this.field_22793, "Server Settings:", contentX, contentY + 48, -1, false);
      context.method_51433(this.field_22793, "Login Command (e.g. /login <hasło>):", contentX, contentY + 95, -1, false);
   }

   private void renderPresetsTab(class_332 context, int mouseX, int mouseY) {
      int editorH = this.field_22790 - 40 - 35 - 45;
      Panel.drawPanel(context, 20, 55, this.field_22789 - 40, editorH, 6);
      int contentX = 60;
      int contentY = 80;
      context.method_51433(this.field_22793, "§7Click on a preset below to load its prices and settings.", contentX, contentY + 15, -5592406, false);
      int listX = 60;
      int listY = 125;
      int listW = this.field_22789 - 40 - 80;
      int listH = editorH - 80;
      if (listH > 10) {
         context.method_51433(this.field_22793, "SAVED PRESETS (click name to load):", listX, listY - 15, -5592406, false);
         List<String> presets = ClientPriceListManager.listPresets();
         context.method_25294(listX, listY - 4, listX + listW, listY - 3, 587202559);
         context.method_44379(listX, listY, listX + listW, listY + listH);

         for(int i = 0; i < presets.size(); ++i) {
            String name = (String)presets.get(i);
            int rowY = listY + i * 22 - (int)this.presetScrollOffset;
            if (rowY >= listY - 22 && rowY <= listY + listH) {
               boolean hovered = mouseX >= listX && mouseX <= listX + listW && mouseY >= rowY && mouseY < rowY + 22;
               boolean isActive = name.equals(CoreConfigLoader.getActiveConfigName());
               int bgColor = hovered ? 587202559 : 184549375;
               if (isActive) {
                  bgColor = 861273941;
               }

               Panel.drawRoundedRect(context, listX, rowY + 1, listW, 20, 4, bgColor);
               int color = hovered ? -1 : (isActive ? -12255420 : -10066330);
               String label = name.equals("bkrynek-config") ? "bkrynek-config.json (Main)" : name;
               context.method_51433(this.field_22793, (isActive ? "§a▶ §f" : "") + label, 60, rowY + 6, color, false);
               if (hovered) {
                  int loadX = this.field_22789 - 20 - 200;
                  boolean loadHovered = mouseX >= loadX && mouseX <= loadX + 40 && mouseY >= rowY + 4 && mouseY <= rowY + 16;
                  context.method_51433(this.field_22793, "§a[LOAD]", loadX, rowY + 6, loadHovered ? -1 : -5592406, false);
                  int saveX = this.field_22789 - 20 - 145;
                  boolean saveHovered = mouseX >= saveX && mouseX <= saveX + 40 && mouseY >= rowY + 4 && mouseY <= rowY + 16;
                  context.method_51433(this.field_22793, "§6[SAVE]", saveX, rowY + 6, saveHovered ? -1 : -5592406, false);
                  int delX = this.field_22789 - 20 - 90;
                  boolean delHovered = mouseX >= delX && mouseX <= delX + 40 && mouseY >= rowY + 4 && mouseY <= rowY + 16;
                  context.method_51433(this.field_22793, "§c[DEL]", delX, rowY + 6, delHovered ? -1 : -5592406, false);
               }
            }
         }

         context.method_44380();
      }

   }

   public boolean method_25402(double mouseX, double mouseY, int button) {
      if (this.currentTab == ConfigEditorScreen.Tab.EDITOR && this.editor != null && this.editor.mouseClicked((int)mouseX, (int)mouseY, button)) {
         this.method_25395((class_364)null);
         return true;
      } else if (this.currentTab == ConfigEditorScreen.Tab.WEBHOOK && this.webhookUrlField != null && this.webhookUrlField.method_25402(mouseX, mouseY, button)) {
         this.method_25395(this.webhookUrlField);
         return true;
      } else if (this.currentTab == ConfigEditorScreen.Tab.RECONNECT && this.loginCommandField != null && this.loginCommandField.method_25402(mouseX, mouseY, button)) {
         this.method_25395(this.loginCommandField);
         return true;
      } else {
         if (this.currentTab == ConfigEditorScreen.Tab.PRESETS) {
            List<String> presets = ClientPriceListManager.listPresets();
            int listY = 125;
            int listW = this.field_22789 - 40 - 80;

            for(int i = 0; i < presets.size(); ++i) {
               String name = (String)presets.get(i);
               int rowY = listY + i * 22 - (int)this.presetScrollOffset;
               if (mouseX >= (double)60.0F && mouseX <= (double)(60 + listW) && mouseY >= (double)rowY && mouseY < (double)(rowY + 22)) {
                  int delX = this.field_22789 - 20 - 90;
                  int saveX = this.field_22789 - 20 - 145;
                  int loadX = this.field_22789 - 20 - 200;
                  if (mouseX >= (double)delX && mouseX <= (double)(delX + 40) && !name.equals("bkrynek-config")) {
                     if (ClientPriceListManager.deletePreset(name)) {
                        ClientCommandRegistration.syncMemoryToConfig();
                        this.syncConfigToEditor();
                        ToastManager.show("§cPreset deleted!", 16733525);
                     }

                     return true;
                  }

                  if (mouseX >= (double)loadX && mouseX <= (double)(loadX + 40)) {
                     CoreConfigLoader.setActiveConfigName(name);
                     BkRynekClient.reloadFromConfig(CoreConfigLoader.reloadConfig());
                     ToastManager.show("§aSwitched to config: " + name, 5635925);
                     this.method_25419();
                     return true;
                  }

                  if (mouseX >= (double)saveX && mouseX <= (double)(saveX + 40)) {
                     try {
                        this.syncFieldsToConfig();
                        ServersConfig toSave = this.currentTab == ConfigEditorScreen.Tab.EDITOR ? this.parseCurrentConfig() : BkRynekClient.serversConfig;
                        if (toSave != null) {
                           CoreConfigLoader.saveSnapshot(name, toSave);
                           ToastManager.show("§aCurrent settings saved to " + name + ".json", 5635925);
                        } else {
                           ToastManager.show("§cInvalid config, cannot save!", 16733525);
                        }
                     } catch (Exception var16) {
                        ToastManager.show("§cSave failed!", 16733525);
                     }

                     return true;
                  }
               }
            }
         }

         return super.method_25402(mouseX, mouseY, button);
      }
   }

   public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
      if (this.currentTab == ConfigEditorScreen.Tab.EDITOR && this.editor != null && this.editor.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount)) {
         return true;
      } else if (this.currentTab == ConfigEditorScreen.Tab.PRESETS) {
         this.presetScrollOffset -= verticalAmount * (double)12.0F;
         if (this.presetScrollOffset < (double)0.0F) {
            this.presetScrollOffset = (double)0.0F;
         }

         return true;
      } else {
         return super.method_25401(mouseX, mouseY, horizontalAmount, verticalAmount);
      }
   }

   public boolean method_25403(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
      return this.currentTab == ConfigEditorScreen.Tab.EDITOR && this.editor != null && this.editor.mouseDragged((int)mouseX, (int)mouseY) ? true : super.method_25403(mouseX, mouseY, button, deltaX, deltaY);
   }

   public boolean method_25406(double mouseX, double mouseY, int button) {
      return this.currentTab == ConfigEditorScreen.Tab.EDITOR && this.editor != null && this.editor.mouseReleased((int)mouseX, (int)mouseY, button) ? true : super.method_25406(mouseX, mouseY, button);
   }

   public boolean method_25404(int keyCode, int scanCode, int modifiers) {
      if (this.currentTab == ConfigEditorScreen.Tab.EDITOR && this.editor != null && this.editor.keyPressed(keyCode, scanCode, modifiers)) {
         this.validateJson();
         return true;
      } else if (this.currentTab == ConfigEditorScreen.Tab.WEBHOOK && this.webhookUrlField != null && this.webhookUrlField.method_25404(keyCode, scanCode, modifiers)) {
         return true;
      } else {
         return this.currentTab == ConfigEditorScreen.Tab.RECONNECT && this.loginCommandField != null && this.loginCommandField.method_25404(keyCode, scanCode, modifiers) ? true : super.method_25404(keyCode, scanCode, modifiers);
      }
   }

   public boolean method_25400(char chr, int modifiers) {
      if (this.currentTab == ConfigEditorScreen.Tab.EDITOR && this.editor != null && this.editor.charTyped(chr, modifiers)) {
         this.validateJson();
         return true;
      } else if (this.currentTab == ConfigEditorScreen.Tab.WEBHOOK && this.webhookUrlField != null && this.webhookUrlField.method_25400(chr, modifiers)) {
         return true;
      } else {
         return this.currentTab == ConfigEditorScreen.Tab.RECONNECT && this.loginCommandField != null && this.loginCommandField.method_25400(chr, modifiers) ? true : super.method_25400(chr, modifiers);
      }
   }

   private void validateJson() {
      if (this.editor != null) {
         try {
            JsonParser.parseString(this.editor.getText());
            this.jsonValid = true;
            this.validationError = "";
         } catch (Exception e) {
            this.jsonValid = false;
            this.validationError = this.extractSimpleError(e.getMessage());
         }

      }
   }

   private String extractSimpleError(String fullMessage) {
      if (fullMessage != null && !fullMessage.isEmpty()) {
         return fullMessage.length() > 44 ? fullMessage.substring(0, 41) + "..." : fullMessage;
      } else {
         return "Unknown error";
      }
   }

   private void saveAndReload() {
      this.syncFieldsToConfig();
      if (this.currentTab == ConfigEditorScreen.Tab.EDITOR && !this.jsonValid) {
         ToastManager.show("§cCannot save invalid JSON!", 16711680);
      } else {
         try {
            this.syncConfigToEditor();
            ServersConfig toSave = this.parseCurrentConfig();
            if (toSave != null) {
               CoreConfigLoader.saveFullConfigObject(toSave);
               BkRynekClient.reloadFromConfig(CoreConfigLoader.reloadConfig());
               ToastManager.show((String)"§aSettings saved and reloaded!", 65280);
               this.method_25419();
            }
         } catch (Exception e) {
            ToastManager.show("§cFailed to save: " + e.getMessage(), 16711680);
         }

      }
   }

   private void revert() {
      try {
         ServersConfig diskConfig = CoreConfigLoader.reloadConfig();
         if (diskConfig != null) {
            BkRynekClient.serversConfig = diskConfig;
            this.syncConfigToEditor();
            this.validateJson();
            ToastManager.show("§eReverted to last saved config!", 16763904);
            this.method_41843();
         }
      } catch (Exception e) {
         ToastManager.show("§cFailed to revert: " + e.getMessage(), 16711680);
      }

   }

   private void loadDefaults() {
      try {
         BkRynekClient.serversConfig = CoreConfigLoader.createDefaultConfig();
         this.syncConfigToEditor();
         this.validateJson();
         ToastManager.show("§eReset to factory defaults", 16763904);
         this.method_41843();
      } catch (Exception e) {
         ToastManager.show("§cFailed to reset: " + e.getMessage(), 16711680);
      }

   }

   public void method_25419() {
      ClientCommandRegistration.syncMemoryToConfig();
      if (this.field_22787 != null) {
         this.field_22787.method_1507(new BkRynekScreen());
      }

   }

   public boolean method_25421() {
      return false;
   }

   @Environment(EnvType.CLIENT)
   private static enum Tab {
      EDITOR,
      WEBHOOK,
      PRESETS,
      RECONNECT;

      // $FF: synthetic method
      private static Tab[] $values() {
         return new Tab[]{EDITOR, WEBHOOK, PRESETS, RECONNECT};
      }
   }
}
