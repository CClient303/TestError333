package pl.bkubiak.bkrynek.client.gui;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.function.Consumer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_437;
import net.minecraft.class_7924;
import pl.bkubiak.bkrynek.client.gui.data.EnchantEntry;
import pl.bkubiak.bkrynek.client.gui.widgets.Button;
import pl.bkubiak.bkrynek.client.gui.widgets.Panel;

@Environment(EnvType.CLIENT)
public class EnchantPickerScreen extends class_437 {
   private final class_437 parent;
   private final Consumer<EnchantEntry> onEnchantSelected;
   private class_342 searchField;
   private List<class_2960> allEnchants = new ArrayList();
   private List<class_2960> filteredEnchants = new ArrayList();
   private float scrollOffset = 0.0F;
   private float targetScrollOffset = 0.0F;
   private int selectedIndex = -1;
   private int panelX;
   private int panelY;
   private int panelW;
   private int panelH;
   private int listX;
   private int listY;
   private int listW;
   private int listH;
   private int rowHeight = 20;
   private int visibleRows;

   public EnchantPickerScreen(class_437 parent, Consumer<EnchantEntry> onEnchantSelected) {
      super(class_2561.method_30163("Select Enchantment"));
      this.parent = parent;
      this.onEnchantSelected = onEnchantSelected;
      this.loadAllEnchants();
   }

   private void loadAllEnchants() {
      this.allEnchants.clear();
      class_310 client = class_310.method_1551();
      if (client.field_1687 != null) {
         client.field_1687.method_30349().method_46759(class_7924.field_41265).ifPresent((reg) -> {
            Set var10000 = reg.method_10235();
            List var10001 = this.allEnchants;
            Objects.requireNonNull(var10001);
            var10000.forEach(var10001::add);
         });
      }

      this.allEnchants.sort(Comparator.comparing(class_2960::toString));
      this.filteredEnchants = new ArrayList(this.allEnchants);
   }

   protected void method_25426() {
      this.method_37067();
      super.method_25426();
      this.panelW = Math.min(300, this.field_22789 - 40);
      this.panelH = Math.min(350, this.field_22790 - 40);
      this.panelX = (this.field_22789 - this.panelW) / 2;
      this.panelY = (this.field_22790 - this.panelH) / 2;
      int margin = 12;
      this.listX = this.panelX + margin;
      this.listY = this.panelY + 50;
      this.listW = this.panelW - margin * 2;
      this.listH = this.panelH - 70;
      this.visibleRows = this.listH / this.rowHeight;
      this.searchField = new class_342(this.field_22793, this.listX, this.panelY + 25, this.listW, 16, class_2561.method_30163(""));
      this.searchField.method_47404(class_2561.method_30163("§8Search..."));
      this.searchField.method_1863(this::onSearchChanged);
      this.method_37063(this.searchField);
      this.method_37063(new Button(this.panelX + this.panelW - 18, this.panelY + 4, 14, 14, "X", (btn) -> this.method_25419(), -48060, false));
      this.method_48265(this.searchField);
   }

   private void onSearchChanged(String query) {
      String search = query.toLowerCase().trim();
      this.filteredEnchants.clear();
      if (search.isEmpty()) {
         this.filteredEnchants.addAll(this.allEnchants);
      } else {
         for(class_2960 id : this.allEnchants) {
            if (id.toString().contains(search) || id.method_12832().contains(search)) {
               this.filteredEnchants.add(id);
            }
         }
      }

      this.scrollOffset = 0.0F;
      this.targetScrollOffset = 0.0F;
      this.selectedIndex = this.filteredEnchants.isEmpty() ? -1 : 0;
   }

   public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
      context.method_25294(0, 0, this.field_22789, this.field_22790, -1442840576);
      float scrollDiff = this.targetScrollOffset - this.scrollOffset;
      if (Math.abs(scrollDiff) > 0.1F) {
         this.scrollOffset += scrollDiff * 0.25F;
      } else {
         this.scrollOffset = this.targetScrollOffset;
      }

      Panel.drawPanel(context, this.panelX, this.panelY, this.panelW, this.panelH, 6);
      Panel.drawHeader(context, this.panelX, this.panelY, this.panelW, 20);
      context.method_51433(this.field_22793, "Select Enchantment", this.panelX + 10, this.panelY + 6, -5592406, false);
      context.method_44379(this.listX, this.listY, this.listX + this.listW, this.listY + this.listH);
      int total = this.filteredEnchants.size();

      for(int i = 0; i < total; ++i) {
         int rowY = this.listY + i * this.rowHeight - (int)this.scrollOffset;
         if (rowY + this.rowHeight >= this.listY && rowY <= this.listY + this.listH) {
            boolean isHovered = mouseX >= this.listX && mouseX <= this.listX + this.listW && mouseY >= rowY && mouseY < rowY + this.rowHeight;
            boolean isSelected = i == this.selectedIndex;
            if (isSelected || isHovered) {
               context.method_25294(this.listX, rowY, this.listX + this.listW, rowY + this.rowHeight, isSelected ? 1613989973 : 1090519039);
            }

            class_2960 id = (class_2960)this.filteredEnchants.get(i);
            String name = id.method_12832().replace('_', ' ');
            String var10000 = name.substring(0, 1).toUpperCase();
            name = var10000 + name.substring(1);
            context.method_51433(this.field_22793, name, this.listX + 4, rowY + 5, -1, false);
         }
      }

      context.method_44380();
      super.method_25394(context, mouseX, mouseY, delta);
   }

   public boolean method_25402(double mouseX, double mouseY, int button) {
      if (button == 0 && mouseX >= (double)this.listX && mouseX <= (double)(this.listX + this.listW) && mouseY >= (double)this.listY && mouseY <= (double)(this.listY + this.listH)) {
         int idx = (int)((mouseY - (double)this.listY + (double)this.scrollOffset) / (double)this.rowHeight);
         if (idx >= 0 && idx < this.filteredEnchants.size()) {
            this.selectEnchant(idx);
            return true;
         }
      }

      return super.method_25402(mouseX, mouseY, button);
   }

   public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
      int maxScroll = Math.max(0, this.filteredEnchants.size() * this.rowHeight - this.listH);
      this.targetScrollOffset = (float)((double)this.targetScrollOffset - verticalAmount * (double)15.0F);
      this.targetScrollOffset = Math.max(0.0F, Math.min(this.targetScrollOffset, (float)maxScroll));
      return true;
   }

   private void selectEnchant(int index) {
      class_2960 id = (class_2960)this.filteredEnchants.get(index);
      String name = id.method_12832().replace('_', ' ');
      String var10000 = name.substring(0, 1).toUpperCase();
      name = var10000 + name.substring(1);
      this.onEnchantSelected.accept(new EnchantEntry(id.toString(), name, 1));
      this.method_25419();
   }

   public void method_25419() {
      class_310.method_1551().method_1507(this.parent);
   }
}
