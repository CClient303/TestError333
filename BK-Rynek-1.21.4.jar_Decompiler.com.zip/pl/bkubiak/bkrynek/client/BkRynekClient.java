package pl.bkubiak.bkrynek.client;

import java.util.Map;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_339;
import net.minecraft.class_4185;
import net.minecraft.class_419;
import net.minecraft.class_642;
import pl.bkubiak.bkrynek.client.command.ClientCommandRegistration;
import pl.bkubiak.bkrynek.client.config.ConfigLoader;
import pl.bkubiak.bkrynek.client.gui.SearchHudOverlay;
import pl.bkubiak.bkrynek.client.keybinding.ToggleAutomation;
import pl.bkubiak.bkrynek.client.keybinding.ToggleScanner;
import pl.bkubiak.bkrynek.client.util.AfkController;
import pl.bkubiak.bkrynek.client.util.ColorUtils;
import pl.bkubiak.bkrynek.client.util.LobbyAutomationController;
import pl.bkubiak.bkrynek.client.util.ReconnectController;
import pl.bkubiak.bkrynek.client.util.SearchAutomationController;
import pl.bkubiak.bkrynek.client.util.SetupManager;
import pl.bkubiak.bkrynek.client.util.ToastManager;
import pl.bkubiak.bkrynek.core.config.ServerEntry;
import pl.bkubiak.bkrynek.core.config.ServersConfig;
import pl.bkubiak.bkrynek.core.manager.ClientPriceListManager;
import pl.bkubiak.bkrynek.core.util.Messages;

@Environment(EnvType.CLIENT)
public class BkRynekClient implements ClientModInitializer {
   public static ServersConfig serversConfig;
   public static boolean isSumMode = true;
   public static boolean isSniperMode = true;
   private static boolean welcomeShown = false;

   public void onInitializeClient() {
      System.out.println("[BK-Rynek] Initializing Client Mod...");
      ToggleScanner.init();
      ToggleAutomation.init();
      ClientTickEvents.END_CLIENT_TICK.register((ClientTickEvents.EndTick)(client) -> {
         AfkController.onTick(client);
         SearchAutomationController.onTick();
         ReconnectController.globalTick();
         if (client.field_1755 instanceof class_419 && ReconnectController.isPending() && !ReconnectController.isCancelled()) {
            int seconds = ReconnectController.getSecondsUntilReconnect();

            for(class_339 btn : Screens.getButtons(client.field_1755)) {
               if (btn.method_25369() != null && btn.method_25369().getString().contains("STOP Auto-Reconnect")) {
                  btn.method_25355(class_2561.method_43470("STOP Auto-Reconnect (" + seconds + "s)"));
               }
            }
         }

      });
      ClientTickEvents.START_CLIENT_TICK.register((ClientTickEvents.StartTick)(client) -> LobbyAutomationController.onTick());
      serversConfig = ConfigLoader.loadConfig();
      Messages.load(serversConfig.language);
      ClientPriceListManager.fullReloadMemory(serversConfig);
      updateProfileFromConnection();
      ClientPlayConnectionEvents.JOIN.register((ClientPlayConnectionEvents.Join)(handler, sender, client) -> client.execute(() -> {
            if (!welcomeShown && client.field_1724 != null) {
               String prefix = "&8[&2B&aK &fRynek&8] ";
               client.field_1724.method_7353(ColorUtils.translateColorCodes(prefix + "&fBK-Rynek started &asuccessfully!"), false);
               client.field_1724.method_7353(ColorUtils.translateColorCodes("&8» &7Discord: &adc.bkubiak.dev"), false);
               client.field_1724.method_7353(ColorUtils.translateColorCodes("&8» &7Commands: &a/bkr help"), false);
               client.field_1724.method_7353(ColorUtils.translateColorCodes("&8» &7GUI: &a/bkr gui"), false);
               ToastManager.show("BK-Rynek Loaded!", 5635925);
               welcomeShown = true;
            }

            class_642 info = client.method_1558();
            if (info != null) {
               ReconnectController.setLastServer(info);
            }

            updateProfileFromConnection();
            String address = getServerAddress();
            ServerEntry entry = findServerEntry(address);
            if (entry != null) {
               if (Boolean.FALSE.equals(entry.usePremiumAccount) && entry.loginCommand != null && !entry.loginCommand.isEmpty()) {
                  if (client.field_1724 != null) {
                     (new Thread(() -> {
                        try {
                           Thread.sleep(5000L);
                           client.execute(() -> {
                              if (client.field_1724 != null) {
                                 client.field_1724.field_3944.method_45730(entry.loginCommand.replace("/", ""));
                                 if (ReconnectController.isReconnecting()) {
                                    LobbyAutomationController.isAutoReconnectedContext = true;
                                    LobbyAutomationController.startLobbyFlow();
                                    ReconnectController.setReconnecting(false);
                                 } else {
                                    LobbyAutomationController.isAutoReconnectedContext = false;
                                 }
                              }

                           });
                        } catch (InterruptedException var3) {
                        }

                     })).start();
                  }
               } else if (ReconnectController.isReconnecting()) {
                  LobbyAutomationController.isAutoReconnectedContext = true;
                  LobbyAutomationController.startLobbyFlow();
                  ReconnectController.setReconnecting(false);
               } else {
                  LobbyAutomationController.isAutoReconnectedContext = false;
               }
            }

         }));
      ClientCommandRegistration.registerCommands();
      ClientReceiveMessageEvents.GAME.register((ClientReceiveMessageEvents.Game)(message, overlay) -> {
         LobbyAutomationController.onChatMessage(message, overlay);
         SearchAutomationController.onChatMessage(message, overlay);
      });
      HudRenderCallback.EVENT.register((HudRenderCallback)(drawContext, tickDelta) -> {
         if (SetupManager.isActive()) {
            String setupText = SetupManager.getSetupInstruction();
            class_2561 renderedSetup = ColorUtils.translateColorCodes(setupText);
            int width = class_310.method_1551().method_22683().method_4486();
            int height = class_310.method_1551().method_22683().method_4502();
            int textWidth = class_310.method_1551().field_1772.method_27525(renderedSetup);
            drawContext.method_27535(class_310.method_1551().field_1772, renderedSetup, width / 2 - textWidth / 2, height - 70, 16777215);
         }

         ToastManager.render(drawContext);
         SearchHudOverlay.render(drawContext);
      });
      ScreenEvents.AFTER_INIT.register((ScreenEvents.AfterInit)(client, screen, scaledWidth, scaledHeight) -> {
         if (screen instanceof class_419) {
            ReconnectController.onDisconnectScreenInit(screen);
            if (ReconnectController.isPending() && !ReconnectController.isCancelled()) {
               boolean buttonExists = Screens.getButtons(screen).stream().anyMatch((b) -> b.method_25369() != null && b.method_25369().getString().contains("STOP Auto-Reconnect"));
               if (!buttonExists) {
                  Screens.getButtons(screen).add(class_4185.method_46430(class_2561.method_43470("STOP Auto-Reconnect"), (button) -> {
                     ReconnectController.cancel();
                     button.method_25355(class_2561.method_43470("Anulowano"));
                     button.field_22763 = false;
                  }).method_46434(scaledWidth / 2 - 100, scaledHeight - 30, 200, 20).method_46431());
               }
            }
         }

      });
   }

   public static void reloadFromConfig(ServersConfig newConfig) {
      SearchAutomationController.cancel();
      serversConfig = newConfig;
      ClientPriceListManager.fullReloadMemory(newConfig);
      Messages.load(newConfig.language);
      updateProfileFromConnection();
   }

   public static void updateProfileFromConnection() {
      if (serversConfig != null) {
         String address = getServerAddress();
         ServerEntry entry = findServerEntry(address);
         if (entry != null) {
            ClientPriceListManager.setActiveProfile(entry.profileName);
            class_310 client = class_310.method_1551();
            if (client.field_1724 != null) {
               String msg = Messages.format("command.profile.change", Map.of("profile", entry.profileName));
               client.field_1724.method_7353(ColorUtils.translateColorCodes(msg), false);
            }
         } else {
            ClientPriceListManager.setActiveProfile(serversConfig.defaultProfile);
            class_310 client = class_310.method_1551();
            if (client.field_1724 != null) {
               String msg = Messages.format("command.profile.change", Map.of("profile", serversConfig.defaultProfile));
               client.field_1724.method_7353(ColorUtils.translateColorCodes(msg), false);
            }
         }

      }
   }

   public static String getServerAddress() {
      return class_310.method_1551().method_1558() != null ? class_310.method_1551().method_1558().field_3761 : "singleplayer";
   }

   public static ServerEntry findServerEntryByProfile(String profileName) {
      if (serversConfig != null && serversConfig.servers != null) {
         for(ServerEntry entry : serversConfig.servers) {
            if (profileName.equals(entry.profileName)) {
               return entry;
            }
         }

         return null;
      } else {
         return null;
      }
   }

   public static ServerEntry findServerEntry(String address) {
      for(ServerEntry entry : serversConfig.servers) {
         for(String domain : entry.domains) {
            if (address.equalsIgnoreCase(domain) || address.toLowerCase().endsWith("." + domain.toLowerCase())) {
               return entry;
            }
         }
      }

      return null;
   }
}
