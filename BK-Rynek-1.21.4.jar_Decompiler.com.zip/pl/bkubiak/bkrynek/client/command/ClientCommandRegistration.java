package pl.bkubiak.bkrynek.client.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import java.util.List;
import java.util.Map;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_5250;
import net.minecraft.class_7157;
import pl.bkubiak.bkrynek.client.BkRynekClient;
import pl.bkubiak.bkrynek.client.config.ConfigLoader;
import pl.bkubiak.bkrynek.client.gui.BkRynekScreen;
import pl.bkubiak.bkrynek.client.keybinding.ToggleScanner;
import pl.bkubiak.bkrynek.client.util.AfkController;
import pl.bkubiak.bkrynek.client.util.SetupManager;
import pl.bkubiak.bkrynek.client.util.ToastManager;
import pl.bkubiak.bkrynek.core.config.CoreConfigLoader;
import pl.bkubiak.bkrynek.core.config.PriceEntry;
import pl.bkubiak.bkrynek.core.config.ServerEntry;
import pl.bkubiak.bkrynek.core.manager.ClientPriceListManager;
import pl.bkubiak.bkrynek.core.util.CompositeKeyUtil;
import pl.bkubiak.bkrynek.core.util.Messages;
import pl.bkubiak.bkrynek.core.util.PriceFormatter;

@Environment(EnvType.CLIENT)
public class ClientCommandRegistration {
   public static void registerCommands() {
      ClientCommandRegistrationCallback.EVENT.register(ClientCommandRegistration::registerBkrCommand);
   }

   private static void registerBkrCommand(CommandDispatcher<FabricClientCommandSource> dispatcher, class_7157 registryAccess) {
      dispatcher.register((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)ClientCommandManager.literal("bkr").executes((ctx) -> {
         String activeProfile = ClientPriceListManager.getActiveProfile();
         String message = Messages.format("mod.info", Map.of("profile", activeProfile));
         ((FabricClientCommandSource)ctx.getSource()).sendFeedback(CommandUi.colored(message));
         return 1;
      })).then(ClientCommandManager.literal("scan").executes((ctx) -> {
         ToggleScanner.scanningEnabled = !ToggleScanner.scanningEnabled;
         String msgKey = ToggleScanner.scanningEnabled ? "command.scanner.toggle.on" : "command.scanner.toggle.off";
         ((FabricClientCommandSource)ctx.getSource()).sendFeedback(CommandUi.colored(Messages.get(msgKey)));
         return 1;
      }))).then(ClientCommandManager.literal("gui").executes((ctx) -> {
         class_310.method_1551().execute(() -> {
            try {
               (new Thread(() -> {
                  try {
                     Thread.sleep(100L);
                     class_310.method_1551().execute(() -> class_310.method_1551().method_1507(new BkRynekScreen()));
                  } catch (Exception e) {
                     e.printStackTrace();
                  }

               })).start();
            } catch (Exception e) {
               System.err.println("[BK-Rynek] Failed to initiate GUI open: " + e.getMessage());
               e.printStackTrace();
            }

         });
         return 1;
      }))).then(ClientCommandManager.literal("profiles").executes((ctx) -> {
         String allProfiles = ClientPriceListManager.listProfiles();
         String[] profiles = allProfiles.split(",\\s*");
         class_5250 finalText = CommandUi.colored(Messages.get("command.profiles.header"));
         finalText.method_10852(class_2561.method_43470("\n"));
         String activeProfile = ClientPriceListManager.getActiveProfile();

         for(String profile : profiles) {
            String trimmedProfile = profile.trim();
            if (trimmedProfile.equals(activeProfile)) {
               String lineTemplate = Messages.format("profile.picked.line", Map.of("profile", trimmedProfile));
               finalText.method_10852(CommandUi.colored(lineTemplate));
            } else {
               String lineTemplate = Messages.format("profile.available.line", Map.of("profile", trimmedProfile));
               class_5250 lineText = CommandUi.clickable(lineTemplate, "/bkr profile " + trimmedProfile, Messages.format("command.profile.change.tooltip", Map.of("profile", trimmedProfile)));
               finalText.method_10852(lineText);
            }

            finalText.method_10852(class_2561.method_43470("\n"));
         }

         ((FabricClientCommandSource)ctx.getSource()).sendFeedback(finalText);
         return 1;
      }))).then(ClientCommandManager.literal("profile").then(ClientCommandManager.argument("profile", StringArgumentType.word()).executes((ctx) -> {
         String profile = StringArgumentType.getString(ctx, "profile");
         ClientPriceListManager.setActiveProfile(profile);
         String msg = Messages.format("command.profile.change", Map.of("profile", profile));
         ((FabricClientCommandSource)ctx.getSource()).sendFeedback(CommandUi.colored(msg));
         return 1;
      })))).then(ClientCommandManager.literal("list").executes((ctx) -> {
         String activeProfile = ClientPriceListManager.getActiveProfile();
         List<PriceEntry> entries = (List)ClientPriceListManager.getAllProfiles().get(activeProfile);
         class_5250 finalText = class_2561.method_43473();
         if (entries != null) {
            for(PriceEntry pe : entries) {
               String compositeKey = CompositeKeyUtil.getCompositeKeyFromEntry(pe);
               String friendlyName = CompositeKeyUtil.getFriendlyName(compositeKey);
               String priceStr = PriceFormatter.formatPrice(pe.maxPrice);
               String itemLineStr = Messages.format("pricelist.item_line", Map.of("item", friendlyName, "price", priceStr));
               class_5250 lineText = CommandUi.colored(itemLineStr).method_10852(class_2561.method_43470("\n"));
               finalText.method_10852(lineText);
            }
         }

         String msgHeader = Messages.format("command.list", Map.of("profile", activeProfile, "list", ""));
         ((FabricClientCommandSource)ctx.getSource()).sendFeedback(CommandUi.colored(msgHeader));
         ((FabricClientCommandSource)ctx.getSource()).sendFeedback(finalText);
         return 1;
      }))).then(ClientCommandManager.literal("pomoc").executes((ctx) -> {
         ((FabricClientCommandSource)ctx.getSource()).sendFeedback(CommandUi.colored(Messages.get("command.help")));
         return 1;
      }))).then(((LiteralArgumentBuilder)((LiteralArgumentBuilder)ClientCommandManager.literal("setup").executes((ctx) -> {
         SetupManager.startSetup();
         return 1;
      })).then(ClientCommandManager.literal("info").executes((ctx) -> {
         SetupManager.showInfo();
         return 1;
      }))).then(ClientCommandManager.literal("cancel").executes((ctx) -> {
         SetupManager.stopSetup();
         return 1;
      })))).then(ClientCommandManager.literal("webhook").then(ClientCommandManager.argument("url", StringArgumentType.greedyString()).executes((ctx) -> {
         String url = StringArgumentType.getString(ctx, "url");
         BkRynekClient.serversConfig.discordWebhookUrl = url;
         ConfigLoader.saveAllConfigs(BkRynekClient.serversConfig);
         ((FabricClientCommandSource)ctx.getSource()).sendFeedback(CommandUi.colored(Messages.get("command.webhook.success")));
         return 1;
      })))).then(ClientCommandManager.literal("config").then(ClientCommandManager.literal("reload").executes((ctx) -> {
         BkRynekClient.reloadFromConfig(CoreConfigLoader.reloadConfig());
         ((FabricClientCommandSource)ctx.getSource()).sendFeedback(CommandUi.colored(Messages.get("command.config.reload.success")));
         return 1;
      })))).then(((LiteralArgumentBuilder)((LiteralArgumentBuilder)ClientCommandManager.literal("sounds").executes((ctx) -> {
         boolean current = BkRynekClient.serversConfig.soundsEnabled;
         String msg = current ? Messages.get("command.sounds.current_on") : Messages.get("command.sounds.current_off");
         ((FabricClientCommandSource)ctx.getSource()).sendFeedback(CommandUi.colored(msg));
         return 1;
      })).then(ClientCommandManager.literal("on").executes((ctx) -> {
         BkRynekClient.serversConfig.soundsEnabled = true;
         ((FabricClientCommandSource)ctx.getSource()).sendFeedback(CommandUi.colored(Messages.get("command.sounds.enabled")));
         ConfigLoader.saveAllConfigs(BkRynekClient.serversConfig);
         return 1;
      }))).then(ClientCommandManager.literal("off").executes((ctx) -> {
         BkRynekClient.serversConfig.soundsEnabled = false;
         ((FabricClientCommandSource)ctx.getSource()).sendFeedback(CommandUi.colored(Messages.get("command.sounds.disabled")));
         ConfigLoader.saveAllConfigs(BkRynekClient.serversConfig);
         return 1;
      })))).then(((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)ClientCommandManager.literal("autorepair").executes((ctx) -> {
         ServerEntry se = findEntry();
         if (se != null) {
            boolean current = se.autoRepair != null && se.autoRepair;
            String status = current ? "§aON" : "§cOFF";
            ((FabricClientCommandSource)ctx.getSource()).sendFeedback(CommandUi.colored(Messages.get("command.autorepair.status", "status", status)));
         }

         return 1;
      })).then(ClientCommandManager.literal("on").executes((ctx) -> {
         ServerEntry se = findEntry();
         if (se != null) {
            se.autoRepair = true;
            ((FabricClientCommandSource)ctx.getSource()).sendFeedback(CommandUi.colored(Messages.get("command.autorepair.on")));
            ConfigLoader.saveAllConfigs(BkRynekClient.serversConfig);
         }

         return 1;
      }))).then(ClientCommandManager.literal("off").executes((ctx) -> {
         ServerEntry se = findEntry();
         if (se != null) {
            se.autoRepair = false;
            ((FabricClientCommandSource)ctx.getSource()).sendFeedback(CommandUi.colored(Messages.get("command.autorepair.off")));
            ConfigLoader.saveAllConfigs(BkRynekClient.serversConfig);
         }

         return 1;
      }))).then(ClientCommandManager.literal("cmd").then(ClientCommandManager.argument("command", StringArgumentType.greedyString()).executes((ctx) -> {
         ServerEntry se = findEntry();
         if (se != null) {
            String cmd = StringArgumentType.getString(ctx, "command");
            se.repairCommand = cmd;
            ((FabricClientCommandSource)ctx.getSource()).sendFeedback(CommandUi.colored(Messages.get("command.autorepair.cmd", "command", cmd)));
            ConfigLoader.saveAllConfigs(BkRynekClient.serversConfig);
         }

         return 1;
      }))))).then(((LiteralArgumentBuilder)((LiteralArgumentBuilder)ClientCommandManager.literal("afk").executes((ctx) -> {
         boolean enabled = !AfkController.isEnabled();
         if (enabled) {
            AfkController.enable();
            ((FabricClientCommandSource)ctx.getSource()).sendFeedback(CommandUi.colored(Messages.get("command.afk.enabled")));
         } else {
            AfkController.disable();
            ((FabricClientCommandSource)ctx.getSource()).sendFeedback(CommandUi.colored(Messages.get("command.afk.disabled")));
         }

         return 1;
      })).then(ClientCommandManager.literal("on").executes((ctx) -> {
         AfkController.enable();
         ((FabricClientCommandSource)ctx.getSource()).sendFeedback(CommandUi.colored(Messages.get("command.afk.enabled")));
         return 1;
      }))).then(ClientCommandManager.literal("off").executes((ctx) -> {
         AfkController.disable();
         ((FabricClientCommandSource)ctx.getSource()).sendFeedback(CommandUi.colored(Messages.get("command.afk.disabled")));
         return 1;
      })))).then(ClientCommandManager.literal("ignorecomponents").executes((ctx) -> {
         boolean newVal = !BkRynekClient.serversConfig.ignoreComponents;
         BkRynekClient.serversConfig.ignoreComponents = newVal;
         ToastManager.show("Ignorowanie komponentów: " + (newVal ? "§aON" : "§cOFF"), 5635925);
         ((FabricClientCommandSource)ctx.getSource()).sendFeedback(CommandUi.colored(Messages.get(newVal ? "command.ignorecomponents.on" : "command.ignorecomponents.off")));
         ConfigLoader.saveAllConfigs(BkRynekClient.serversConfig);
         return 1;
      }))).then(ClientCommandManager.literal("lang").then(ClientCommandManager.argument("language", StringArgumentType.word()).executes((ctx) -> {
         String lang = StringArgumentType.getString(ctx, "language");
         if (lang.equalsIgnoreCase("pl") || lang.equalsIgnoreCase("en")) {
            BkRynekClient.serversConfig.language = lang.toLowerCase();
            Messages.load(lang.toLowerCase());
            ConfigLoader.saveAllConfigs(BkRynekClient.serversConfig);
            String msg = Messages.format("command.lang.success", Map.of("lang", lang.toUpperCase()));
            ((FabricClientCommandSource)ctx.getSource()).sendFeedback(CommandUi.colored(msg));
         }

         return 1;
      })))).then(((LiteralArgumentBuilder)ClientCommandManager.literal("preset").then(ClientCommandManager.literal("save").then(ClientCommandManager.argument("name", StringArgumentType.word()).executes((ctx) -> {
         String name = StringArgumentType.getString(ctx, "name");
         if (ClientPriceListManager.savePreset(name, BkRynekClient.serversConfig)) {
            String msg = Messages.format("command.preset.save.success", Map.of("preset", name, "profile", ClientPriceListManager.getActiveProfile()));
            ((FabricClientCommandSource)ctx.getSource()).sendFeedback(CommandUi.colored(msg));
         } else {
            ((FabricClientCommandSource)ctx.getSource()).sendFeedback(CommandUi.colored(Messages.get("command.preset.save.empty")));
         }

         return 1;
      })))).then(ClientCommandManager.literal("load").then(ClientCommandManager.argument("name", StringArgumentType.word()).executes((ctx) -> {
         String name = StringArgumentType.getString(ctx, "name");
         if (CoreConfigLoader.loadFullConfig(name) != null) {
            CoreConfigLoader.setActiveConfigName(name);
            BkRynekClient.reloadFromConfig(CoreConfigLoader.reloadConfig());
            String msg = Messages.format("command.preset.load.success", Map.of("preset", name, "profile", ClientPriceListManager.getActiveProfile()));
            ((FabricClientCommandSource)ctx.getSource()).sendFeedback(CommandUi.colored(msg));
         } else {
            String msg = Messages.format("command.preset.load.notfound", Map.of("preset", name));
            ((FabricClientCommandSource)ctx.getSource()).sendFeedback(CommandUi.colored(msg));
         }

         return 1;
      })))));
   }

   public static void syncMemoryToConfig() {
      ClientPriceListManager.syncMemoryToConfig(BkRynekClient.serversConfig);
   }

   public static void reinitProfilesFromConfig() {
      if (BkRynekClient.serversConfig != null) {
         if (BkRynekClient.serversConfig.servers != null) {
            for(ServerEntry se : BkRynekClient.serversConfig.servers) {
               if (se.profileName != null && se.prices != null) {
                  ClientPriceListManager.addProfile(se.profileName, se.prices);
               }
            }

         }
      }
   }

   private static ServerEntry findEntry() {
      return BkRynekClient.findServerEntry(BkRynekClient.getServerAddress());
   }
}
