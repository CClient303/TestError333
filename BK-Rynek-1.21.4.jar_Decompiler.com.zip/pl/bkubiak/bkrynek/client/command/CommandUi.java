package pl.bkubiak.bkrynek.client.command;

import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import java.util.concurrent.CompletableFuture;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_2583;
import net.minecraft.class_2960;
import net.minecraft.class_5250;
import net.minecraft.class_7923;
import net.minecraft.class_2558.class_2559;
import net.minecraft.class_2568.class_5247;
import pl.bkubiak.bkrynek.client.util.ColorUtils;

@Environment(EnvType.CLIENT)
public final class CommandUi {
   private CommandUi() {
   }

   public static class_5250 colored(String text) {
      class_5250 out = class_2561.method_43473();
      out.method_10852(ColorUtils.translateColorCodes(text));
      return out;
   }

   public static class_5250 clickable(String text, String command, String hoverText) {
      return clickable(text, class_2559.field_11750, command, hoverText);
   }

   public static class_5250 clickable(String text, class_2558.class_2559 action, String command, String hoverText) {
      class_5250 out = colored(text);
      class_2583 style = class_2583.field_24360.method_10958(new class_2558(action, command));
      if (hoverText != null && !hoverText.isEmpty()) {
         style = style.method_10949(new class_2568(class_5247.field_24342, class_2561.method_43470(hoverText)));
      }

      out.method_10862(style);
      return out;
   }

   public static CompletableFuture<Suggestions> suggestItemIds(SuggestionsBuilder builder) {
      String remaining = builder.getRemaining().toLowerCase();
      if (remaining.startsWith("mc:")) {
         remaining = "minecraft:" + remaining.substring(3);
      }

      if (remaining.contains("minecraft:")) {
         for(class_2960 itemId : class_7923.field_41178.method_10235()) {
            String asString = itemId.toString();
            if (asString.contains(remaining)) {
               builder.suggest(asString);
            }
         }
      }

      return builder.buildFuture();
   }
}
