package pl.bkubiak.bkrynek.client.config;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.loader.api.FabricLoader;
import pl.bkubiak.bkrynek.core.config.CoreConfigLoader;
import pl.bkubiak.bkrynek.core.config.ServersConfig;

@Environment(EnvType.CLIENT)
public class ConfigLoader {
   private static final Path MOD_CONFIG_DIR;

   public static ServersConfig loadConfig() {
      return CoreConfigLoader.loadConfig(MOD_CONFIG_DIR);
   }

   public static void saveAllConfigs(ServersConfig config) {
      CoreConfigLoader.saveAllConfigs(config, MOD_CONFIG_DIR);
   }

   static {
      Path configDir = FabricLoader.getInstance().getConfigDir();
      MOD_CONFIG_DIR = configDir.resolve("BK-Mods").resolve("BK-Rynek");

      try {
         if (!Files.exists(MOD_CONFIG_DIR, new LinkOption[0])) {
            Files.createDirectories(MOD_CONFIG_DIR);
         }
      } catch (IOException e) {
         e.printStackTrace();
      }

   }
}
