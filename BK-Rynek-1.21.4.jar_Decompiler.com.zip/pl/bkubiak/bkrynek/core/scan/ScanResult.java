package pl.bkubiak.bkrynek.core.scan;

import pl.bkubiak.bkrynek.core.config.PriceEntry;

public class ScanResult {
   public final boolean highlight;
   public final int color;
   public final double foundPrice;
   public final double maxPrice;
   public final PriceEntry matchedEntry;

   public ScanResult(boolean highlight, int color, double foundPrice, double maxPrice, PriceEntry matchedEntry) {
      this.highlight = highlight;
      this.color = color;
      this.foundPrice = foundPrice;
      this.maxPrice = maxPrice;
      this.matchedEntry = matchedEntry;
   }

   public static ScanResult noHighlight() {
      return new ScanResult(false, 0, (double)-1.0F, (double)-1.0F, (PriceEntry)null);
   }
}
