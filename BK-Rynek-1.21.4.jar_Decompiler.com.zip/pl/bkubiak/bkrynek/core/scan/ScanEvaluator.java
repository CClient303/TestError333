package pl.bkubiak.bkrynek.core.scan;

import java.util.Calendar;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import pl.bkubiak.bkrynek.core.config.PriceEntry;
import pl.bkubiak.bkrynek.core.config.ServerEntry;
import pl.bkubiak.bkrynek.core.config.ServersConfig;
import pl.bkubiak.bkrynek.core.manager.ClientPriceListManager;

public final class ScanEvaluator {
   private static final Map<String, Pattern> patternCache = new ConcurrentHashMap();

   private static Pattern getPattern(String regex) {
      return (Pattern)patternCache.computeIfAbsent(regex, (r) -> Pattern.compile(r, 2));
   }

   private ScanEvaluator() {
   }

   public static ScanResult evaluate(ScanInput input, ServersConfig config, boolean isSumMode) {
      if (input != null && config != null && config.servers != null) {
         String activeProfile = ClientPriceListManager.getActiveProfile();
         ServerEntry entry = findServerEntryByProfile(config, activeProfile);
         if (entry == null) {
            return ScanResult.noHighlight();
         } else {
            String loreRegex = entry.loreRegex;
            String colorStr = entry.highlightColor;
            String colorStackStr = entry.highlightColorStack != null && !entry.highlightColorStack.isEmpty() ? entry.highlightColorStack : colorStr;
            int highlightColor = parseColor(colorStr);
            int highlightColorStack = parseColor(colorStackStr);
            double foundPrice = (double)-1.0F;
            Pattern pattern = getPattern(loreRegex);

            for(String plain : input.loreLines) {
               Matcher m = pattern.matcher(plain);
               if (m.find()) {
                  String priceGroup = m.group(1);
                  double parsedPrice = parsePriceWithSuffix(priceGroup);
                  if (parsedPrice >= (double)0.0F) {
                     foundPrice = parsedPrice;
                     break;
                  }
               }
            }

            if (foundPrice < (double)0.0F) {
               return ScanResult.noHighlight();
            } else {
               if (entry.loreSellerRegex != null && !entry.loreSellerRegex.isEmpty()) {
                  boolean sellerFound = false;
                  Pattern sellerPattern = getPattern(entry.loreSellerRegex);

                  for(String plain : input.loreLines) {
                     if (sellerPattern.matcher(plain).find()) {
                        sellerFound = true;
                        break;
                     }
                  }

                  if (!sellerFound) {
                     return ScanResult.noHighlight();
                  }
               }

               int stackSize = input.stackSize;
               boolean isStack = stackSize > 1;
               double unitPrice = isStack ? foundPrice / (double)stackSize : foundPrice;
               Integer daysLeft = null;

               for(String plain : input.loreLines) {
                  String lowerPlain = plain.toLowerCase();
                  if (lowerPlain.contains("wygaśnie:") || lowerPlain.contains("wygasnie:")) {
                     try {
                        String dateStr = plain.substring(plain.indexOf(":") + 1).trim();
                        if (dateStr.contains(",")) {
                           dateStr = dateStr.substring(0, dateStr.indexOf(",")).trim();
                        }

                        String[] parts = dateStr.split("-");
                        if (parts.length == 3) {
                           int day = Integer.parseInt(parts[0]);
                           int month = Integer.parseInt(parts[1]);
                           int year = Integer.parseInt(parts[2]);
                           Calendar cal = Calendar.getInstance();
                           long now = cal.getTimeInMillis();
                           cal.set(year, month - 1, day, 23, 59, 59);
                           long expiry = cal.getTimeInMillis();
                           daysLeft = (int)((expiry - now) / 86400000L);
                        }
                     } catch (Exception var31) {
                     }
                     break;
                  }
               }

               PriceEntry matchedEntry = ClientPriceListManager.findMatchingPriceEntry(input.noColorName, input.loreLines, input.materialId, input.enchantments, input.componentCount, input.customModelData, daysLeft);
               if (matchedEntry == null) {
                  return ScanResult.noHighlight();
               } else {
                  double maxPrice = matchedEntry.maxPrice;
                  double comparisonPrice = isSumMode ? foundPrice : unitPrice;
                  double epsilon = 1.0E-4;
                  if (comparisonPrice <= maxPrice + epsilon) {
                     if (isSumMode && matchedEntry.requiredCount > 0 && input.stackSize != matchedEntry.requiredCount) {
                        return ScanResult.noHighlight();
                     } else {
                        boolean isBargain = comparisonPrice < maxPrice - epsilon;
                        int finalColor;
                        if (isBargain) {
                           finalColor = -16777216 | highlightColor & 16777215;
                        } else {
                           finalColor = -16777216 | highlightColorStack & 16777215;
                        }

                        return new ScanResult(true, finalColor, foundPrice, maxPrice, matchedEntry);
                     }
                  } else {
                     return ScanResult.noHighlight();
                  }
               }
            }
         }
      } else {
         return ScanResult.noHighlight();
      }
   }

   private static ServerEntry findServerEntryByProfile(ServersConfig config, String profileName) {
      if (config != null && config.servers != null) {
         for(ServerEntry se : config.servers) {
            if (se.profileName.equals(profileName)) {
               return se;
            }
         }

         return null;
      } else {
         return null;
      }
   }

   private static int parseColor(String colorStr) {
      if (colorStr != null && !colorStr.isEmpty()) {
         if (colorStr.startsWith("#")) {
            colorStr = colorStr.substring(1);
         }

         if (colorStr.length() == 6) {
            colorStr = "FF" + colorStr;
         }

         try {
            long argb = Long.parseLong(colorStr, 16);
            return (int)(argb & -1L);
         } catch (Exception var3) {
            return -1;
         }
      } else {
         return -1;
      }
   }

   private static double parsePriceWithSuffix(String raw) {
      raw = raw.trim().replaceAll("[\\s\\u00A0\\u202F]+", "");
      if (raw.contains("(")) {
         raw = raw.substring(0, raw.indexOf("("));
      }

      String lower = raw.toLowerCase();
      double multiplier = (double)1.0F;
      if (!lower.endsWith("mld") && !lower.endsWith("b")) {
         if (lower.endsWith("t")) {
            multiplier = 1.0E12;
            raw = raw.substring(0, raw.length() - 1);
         } else if (lower.endsWith("m")) {
            multiplier = (double)1000000.0F;
            raw = raw.substring(0, raw.length() - 1);
         } else if (lower.endsWith("k")) {
            multiplier = (double)1000.0F;
            raw = raw.substring(0, raw.length() - 1);
         }
      } else {
         multiplier = (double)1.0E9F;
         raw = raw.substring(0, raw.length() - (lower.endsWith("mld") ? 3 : 1));
      }

      String digits = raw.replaceAll("[^0-9.,]", "");
      if (digits.isEmpty()) {
         return (double)-1.0F;
      } else {
         int lastDot = digits.lastIndexOf(46);
         int lastComma = digits.lastIndexOf(44);
         int lastSep = Math.max(lastDot, lastComma);
         if (lastSep != -1) {
            int digitsAfter = digits.length() - lastSep - 1;
            if (digitsAfter == 3) {
               digits = digits.replaceAll("[.,]", "");
            } else if (digitsAfter > 0 && digitsAfter <= 2) {
               String intPart = digits.substring(0, lastSep).replaceAll("[.,]", "");
               String fracPart = digits.substring(lastSep + 1);
               digits = intPart + "." + fracPart;
            } else {
               digits = digits.replaceAll("[.,]", "");
            }
         }

         try {
            return Double.parseDouble(digits) * multiplier;
         } catch (NumberFormatException var11) {
            return (double)-1.0F;
         }
      }
   }
}
