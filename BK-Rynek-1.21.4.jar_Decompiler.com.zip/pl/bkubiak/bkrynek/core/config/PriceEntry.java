package pl.bkubiak.bkrynek.core.config;

public class PriceEntry {
   public String name;
   public String lore;
   public String material;
   public String enchants;
   public double maxPrice = (double)0.0F;
   public double sellPrice = (double)0.0F;
   public int componentCount = 0;
   public Integer customModelData;
   public Integer requiredCount = 1;
   public Integer sellCount = 1;
   public Boolean buyEnabled = true;
   public Boolean sellEnabled = false;
   public String excludedEnchants;
   public Integer minDaysLeft;
}
