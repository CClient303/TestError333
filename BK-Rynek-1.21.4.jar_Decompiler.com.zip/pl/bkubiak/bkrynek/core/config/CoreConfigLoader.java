package pl.bkubiak.bkrynek.core.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public final class CoreConfigLoader {
   private static final Gson GSON = (new GsonBuilder()).setPrettyPrinting().create();
   private static final String DEFAULT_CONFIG_NAME = "bkrynek-config";
   private static final String SELECTED_CONFIG_FILE = "selected.txt";
   private static String activeConfigName = "bkrynek-config";
   private static Path lastModConfigDir = null;

   private CoreConfigLoader() {
   }

   public static ServersConfig loadConfig(Path modConfigDir) {
      lastModConfigDir = modConfigDir;
      Path configDir = ensureConfigDir(modConfigDir);
      loadActiveConfigName(configDir);
      Path configFile = configDir.resolve(activeConfigName + ".json");
      ServersConfig config;
      if (!Files.exists(configFile, new LinkOption[0])) {
         config = createDefaultConfig();
         saveAllConfigs(config, modConfigDir);
      } else {
         try {
            Reader reader = Files.newBufferedReader(configFile);

            try {
               config = (ServersConfig)GSON.fromJson(reader, ServersConfig.class);
               if (config == null) {
                  config = createDefaultConfig();
               }

               if (config.discordWebhookUrl == null) {
                  config.discordWebhookUrl = "";
               }
            } catch (Throwable var8) {
               if (reader != null) {
                  try {
                     reader.close();
                  } catch (Throwable var7) {
                     var8.addSuppressed(var7);
                  }
               }

               throw var8;
            }

            if (reader != null) {
               reader.close();
            }
         } catch (IOException e) {
            e.printStackTrace();
            config = createDefaultConfig();
         }
      }

      for(ServerEntry entry : config.servers) {
         applyDefaults(entry);
      }

      return config;
   }

   private static void loadActiveConfigName(Path configDir) {
      Path selectedFile = configDir.resolve("selected.txt");
      if (Files.exists(selectedFile, new LinkOption[0])) {
         try {
            String name = Files.readString(selectedFile).trim();
            if (!name.isEmpty()) {
               activeConfigName = name;
            }
         } catch (IOException var3) {
         }
      }

   }

   public static void setActiveConfigName(String name) {
      if (name == null || name.isEmpty()) {
         name = "bkrynek-config";
      }

      activeConfigName = name;
      if (lastModConfigDir != null) {
         Path configDir = ensureConfigDir(lastModConfigDir);
         Path selectedFile = configDir.resolve("selected.txt");

         try {
            Files.writeString(selectedFile, name);
         } catch (IOException e) {
            e.printStackTrace();
         }
      }

   }

   public static String getActiveConfigName() {
      return activeConfigName;
   }

   public static void saveAllConfigs(ServersConfig config, Path modConfigDir) {
      Path configDir = ensureConfigDir(modConfigDir);
      ServersConfig mainConfig = new ServersConfig();
      mainConfig.defaultProfile = config.defaultProfile;
      mainConfig.soundsEnabled = config.soundsEnabled;
      mainConfig.discordWebhookUrl = config.discordWebhookUrl;
      mainConfig.webhookBuyEnabled = config.webhookBuyEnabled;
      mainConfig.webhookSellEnabled = config.webhookSellEnabled;
      mainConfig.language = config.language;
      mainConfig.hudX = config.hudX;
      mainConfig.hudY = config.hudY;
      mainConfig.logX = config.logX;
      mainConfig.logY = config.logY;
      mainConfig.webhookListingEnabled = config.webhookListingEnabled;
      mainConfig.servers = config.servers;
      Path configFile = configDir.resolve(activeConfigName + ".json");

      try {
         Writer writer = Files.newBufferedWriter(configFile);

         try {
            GSON.toJson(mainConfig, writer);
         } catch (Throwable var9) {
            if (writer != null) {
               try {
                  writer.close();
               } catch (Throwable var8) {
                  var9.addSuppressed(var8);
               }
            }

            throw var9;
         }

         if (writer != null) {
            writer.close();
         }
      } catch (IOException e) {
         e.printStackTrace();
      }

   }

   private static Path ensureConfigDir(Path modConfigDir) {
      if (modConfigDir == null) {
         return null;
      } else {
         try {
            if (!Files.exists(modConfigDir, new LinkOption[0])) {
               Files.createDirectories(modConfigDir);
            }
         } catch (IOException e) {
            e.printStackTrace();
         }

         return modConfigDir;
      }
   }

   public static void saveFullConfigObject(ServersConfig config) {
      saveAllConfigs(config, lastModConfigDir);
   }

   public static void saveSnapshot(String name, ServersConfig config) throws IOException {
      if (lastModConfigDir != null && !name.equals(activeConfigName)) {
         Path configDir = ensureConfigDir(lastModConfigDir);
         Path file = configDir.resolve(name + ".json");
         Writer writer = Files.newBufferedWriter(file);

         try {
            GSON.toJson(config, writer);
         } catch (Throwable var8) {
            if (writer != null) {
               try {
                  writer.close();
               } catch (Throwable var7) {
                  var8.addSuppressed(var7);
               }
            }

            throw var8;
         }

         if (writer != null) {
            writer.close();
         }

      }
   }

   public static void deleteSnapshot(String name) throws IOException {
      if (lastModConfigDir != null && !name.equals("bkrynek-config")) {
         Path configDir = ensureConfigDir(lastModConfigDir);
         Path file = configDir.resolve(name + ".json");
         Files.deleteIfExists(file);
         if (name.equals(activeConfigName)) {
            setActiveConfigName("bkrynek-config");
         }

      }
   }

   public static List<String> listSnapshots() {
      List<String> snapshots = new ArrayList();
      if (lastModConfigDir == null) {
         return snapshots;
      } else {
         Path configDir = ensureConfigDir(lastModConfigDir);
         if (Files.exists(configDir.resolve("bkrynek-config.json"), new LinkOption[0])) {
            snapshots.add("bkrynek-config");
         }

         try {
            DirectoryStream<Path> stream = Files.newDirectoryStream(configDir, "*.json");

            try {
               for(Path entry : stream) {
                  String fileName = entry.getFileName().toString();
                  String nameOnly = fileName.substring(0, fileName.lastIndexOf(46));
                  if (!nameOnly.equals("bkrynek-config")) {
                     snapshots.add(nameOnly);
                  }
               }
            } catch (Throwable var8) {
               if (stream != null) {
                  try {
                     stream.close();
                  } catch (Throwable var7) {
                     var8.addSuppressed(var7);
                  }
               }

               throw var8;
            }

            if (stream != null) {
               stream.close();
            }
         } catch (IOException e) {
            e.printStackTrace();
         }

         return snapshots;
      }
   }

   public static ServersConfig loadFullConfig(String name) {
      if (lastModConfigDir == null) {
         return null;
      } else {
         Path configDir = ensureConfigDir(lastModConfigDir);
         Path file = configDir.resolve(name + ".json");
         if (!Files.exists(file, new LinkOption[0])) {
            return null;
         } else {
            try {
               String content = Files.readString(file);
               if (content.contains("\"servers\":")) {
                  ServersConfig cfg = (ServersConfig)GSON.fromJson(content, ServersConfig.class);
                  if (cfg != null) {
                     for(ServerEntry entry : cfg.servers) {
                        applyDefaults(entry);
                     }

                     return cfg;
                  }
               }

               ServerEntry entry = (ServerEntry)GSON.fromJson(content, ServerEntry.class);
               if (entry != null) {
                  ServersConfig sc = new ServersConfig();
                  sc.servers.add(entry);
                  sc.defaultProfile = entry.profileName != null ? entry.profileName : "default";
                  sc.discordWebhookUrl = "";
                  return sc;
               }
            } catch (Exception e) {
               e.printStackTrace();
            }

            return null;
         }
      }
   }

   public static ServerEntry loadSnapshot(String name) {
      ServersConfig full = loadFullConfig(name);
      if (full != null && !full.servers.isEmpty()) {
         for(ServerEntry se : full.servers) {
            if (se.profileName != null && se.profileName.equalsIgnoreCase(full.defaultProfile)) {
               return se;
            }
         }

         return (ServerEntry)full.servers.get(0);
      } else {
         return null;
      }
   }

   public static void saveConfigJson(String jsonContent) throws IOException {
      if (lastModConfigDir == null) {
         throw new IllegalStateException("Config directory not initialized yet!");
      } else {
         Path configDir = ensureConfigDir(lastModConfigDir);
         Path configFile = configDir.resolve(activeConfigName + ".json");
         Files.writeString(configFile, jsonContent, StandardCharsets.UTF_8);
      }
   }

   public static String getConfigJson() throws IOException {
      if (lastModConfigDir == null) {
         throw new IllegalStateException("Config directory not initialized yet!");
      } else {
         Path configDir = ensureConfigDir(lastModConfigDir);
         Path configFile = configDir.resolve(activeConfigName + ".json");
         return !Files.exists(configFile, new LinkOption[0]) ? "{}" : Files.readString(configFile, StandardCharsets.UTF_8);
      }
   }

   public static ServersConfig reloadConfig() {
      if (lastModConfigDir == null) {
         throw new IllegalStateException("Config directory not initialized yet!");
      } else {
         return loadConfig(lastModConfigDir);
      }
   }

   public static String getDefaultConfigJson() {
      return GSON.toJson(createDefaultConfig());
   }

   public static ServersConfig createDefaultConfig() {
      ServersConfig cfg = new ServersConfig();
      cfg.defaultProfile = "default";
      cfg.discordWebhookUrl = "";
      cfg.soundsEnabled = false;
      cfg.webhookBuyEnabled = true;
      cfg.webhookSellEnabled = true;
      cfg.webhookListingEnabled = true;
      cfg.language = "en";
      cfg.hudX = 10;
      cfg.hudY = 10;
      cfg.logX = 10;
      cfg.logY = 100;
      ServerEntry defaultServer = new ServerEntry();
      defaultServer.profileName = "default";
      defaultServer.domains = new ArrayList(List.of("*"));
      defaultServer.loreRegex = "(?i).*Cena\\s*:?\\s*(?:\\$\\s*)?((?:\\d{1,3}(?:[\\s\\u00A0.,]\\d{3})*|\\d+)(?:mld|m|k)?)(?:\\s*\\$)?.*";
      applyDefaults(defaultServer);
      cfg.servers.add(defaultServer);
      ServerEntry server1 = new ServerEntry();
      server1.domains = new ArrayList(List.of("minestar.pl"));
      server1.profileName = "minestar_boxpvp";
      server1.loreRegex = "(?i).*Cena.*?\\$?([\\d.,]+(?:mld|[km])?).*";
      server1.highlightColor = "#00FF00";
      server1.highlightColorStack = "#FF9900";
      server1.miniAlarmSound = "minecraft:ui.button.click";
      server1.miniAlarmSoundStack = "minecraft:ui.toast.challenge_complete";
      server1.marketCommands = new ArrayList(List.of("/ah otworz", "/rynek otworz"));
      server1.marketGuiTitle = "Rynek";
      server1.marketNextPageName = "Nastepna strona";
      server1.marketNextPageMaterial = "minecraft:tipped_arrow";
      server1.marketNextPageSlot = 53;
      server1.marketOpenDelayMs = 500;
      server1.marketNextDelayMs = 200;
      server1.marketCloseDelayMs = 500;
      applyDefaults(server1);
      PriceEntry pe1 = new PriceEntry();
      pe1.name = "minecraft:gunpowder";
      pe1.maxPrice = (double)100.0F;
      pe1.buyEnabled = true;
      pe1.sellEnabled = false;
      pe1.requiredCount = 1;
      pe1.sellCount = 1;
      pe1.sellPrice = (double)0.0F;
      pe1.componentCount = 0;
      server1.prices.add(pe1);
      cfg.servers.add(server1);
      ServerEntry server2 = new ServerEntry();
      server2.domains = new ArrayList(List.of("anarchia.gg"));
      server2.profileName = "anarchia_smp";
      server2.loreRegex = "(?i).*Koszt.*?\\$([\\d.,]+(?:mld|[km])?).*";
      server2.highlightColor = "#00FF00";
      server2.highlightColorStack = "#FF9900";
      server2.miniAlarmSound = "minecraft:ui.button.click";
      server2.miniAlarmSoundStack = "minecraft:ui.toast.challenge_complete";
      server2.marketCommands = new ArrayList(List.of("/ah", "/rynek"));
      server2.marketGuiTitle = "Rynek";
      server2.marketNextPageName = "Nastepna strona";
      server2.marketNextPageMaterial = "minecraft:lime_dye";
      server2.marketNextPageSlot = 50;
      server2.confirmSlot = 11;
      server2.marketOpenDelayMs = 500;
      server2.marketNextDelayMs = 100;
      server2.marketCloseDelayMs = 500;
      server2.marketConfirmDelayMs = 250;
      server2.marketRestartDelayMs = 500;
      server2.aggressiveAnarchiaMode = true;
      applyDefaults(server2);
      PriceEntry pe2 = new PriceEntry();
      pe2.name = "minecraft:emerald";
      pe2.maxPrice = (double)200.0F;
      pe2.buyEnabled = true;
      pe2.sellEnabled = false;
      pe2.requiredCount = 1;
      pe2.sellPrice = (double)0.0F;
      pe2.componentCount = 0;
      server2.prices.add(pe2);
      cfg.servers.add(server2);
      ServerEntry server3 = new ServerEntry();
      server3.domains = new ArrayList(List.of("rapy.pl", "rapy.gg", "rapysmp.pl", "jjsmp.pl"));
      server3.profileName = "rapy";
      server3.loreRegex = "(?i).*Cena\\s*:?\\s*(?:\\$\\s*)?((?:\\d{1,3}(?:[\\s\\u00A0.,]\\d{3})*|\\d+))(?:\\s*\\$)?.*";
      server3.highlightColor = "#00FF00";
      server3.highlightColorStack = "#FF9900";
      server3.miniAlarmSound = "minecraft:ui.button.click";
      server3.miniAlarmSoundStack = "minecraft:ui.toast.challenge_complete";
      server3.marketCommands = new ArrayList(List.of("/ah", "/rynek"));
      server3.marketGuiTitle = "Market";
      server3.marketNextPageName = "Nastepna strona";
      server3.marketNextPageMaterial = "minecraft:arrow";
      server3.marketNextPageSlot = 53;
      server3.marketOpenDelayMs = 500;
      server3.marketNextDelayMs = 200;
      server3.marketCloseDelayMs = 500;
      applyDefaults(server3);
      PriceEntry pe3 = new PriceEntry();
      pe3.name = "minecraft:emerald";
      pe3.maxPrice = (double)200.0F;
      pe3.buyEnabled = true;
      pe3.sellEnabled = false;
      pe3.requiredCount = 1;
      pe3.sellPrice = (double)0.0F;
      pe3.componentCount = 0;
      server3.prices.add(pe3);
      cfg.servers.add(server3);
      ServerEntry server4 = new ServerEntry();
      server4.domains = new ArrayList(List.of("pykmc.pl"));
      server4.profileName = "pykmc";
      server4.loreRegex = "(?i).*Kwota.*?\\$([\\d.,]+(?:mld|m|k)?).*";
      server4.highlightColor = "#00FF00";
      server4.highlightColorStack = "#FF9900";
      server4.miniAlarmSound = "minecraft:ui.button.click";
      server4.miniAlarmSoundStack = "minecraft:ui.toast.challenge_complete";
      server4.marketCommands = new ArrayList(List.of("/ah", "/rynek"));
      server4.marketGuiTitle = "Rynek";
      server4.marketNextPageName = "Nastepna";
      server4.marketNextPageMaterial = "minecraft:green_terracotta";
      server4.marketNextPageSlot = 50;
      server4.marketOpenDelayMs = 500;
      server4.marketNextDelayMs = 200;
      server4.marketCloseDelayMs = 500;
      applyDefaults(server4);
      PriceEntry pe4 = new PriceEntry();
      pe4.name = "minecraft:emerald";
      pe4.maxPrice = (double)200.0F;
      pe4.buyEnabled = true;
      pe4.sellEnabled = false;
      pe4.requiredCount = 1;
      pe4.sellPrice = (double)0.0F;
      pe4.componentCount = 0;
      server4.prices.add(pe4);
      cfg.servers.add(server4);
      ServerEntry server5 = new ServerEntry();
      server5.domains = new ArrayList(List.of("donutsmp.net", "donutsmp.com"));
      server5.profileName = "donutsmp";
      server5.loreRegex = "(?i)Price:\\s*\\$\\s*([\\d.,]+(?:[mktb])?)";
      server5.loreSellerRegex = "(?i)Seller:\\s*([^\\s]+)";
      server5.confirmItemName = "CONFIRM";
      server5.marketGuiTitle = "AUCTION";
      server5.errorMessages = new ArrayList(List.of("This item was already bought"));
      server5.highlightColor = "#00FF00";
      server5.scanningInterval = 100;
      server5.highlightColorStack = "#FF9900";
      server5.miniAlarmSound = "minecraft:ui.button.click";
      server5.miniAlarmSoundStack = "minecraft:ui.toast.challenge_complete";
      server5.marketCommands = new ArrayList(List.of("/ah", "/rynek"));
      server5.marketNextPageName = "Next Page";
      server5.marketNextPageMaterial = "minecraft:arrow";
      server5.marketNextPageSlot = 53;
      server5.marketOpenDelayMs = 500;
      server5.marketNextDelayMs = 200;
      server5.marketCloseDelayMs = 500;
      server5.skipConfirmMessage = true;
      applyDefaults(server5);
      cfg.servers.add(server5);
      return cfg;
   }

   private static void applyDefaults(ServerEntry entry) {
      if (entry.prices == null) {
         entry.prices = new ArrayList();
      }

      if (entry.loreRegex == null || entry.loreRegex.equals("Cena: (\\d+)")) {
         entry.loreRegex = "(?i).*Cena\\s*:?\\s*(?:\\$\\s*)?((?:\\d{1,3}(?:[\\s\\u00A0.,]\\d{3})*|\\d+)(?:mld|m|k)?)(?:\\s*\\$)?.*";
      }

      if (entry.highlightColor == null) {
         entry.highlightColor = "#00FF00";
      }

      if (entry.highlightColorStack == null) {
         entry.highlightColorStack = "#FF9900";
      }

      if (entry.miniAlarmSound == null) {
         entry.miniAlarmSound = "minecraft:ui.button.click";
      }

      if (entry.miniAlarmSoundStack == null) {
         entry.miniAlarmSoundStack = "minecraft:entity.player.levelup";
      }

      if (entry.marketCommands == null) {
         entry.marketCommands = new ArrayList();
      }

      if (entry.marketOpenDelayMs == null) {
         entry.marketOpenDelayMs = 1500;
      }

      if (entry.marketNextDelayMs == null) {
         entry.marketNextDelayMs = 800;
      }

      if (entry.marketCloseDelayMs == null) {
         entry.marketCloseDelayMs = 500;
      }

      if (entry.marketConfirmDelayMs == null) {
         entry.marketConfirmDelayMs = 100;
      }

      if (entry.marketActionDelayMs == null) {
         entry.marketActionDelayMs = 50;
      }

      if (entry.loreSellerRegex == null) {
         entry.loreSellerRegex = "";
      }

      if (entry.confirmItemName == null) {
         entry.confirmItemName = "";
      }

      if (entry.marketConfirmAttempts == null) {
         entry.marketConfirmAttempts = 1;
      }

      if (entry.autoRepair == null) {
         entry.autoRepair = false;
      }

      if (entry.repairCommand == null) {
         entry.repairCommand = "repair";
      }

   }
}
