package pl.bkubiak.bkrynek.core.config;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public class ServerEntry {
   public List<String> domains = new ArrayList();
   public String profileName;
   public String loreRegex = "Cena: (\\d+)";
   public String loreSellerRegex;
   public String confirmItemName;
   public String highlightColor = "#80FF00";
   public String highlightColorStack = "#FF8000";
   public String miniAlarmSound = "minecraft:ui.button.click";
   public String miniAlarmSoundStack = "minecraft:entity.player.levelup";
   public List<String> marketCommands = new ArrayList();
   public String marketGuiTitle;
   public String marketNextPageName;
   public String marketNextPageMaterial;
   public Integer refreshSlot;
   public Integer confirmSlot;
   public Integer marketNextPageSlot;
   public Integer marketOpenDelayMs;
   public Integer marketNextDelayMs;
   public Integer marketCloseDelayMs;
   public Integer marketConfirmDelayMs;
   public Integer marketActionDelayMs;
   public Integer marketConfirmAttempts = 1;
   public Integer marketOpenAttempts = 1;
   public List<String> successMessages = new ArrayList();
   public List<String> errorMessages = new ArrayList();
   public Integer scanningInterval = 300;
   public Integer marketRestartDelayMs = 300;
   public Boolean skipConfirmMessage = false;
   public Boolean aggressiveAnarchiaMode = false;
   public Integer sortingSlot = 53;
   public String sortingKeyword = "najnowsz";
   public Boolean autoReconnect = true;
   public Boolean autoStartScanner = true;
   public String loginCommand = "/login MojeHaslo123";
   public Integer reconnectDelayMs = 8;
   public Boolean usePremiumAccount = true;
   public Boolean autoRepair = false;
   public String repairCommand = "repair";
   public List<PriceEntry> prices = new ArrayList();
   public transient Path sourceFile;
}
