package pl.bkubiak.bkrynek.core.config;

import java.util.ArrayList;
import java.util.List;

public class ServersConfig {
   public String defaultProfile = "default";
   public List<ServerEntry> servers = new ArrayList();
   public boolean soundsEnabled = false;
   public String discordWebhookUrl = "";
   public boolean webhookBuyEnabled = true;
   public boolean webhookSellEnabled = true;
   public boolean webhookListingEnabled = true;
   public boolean ignoreComponents = false;
   public String language = "en";
   public int hudX = 10;
   public int hudY = 10;
   public int logX = 10;
   public int logY = 100;
}
