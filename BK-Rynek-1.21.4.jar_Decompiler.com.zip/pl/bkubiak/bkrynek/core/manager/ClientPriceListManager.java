package pl.bkubiak.bkrynek.core.manager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import pl.bkubiak.bkrynek.core.config.CoreConfigLoader;
import pl.bkubiak.bkrynek.core.config.PriceEntry;
import pl.bkubiak.bkrynek.core.config.ServerEntry;
import pl.bkubiak.bkrynek.core.config.ServersConfig;
import pl.bkubiak.bkrynek.core.util.CompositeKeyUtil;

public class ClientPriceListManager {
   private static final Map<String, List<PriceEntry>> priceLists = new HashMap();
   private static final Map<String, Map<String, String>> customLookup = new HashMap();
   private static String activeProfile = "default";
   private static String activePreset = null;
   private static boolean ignoreComponents = false;
   private static long version = 0L;

   public static long getVersion() {
      return version;
   }

   public static void fullReloadMemory(ServersConfig config) {
      priceLists.clear();
      customLookup.clear();
      ignoreComponents = config.ignoreComponents;

      for(ServerEntry entry : config.servers) {
         String profile = entry.profileName;
         priceLists.put(profile, new ArrayList(entry.prices));
         Map<String, String> lookup = new HashMap();

         for(PriceEntry pe : entry.prices) {
            lookup.put(CompositeKeyUtil.getCompositeKeyFromEntry(pe), pe.name);
         }

         customLookup.put(profile, lookup);
      }

      markDirty();
   }

   private static void markDirty() {
      ++version;
   }

   public static void setActiveProfile(String profile) {
      activeProfile = profile;
      priceLists.computeIfAbsent("default", (k) -> new ArrayList());
      customLookup.computeIfAbsent("default", (k) -> new HashMap());
      priceLists.computeIfAbsent(profile, (k) -> new ArrayList());
      customLookup.computeIfAbsent(profile, (k) -> new HashMap());
      markDirty();
   }

   public static String getActiveProfile() {
      return activeProfile;
   }

   public static String listProfiles() {
      return priceLists.isEmpty() ? "No profiles defined." : String.join(", ", priceLists.keySet());
   }

   public static void nextProfile() {
      List<String> keys = new ArrayList(priceLists.keySet());
      if (!keys.isEmpty()) {
         int idx = keys.indexOf(activeProfile);
         activeProfile = (String)keys.get((idx + 1) % keys.size());
         markDirty();
      }
   }

   public static void prevProfile() {
      List<String> keys = new ArrayList(priceLists.keySet());
      if (!keys.isEmpty()) {
         int idx = keys.indexOf(activeProfile);
         activeProfile = (String)keys.get((idx - 1 + keys.size()) % keys.size());
         markDirty();
      }
   }

   public static void addPriceEntry(PriceEntry entry) {
      String compositeKey = CompositeKeyUtil.getCompositeKeyFromEntry(entry);
      List<PriceEntry> entries = (List)priceLists.computeIfAbsent(activeProfile, (k) -> new ArrayList());
      entries.removeIf((pe) -> CompositeKeyUtil.getCompositeKeyFromEntry(pe).equals(compositeKey));
      entries.add(entry);
      markDirty();
   }

   public static boolean removePriceEntry(PriceEntry entry) {
      String compositeKey = CompositeKeyUtil.getCompositeKeyFromEntry(entry);
      List<PriceEntry> entries = (List)priceLists.get(activeProfile);
      if (entries != null) {
         boolean removed = entries.removeIf((pe) -> CompositeKeyUtil.getCompositeKeyFromEntry(pe).equals(compositeKey));
         if (removed) {
            markDirty();
            return true;
         }
      }

      return false;
   }

   public static List<PriceEntry> getPriceListForProfile(String profile) {
      return (List)priceLists.getOrDefault(profile, new ArrayList());
   }

   public static void addProfile(String name, List<PriceEntry> prices) {
      priceLists.put(name, new ArrayList(prices));
      markDirty();
   }

   public static void syncMemoryToConfig(ServersConfig config) {
      if (config != null && config.servers != null) {
         for(ServerEntry se : config.servers) {
            List<PriceEntry> list = (List)priceLists.get(se.profileName);
            if (list != null) {
               se.prices = new ArrayList(list);
            }
         }

      }
   }

   public static PriceEntry findMatchingPriceEntry(String noColorName, List<String> loreLines, String materialId, String enchantments, int componentCount, Integer customModelData, Object extra) {
      List<PriceEntry> entries = (List)priceLists.get(activeProfile);
      if (entries == null) {
         return null;
      } else {
         boolean isSelling = false;
         Integer daysLeft = null;
         if (extra instanceof Boolean) {
            isSelling = (Boolean)extra;
         } else if (extra instanceof Integer) {
            daysLeft = (Integer)extra;
         }

         PriceEntry best = null;
         int bestScore = -1;
         String lowerMaterialId = materialId.toLowerCase();
         String lowerEnchantments = enchantments == null ? "" : enchantments.toLowerCase();
         Iterator var14 = entries.iterator();

         while(true) {
            PriceEntry pe;
            int score;
            boolean foundExcluded;
            do {
               while(true) {
                  while(true) {
                     while(true) {
                        while(true) {
                           while(true) {
                              if (!var14.hasNext()) {
                                 if (isSelling && best != null) {
                                    boolean entryHasLore = best.lore != null && !best.lore.isEmpty();
                                    boolean entryHasEnchants = best.enchants != null && !best.enchants.isEmpty();
                                    score = best.customModelData != null;
                                    boolean entryIsGeneric = !entryHasLore && !entryHasEnchants && !score;
                                    if (entryIsGeneric) {
                                       foundExcluded = lowerEnchantments != null && !lowerEnchantments.isEmpty();
                                       boolean itemHasRichLore = loreLines != null && loreLines.size() > 3;
                                       if (foundExcluded || itemHasRichLore) {
                                          System.out.println("[BK-Rynek SELL SAFETY] Generic sell match: entry='" + best.name + "' for item with enchants/lore. Allowing because sellPrice is set.");
                                       }
                                    }
                                 }

                                 return best;
                              }

                              pe = (PriceEntry)var14.next();
                              if (isSelling) {
                                 if (pe.sellEnabled != null && pe.sellEnabled) {
                                    break;
                                 }
                              } else if (extra instanceof Boolean) {
                                 if (pe.buyEnabled == null || pe.buyEnabled) {
                                    break;
                                 }
                              } else {
                                 score = pe.buyEnabled != null && pe.buyEnabled || pe.sellEnabled != null && pe.sellEnabled;
                                 if (score) {
                                    break;
                                 }
                              }
                           }

                           if (daysLeft == null || pe.minDaysLeft == null || daysLeft >= pe.minDaysLeft) {
                              if (pe.material == null || pe.material.isEmpty()) {
                                 break;
                              }

                              String m1 = materialId.toLowerCase();
                              String m2 = pe.material.toLowerCase();
                              if (m1.startsWith("minecraft:")) {
                                 m1 = m1.substring(10);
                              }

                              if (m2.startsWith("minecraft:")) {
                                 m2 = m2.substring(10);
                              }

                              if (m1.equals(m2)) {
                                 break;
                              }
                           }
                        }

                        if ((pe.customModelData == null || pe.customModelData.equals(customModelData)) && (ignoreComponents || pe.componentCount <= 0 || componentCount >= pe.componentCount) && (!isSelling || pe.name != null && !pe.name.isEmpty() && noColorName.equalsIgnoreCase(pe.name))) {
                           score = 0;
                           if (pe.material != null && !pe.material.isEmpty()) {
                              score += 1000;
                           }

                           if (pe.name == null || pe.name.isEmpty()) {
                              break;
                           }

                           if (noColorName.equals(pe.name)) {
                              score += Math.min(500, pe.name.length()) + 200;
                              break;
                           }

                           String lowerEntryName = pe.name.toLowerCase();
                           String normalizedEntryName = lowerEntryName.replace(" ", "_");
                           boolean materialNameMatch = lowerMaterialId.contains(lowerEntryName) || lowerMaterialId.contains(normalizedEntryName);
                           if (materialNameMatch) {
                              score += Math.min(500, pe.name.length());
                              break;
                           }
                        }
                     }

                     if (pe.lore == null || pe.lore.isEmpty()) {
                        break;
                     }

                     String[] configLoreParts = pe.lore.split(";");
                     foundExcluded = true;

                     for(String part : configLoreParts) {
                        if (!part.trim().isEmpty()) {
                           boolean partFound = false;

                           for(String line : loreLines) {
                              if (line.toLowerCase().contains(part.toLowerCase())) {
                                 partFound = true;
                                 break;
                              }
                           }

                           if (!partFound) {
                              foundExcluded = false;
                              break;
                           }
                        }
                     }

                     if (foundExcluded) {
                        score += isSelling ? 5000 : 50;
                        break;
                     }
                  }

                  if (pe.enchants == null || pe.enchants.isEmpty()) {
                     break;
                  }

                  String[] requiredEnchants = pe.enchants.toLowerCase().split(",");
                  foundExcluded = true;

                  for(String req : requiredEnchants) {
                     if (!req.trim().isEmpty() && !lowerEnchantments.contains(req.trim())) {
                        foundExcluded = false;
                        break;
                     }
                  }

                  if (foundExcluded) {
                     score += isSelling ? 2500 : 25;
                     break;
                  }
               }

               if (pe.excludedEnchants == null || pe.excludedEnchants.isEmpty()) {
                  break;
               }

               String[] excludedList = pe.excludedEnchants.toLowerCase().split(",");
               foundExcluded = false;

               for(String excluded : excludedList) {
                  if (!excluded.trim().isEmpty() && lowerEnchantments.contains(excluded.trim())) {
                     foundExcluded = true;
                     break;
                  }
               }
            } while(foundExcluded);

            if (pe.customModelData != null) {
               score += 2000;
            }

            if (score > bestScore) {
               bestScore = score;
               best = pe;
            }
         }
      }
   }

   public static PriceEntry findBestMatch(String name, List<String> lore, String material, Integer customModelData) {
      return findMatchingPriceEntry(name, lore, material, "", 0, customModelData, (Object)null);
   }

   public static Map<String, List<PriceEntry>> getAllProfiles() {
      return priceLists;
   }

   public static void clearAllProfiles() {
      priceLists.clear();
      customLookup.clear();
      activeProfile = "default";
      markDirty();
   }

   public static boolean savePreset(String name, ServersConfig config) {
      try {
         CoreConfigLoader.saveSnapshot(name, config);
         activePreset = name;
         markDirty();
         return true;
      } catch (Exception e) {
         e.printStackTrace();
         return false;
      }
   }

   public static ServersConfig loadPreset(String name) {
      return CoreConfigLoader.loadFullConfig(name);
   }

   public static boolean deletePreset(String name) {
      try {
         CoreConfigLoader.deleteSnapshot(name);
         if (name.equals(activePreset)) {
            activePreset = null;
         }

         markDirty();
         return true;
      } catch (Exception e) {
         e.printStackTrace();
         return false;
      }
   }

   public static List<String> listPresets() {
      return CoreConfigLoader.listSnapshots();
   }

   public static String getActivePreset() {
      return activePreset;
   }

   public static void setActivePreset(String name) {
      activePreset = name;
   }

   private static PriceEntry copyPriceEntry(PriceEntry src) {
      if (src == null) {
         return null;
      } else {
         PriceEntry copy = new PriceEntry();
         copy.name = src.name;
         copy.lore = src.lore;
         copy.material = src.material;
         copy.enchants = src.enchants;
         copy.maxPrice = src.maxPrice;
         copy.sellPrice = src.sellPrice;
         copy.componentCount = src.componentCount;
         copy.customModelData = src.customModelData;
         copy.requiredCount = src.requiredCount;
         copy.sellCount = src.sellCount;
         copy.buyEnabled = src.buyEnabled;
         copy.sellEnabled = src.sellEnabled;
         copy.excludedEnchants = src.excludedEnchants;
         copy.minDaysLeft = src.minDaysLeft;
         return copy;
      }
   }
}
