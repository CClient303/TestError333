package pl.bkubiak.bkrynek.core.util;

import java.util.HashMap;
import java.util.Map;

public class EnchantMapper {
   private static final Map<String, String> pre120Map = new HashMap();
   private static final Map<String, String> post121Map = new HashMap();

   private static void register(String shortName, String minecraftId, String alias) {
      register(shortName, minecraftId, alias, alias);
   }

   private static void register(String shortName, String minecraftId, String alias, String standardName) {
      if (shortName != null) {
         pre120Map.put(shortName, standardName);
         post121Map.put(shortName, standardName);
      }

      if (minecraftId != null) {
         pre120Map.put(minecraftId, standardName);
         post121Map.put(minecraftId, standardName);
      }

      if (alias != null) {
         pre120Map.put(alias.toLowerCase(), standardName);
         post121Map.put(alias.toLowerCase(), standardName);
      }

   }

   public static String mapEnchant(String shortName, boolean post121) {
      String baseName = shortName.toLowerCase();
      if (baseName.startsWith("minecraft:")) {
         baseName = baseName.substring("minecraft:".length());
      }

      String levelPart = "";

      int index;
      for(index = baseName.length() - 1; index >= 0 && Character.isDigit(baseName.charAt(index)); --index) {
      }

      if (index < baseName.length() - 1) {
         levelPart = baseName.substring(index + 1);
         baseName = baseName.substring(0, index + 1).trim();
      }

      if (baseName.endsWith("_")) {
         baseName = baseName.substring(0, baseName.length() - 1);
      }

      String mapped;
      if (post121) {
         mapped = (String)post121Map.getOrDefault(baseName, "unknown");
      } else {
         mapped = (String)pre120Map.getOrDefault(baseName, "unknown");
      }

      return !mapped.equals("unknown") && !levelPart.isEmpty() ? mapped + " " + levelPart : mapped;
   }

   static {
      register("prot", "protection", "Protection");
      register("fpro", "fire_protection", "Fire Protection");
      register("bpro", "blast_protection", "Blast Protection");
      register("ppro", "projectile_protection", "Projectile Protection");
      register("feat", "feather_falling", "Feather Falling");
      register("resp", "respiration", "Respiration");
      register("aqua", "aqua_affinity", "Aqua Affinity");
      register("dept", "depth_strider", "Depth Strider");
      register("fros", "frost_walker", "Frost Walker");
      register("soul", "soul_speed", "Soul Speed");
      register("swif", "swift_sneak", "Swift Sneak");
      register("thorn", "thorns", "Thorns");
      register("sharp", "sharpness", "Sharpness");
      register("smite", "smite", "Smite");
      register("bane", "bane_of_arthropods", "Bane of Arthropods");
      register("fire", "fire_aspect", "Fire");
      register("knock", "knockback", "Knockback");
      register("loot", "looting", "Looting");
      register("sweep", "sweeping_edge", "Sweeping Edge");
      register("sweeping", "sweeping", "Sweeping Edge");
      register("dens", "density", "Density");
      register("brea", "breach", "Breach");
      register("wind", "wind_burst", "Wind Burst");
      register("effi", "efficiency", "Efficiency");
      register("silk", "silk_touch", "Silk Touch");
      register("unbr", "unbreaking", "Unbreaking");
      register("fort", "fortune", "Fortune");
      register("power", "power", "Power");
      register("punch", "punch", "Punch");
      register("flame", "flame", "Flame");
      register("infi", "infinity", "Infinity");
      register("luck", "luck_of_the_sea", "Luck of the Sea");
      register("lure", "lure", "Lure");
      register("mult", "multishot", "Multishot");
      register("pier", "piercing", "Piercing");
      register("quic", "quick_charge", "Quick Charge");
      register("chan", "channeling", "Channeling");
      register("impa", "impaling", "Impaling");
      register("loya", "loyalty", "Loyalty");
      register("ript", "riptide", "Riptide");
      register("mend", "mending", "Mending");
      register("bind", "binding_curse", "Curse of Binding");
      register("vani", "vanishing_curse", "Curse of Vanishing");
      register((String)null, (String)null, "Ostrość", "Sharpness");
      register((String)null, (String)null, "Wydajność", "Efficiency");
      register((String)null, (String)null, "Niezniszczalność", "Unbreaking");
      register((String)null, (String)null, "Ochrona", "Protection");
      register((String)null, (String)null, "Szczęście", "Fortune");
      register((String)null, (String)null, "Grabież", "Looting");
      register((String)null, (String)null, "Zaklęty ogień", "Fire Aspect");
      register((String)null, (String)null, "Odrzut", "Knockback");
      register((String)null, (String)null, "Moc", "Power");
      register((String)null, (String)null, "Uderzenie", "Punch");
      register((String)null, (String)null, "Płomień", "Flame");
      register((String)null, (String)null, "Nieskończoność", "Infinity");
      register((String)null, (String)null, "Jedwabny dotyk", "Silk Touch");
      register((String)null, (String)null, "Naprawa", "Mending");
      register((String)null, (String)null, "Pancerny kadłub", "Protection");
   }
}
