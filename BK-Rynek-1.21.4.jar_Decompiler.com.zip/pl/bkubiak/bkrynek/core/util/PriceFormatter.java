package pl.bkubiak.bkrynek.core.util;

import java.util.Locale;

public class PriceFormatter {
   public static double parsePrice(String raw) {
      if (raw != null && !raw.isEmpty()) {
         raw = raw.trim().replace(',', '.');
         double multiplier = (double)1.0F;
         String lower = raw.toLowerCase();
         if (lower.endsWith("k")) {
            multiplier = (double)1000.0F;
            raw = raw.substring(0, raw.length() - 1);
         } else if (lower.endsWith("mld")) {
            multiplier = (double)1.0E9F;
            raw = raw.substring(0, raw.length() - 3);
         } else if (lower.endsWith("m")) {
            multiplier = (double)1000000.0F;
            raw = raw.substring(0, raw.length() - 1);
         }

         try {
            double base = Double.parseDouble(raw);
            return base * multiplier;
         } catch (NumberFormatException var6) {
            return (double)-1.0F;
         }
      } else {
         return (double)-1.0F;
      }
   }

   public static String formatPrice(double value) {
      double absVal = Math.abs(value);
      String suffix = "";
      if (absVal >= (double)1.0E9F) {
         value /= (double)1.0E9F;
         suffix = "mld";
      } else if (absVal >= (double)1000000.0F) {
         value /= (double)1000000.0F;
         suffix = "m";
      } else if (absVal >= (double)1000.0F) {
         value /= (double)1000.0F;
         suffix = "k";
      }

      String formatted = String.format(Locale.US, "%.2f", value);
      if (formatted.contains(".")) {
         formatted = formatted.replaceAll("0+$", "").replaceAll("\\.$", "");
      }

      return formatted + suffix + "$";
   }
}
