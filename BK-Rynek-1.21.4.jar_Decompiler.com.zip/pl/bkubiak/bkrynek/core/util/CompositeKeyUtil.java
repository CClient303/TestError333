package pl.bkubiak.bkrynek.core.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import pl.bkubiak.bkrynek.core.config.PriceEntry;

public class CompositeKeyUtil {
   private static final Pattern PATTERN = Pattern.compile("^(.*?)\\s*(?:\\(\\s*\\\"([^\\\"]+)\\\"\\s*\\))?\\s*(?:\\[\\s*\\\"([^\\\"]+)\\\"\\s*\\])?\\s*(?:\\{\\s*\\\"([^\\\"]+)\\\"\\s*\\})?\\s*$");

   public static String createCompositeKey(String rawInput) {
      String normalized = rawInput.trim();
      if (normalized.startsWith("[\"") && normalized.endsWith("\"]")) {
         String material = normalized.substring(2, normalized.length() - 2).trim().toLowerCase();
         return material + "|||";
      } else if (normalized.toLowerCase().startsWith("minecraft:") && normalized.matches("(?i)^minecraft:[a-z0-9_]+$")) {
         String material = normalized.toLowerCase();
         return material + "|||";
      } else {
         Matcher matcher = PATTERN.matcher(normalized);
         String lore = "";
         String material = "";
         String enchants = "";
         String baseName;
         if (matcher.matches()) {
            baseName = matcher.group(1).trim();
            if (matcher.group(2) != null) {
               lore = matcher.group(2).trim();
            }

            if (matcher.group(3) != null) {
               material = matcher.group(3).trim();
            }

            if (matcher.group(4) != null) {
               enchants = matcher.group(4).trim();
            }
         } else {
            baseName = normalized;
         }

         if (!material.isEmpty() && !material.toLowerCase().startsWith("minecraft:")) {
            material = "minecraft:" + material;
         }

         return (baseName + "|" + lore + "|" + material + "|" + enchants).toLowerCase();
      }
   }

   public static String getFriendlyName(String compositeKey) {
      String[] parts = compositeKey.split("\\|", -1);
      String baseName = parts[0];
      String lore = parts[1];
      String material = parts[2];
      String enchants = parts.length > 3 ? parts[3] : "";
      StringBuilder sb = new StringBuilder();
      if (!baseName.isEmpty()) {
         sb.append(baseName);
         if (!lore.isEmpty()) {
            sb.append("(\"").append(lore).append("\")");
         }

         if (!enchants.isEmpty()) {
            sb.append("{\"").append(enchants).append("\"}");
         }

         return sb.toString();
      } else {
         return !material.isEmpty() ? material : "";
      }
   }

   public static String getCompositeKeyFromEntry(PriceEntry entry) {
      String var10000 = entry.name;
      return (var10000 + "|" + (entry.lore == null ? "" : entry.lore) + "|" + (entry.material == null ? "" : entry.material) + "|" + (entry.enchants == null ? "" : entry.enchants) + "|" + (entry.excludedEnchants == null ? "" : entry.excludedEnchants) + "|" + String.valueOf(entry.minDaysLeft == null ? "" : entry.minDaysLeft) + "|" + entry.componentCount + "|" + String.valueOf(entry.customModelData == null ? "" : entry.customModelData)).toLowerCase();
   }

   public static String[] splitCompositeKey(String compositeKey) {
      return compositeKey.split("\\|", -1);
   }
}
