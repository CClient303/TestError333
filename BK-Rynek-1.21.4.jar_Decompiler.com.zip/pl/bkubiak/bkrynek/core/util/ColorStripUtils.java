package pl.bkubiak.bkrynek.core.util;

import java.util.HashMap;
import java.util.Map;

public class ColorStripUtils {
   private static final Map<Character, Character> SMALL_FONT_MAP = new HashMap<Character, Character>() {
      {
         this.put('ᴀ', 'a');
         this.put('ʙ', 'b');
         this.put('ᴄ', 'c');
         this.put('ᴅ', 'd');
         this.put('ᴇ', 'e');
         this.put('ꜰ', 'f');
         this.put('ɢ', 'g');
         this.put('ʜ', 'h');
         this.put('ɪ', 'i');
         this.put('ᴊ', 'j');
         this.put('ᴋ', 'k');
         this.put('ʟ', 'l');
         this.put('ᴍ', 'm');
         this.put('ɴ', 'n');
         this.put('ᴏ', 'o');
         this.put('ᴘ', 'p');
         this.put('ʀ', 'r');
         this.put('ꜱ', 's');
         this.put('ᴛ', 't');
         this.put('ᴜ', 'u');
         this.put('ᴠ', 'v');
         this.put('ᴡ', 'w');
         this.put('ʏ', 'y');
         this.put('ᴢ', 'z');
         this.put('ꜱ', 's');
         this.put('ꜰ', 'f');
         this.put('ʟ', 'l');
         this.put('ᵃ', 'a');
         this.put('ᵇ', 'b');
         this.put('ᶜ', 'c');
         this.put('ᵈ', 'd');
         this.put('ᵉ', 'e');
         this.put('ᶠ', 'f');
         this.put('ᵍ', 'g');
         this.put('ʰ', 'h');
         this.put('ⁱ', 'i');
         this.put('ʲ', 'j');
         this.put('ᵏ', 'k');
         this.put('ˡ', 'l');
         this.put('ᵐ', 'm');
         this.put('ⁿ', 'n');
         this.put('ᵒ', 'o');
         this.put('ᵖ', 'p');
         this.put('ʳ', 'r');
         this.put('ˢ', 's');
         this.put('ᵗ', 't');
         this.put('ᵘ', 'u');
         this.put('ᵛ', 'v');
         this.put('ʷ', 'w');
         this.put('ˣ', 'x');
         this.put('ʸ', 'y');
         this.put('ᶻ', 'z');
         this.put('ⓐ', 'a');
         this.put('ⓑ', 'b');
         this.put('ⓒ', 'c');
         this.put('ⓓ', 'd');
         this.put('ⓔ', 'e');
         this.put('ⓕ', 'f');
         this.put('ⓖ', 'g');
         this.put('ⓗ', 'h');
         this.put('ⓘ', 'i');
         this.put('ⓙ', 'j');
         this.put('ⓚ', 'k');
         this.put('ⓛ', 'l');
         this.put('ⓜ', 'm');
         this.put('ⓝ', 'n');
         this.put('ⓞ', 'o');
         this.put('ⓟ', 'p');
         this.put('ⓠ', 'q');
         this.put('ⓡ', 'r');
         this.put('ⓢ', 's');
         this.put('ⓣ', 't');
         this.put('ⓤ', 'u');
         this.put('ⓥ', 'v');
         this.put('ⓦ', 'w');
         this.put('ⓧ', 'x');
         this.put('ⓨ', 'y');
         this.put('ⓩ', 'z');
         this.put('⁰', '0');
         this.put('¹', '1');
         this.put('²', '2');
         this.put('³', '3');
         this.put('⁴', '4');
         this.put('⁵', '5');
         this.put('⁶', '6');
         this.put('⁷', '7');
         this.put('⁸', '8');
         this.put('⁹', '9');
         this.put('₀', '0');
         this.put('₁', '1');
         this.put('₂', '2');
         this.put('₃', '3');
         this.put('₄', '4');
         this.put('₅', '5');
         this.put('₆', '6');
         this.put('₇', '7');
         this.put('₈', '8');
         this.put('₉', '9');
         this.put('０', '0');
         this.put('１', '1');
         this.put('２', '2');
         this.put('３', '3');
         this.put('４', '4');
         this.put('５', '5');
         this.put('６', '6');
         this.put('７', '7');
         this.put('８', '8');
         this.put('９', '9');
         this.put('⓪', '0');
         this.put('①', '1');
         this.put('②', '2');
         this.put('③', '3');
         this.put('④', '4');
         this.put('⑤', '5');
         this.put('⑥', '6');
         this.put('⑦', '7');
         this.put('⑧', '8');
         this.put('⑨', '9');
      }
   };

   public static String stripAllColorsAndFormats(String input) {
      if (input != null && !input.isEmpty()) {
         input = mapSmallFont(input);
         input = input.replaceAll("§[0-9A-FK-ORa-fk-or]", "");
         input = input.replaceAll("§x(§[0-9A-Fa-f]){6}", "");
         input = input.replaceAll("(?i)<gradient:[^>]*>", "");
         input = input.replaceAll("(?i)</gradient>", "");
         input = input.replaceAll("(?i)<#?[0-9A-F]{6}>", "");
         input = input.replaceAll("(?i)<##[0-9A-F]{6}>", "");
         input = input.replaceAll("(?i)&#[0-9A-F]{6}", "");
         return input.trim();
      } else {
         return "";
      }
   }

   private static String mapSmallFont(String input) {
      StringBuilder sb = new StringBuilder();

      for(int i = 0; i < input.length(); ++i) {
         char c = input.charAt(i);
         if (SMALL_FONT_MAP.containsKey(c)) {
            sb.append(SMALL_FONT_MAP.get(c));
         } else {
            sb.append(c);
         }
      }

      return sb.toString();
   }
}
