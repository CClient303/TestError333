package pl.bkubiak.bkrynek.core.util;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpResponse.BodyHandlers;
import java.time.Duration;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

public final class RemoteAdConfig {
   private static final String CONFIG_URL = "https://raw.githubusercontent.com/xqbkubiak/BK-Rynek/refs/heads/ad/config.json";
   private static final String DEFAULT_NAME = "BK-Rynek";
   private static final String DEFAULT_ADDRESS = null;
   private static volatile String cachedName = "BK-Rynek";
   private static volatile String cachedAddress;
   private static volatile boolean fetched;
   private static final AtomicBoolean started;
   private static final Gson GSON;

   private RemoteAdConfig() {
   }

   public static void preloadAsync() {
      if (started.compareAndSet(false, true)) {
         Thread t = new Thread(RemoteAdConfig::fetchOnce, "bkrynek-remote-ad-fetch");
         t.setDaemon(true);
         t.start();
      }
   }

   public static String serverName() {
      if (!fetched) {
         return "BK-Rynek";
      } else {
         return cachedName != null && !cachedName.isBlank() ? cachedName : "BK-Rynek";
      }
   }

   public static String serverAddress() {
      if (!fetched) {
         return null;
      } else {
         return cachedAddress != null && !cachedAddress.isBlank() ? cachedAddress : null;
      }
   }

   private static void fetchOnce() {
      try {
         HttpClient client = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(2L)).build();
         HttpRequest req = HttpRequest.newBuilder().uri(URI.create("https://raw.githubusercontent.com/xqbkubiak/BK-Rynek/refs/heads/ad/config.json")).header("Accept", "application/json").header("User-Agent", "BK-Rynek/1 JavaHttpClient").timeout(Duration.ofSeconds(4L)).GET().build();
         HttpResponse<String> resp = client.send(req, BodyHandlers.ofString());
         if (resp.statusCode() >= 200 && resp.statusCode() < 300) {
            String body = (String)resp.body();
            JsonObject obj = (JsonObject)GSON.fromJson(body, JsonObject.class);
            if (obj != null) {
               boolean hasName = obj.has("serverName");
               boolean nameIsNull = hasName && obj.get("serverName").isJsonNull();
               boolean hasAddr = obj.has("serverAddress");
               boolean addrIsNull = hasAddr && obj.get("serverAddress").isJsonNull();
               if (hasName) {
                  if (nameIsNull) {
                     cachedName = null;
                  } else {
                     String name = obj.get("serverName").getAsString();
                     if (name != null && !name.isBlank()) {
                        cachedName = name;
                     }
                  }
               }

               if (hasAddr) {
                  if (addrIsNull) {
                     cachedAddress = null;
                  } else {
                     String addr = obj.get("serverAddress").getAsString();
                     if (addr != null && !addr.isBlank()) {
                        cachedAddress = normalizeAddress(addr);
                     }
                  }
               }

               fetched = true;
               System.out.println("[BK-Rynek] Remote config loaded: name='" + cachedName + "', address='" + cachedAddress + "'");
            }
         } else {
            System.out.println("[BK-Rynek] Remote config HTTP status: " + resp.statusCode());
         }
      } catch (Throwable t) {
         System.out.println("[BK-Rynek] Remote config fetch failed: " + t.getMessage());
      }

   }

   private static String normalizeAddress(String address) {
      if (address == null) {
         return null;
      } else {
         String a = address.trim().toLowerCase(Locale.ROOT);
         if (a.endsWith(":25565")) {
            a = a.substring(0, a.length() - 6);
         }

         return a;
      }
   }

   static {
      cachedAddress = DEFAULT_ADDRESS;
      fetched = false;
      started = new AtomicBoolean(false);
      GSON = new Gson();
   }
}
