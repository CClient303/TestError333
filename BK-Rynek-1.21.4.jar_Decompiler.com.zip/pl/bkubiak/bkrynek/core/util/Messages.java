package pl.bkubiak.bkrynek.core.util;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Messages {
   private static final Map<String, List<String>> messages = new HashMap();
   private static String currentLang = "pl";

   public static void load(String lang) {
      System.out.println("[BK-Rynek] Loading messages for: " + lang);
      currentLang = lang;
      String path = "/assets/bkrynek/messages/messages_" + lang + ".json";

      try {
         InputStream in = Messages.class.getResourceAsStream(path);

         try {
            if (in == null) {
               System.err.println("Message file not found: " + path);
               if (!lang.equals("pl")) {
                  load("pl");
               }
            } else {
               Type type = (new TypeToken<Map<String, List<String>>>() {
               }).getType();
               Map<String, List<String>> loaded = (Map)(new Gson()).fromJson(new InputStreamReader(in, StandardCharsets.UTF_8), type);
               if (loaded != null) {
                  messages.clear();
                  messages.putAll(loaded);
                  System.out.println("[BK-Rynek] Loaded " + loaded.size() + " message keys.");
               } else {
                  System.err.println("[BK-Rynek] Failed to parse message file: " + path);
               }
            }
         } catch (Throwable var6) {
            if (in != null) {
               try {
                  in.close();
               } catch (Throwable var5) {
                  var6.addSuppressed(var5);
               }
            }

            throw var6;
         }

         if (in != null) {
            in.close();
         }
      } catch (Exception e) {
         System.err.println("[BK-Rynek] Error loading messages:");
         e.printStackTrace();
      }

   }

   public static String get(String key) {
      List<String> lines = (List)messages.get(key);
      return lines == null ? "Missing message for key: " + key + " (lang: " + currentLang + ")" : String.join("\n", lines);
   }

   public static String format(String key, Map<String, String> placeholders) {
      List<String> lines = (List)messages.get(key);
      if (lines == null) {
         return "Missing message for key: " + key + " (lang: " + currentLang + ")";
      } else {
         List<String> replaced = new ArrayList();

         for(String line : lines) {
            for(Map.Entry<String, String> entry : placeholders.entrySet()) {
               line = line.replace("%" + (String)entry.getKey() + "%", (CharSequence)entry.getValue());
            }

            replaced.add(line);
         }

         return String.join("\n", replaced);
      }
   }

   public static String get(String key, String... args) {
      if (args.length == 0) {
         return get(key);
      } else {
         Map<String, String> placeholders = new HashMap();

         for(int i = 0; i < args.length; i += 2) {
            if (i + 1 < args.length) {
               placeholders.put(args[i], args[i + 1]);
            }
         }

         return format(key, placeholders);
      }
   }

   static {
      load("pl");
   }
}
