package pl.bkubiak.bkrynek.core.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class EnchantStringParser {
   private static final Pattern NEWER_PATTERN = Pattern.compile("ResourceKey\\[\\s*minecraft:enchantment\\s*/\\s*minecraft:([^\\]]+)\\]\\s*=Enchantment [^}]+}\\s*=>\\s*(\\d+)");
   private static final Pattern OLDER_PATTERN = Pattern.compile("\\{id:\"([^\"]+)\",lvl:(\\d+)s\\}");

   private EnchantStringParser() {
   }

   public static String parse(String rawEnchants) {
      if (rawEnchants != null && !rawEnchants.isEmpty()) {
         Matcher enchantMatcherNew = NEWER_PATTERN.matcher(rawEnchants);
         StringBuilder enchantBuilder = new StringBuilder();

         boolean foundAny;
         String mappedEnchant;
         for(foundAny = false; enchantMatcherNew.find(); enchantBuilder.append(mappedEnchant)) {
            foundAny = true;
            String enchId = enchantMatcherNew.group(1).trim();
            String levelStr = enchantMatcherNew.group(2).trim();
            String shortEnchant = enchId + levelStr;
            mappedEnchant = EnchantMapper.mapEnchant(shortEnchant, true);
            if (enchantBuilder.length() > 0) {
               enchantBuilder.append(",");
            }
         }

         String mappedEnchant;
         if (!foundAny) {
            for(Matcher enchantMatcherOld = OLDER_PATTERN.matcher(rawEnchants); enchantMatcherOld.find(); enchantBuilder.append(mappedEnchant)) {
               String enchId = enchantMatcherOld.group(1).trim();
               String levelStr = enchantMatcherOld.group(2).trim();
               if (enchId.startsWith("minecraft:")) {
                  enchId = enchId.substring("minecraft:".length());
               }

               mappedEnchant = enchId + levelStr;
               mappedEnchant = EnchantMapper.mapEnchant(mappedEnchant, false);
               if (enchantBuilder.length() > 0) {
                  enchantBuilder.append(",");
               }
            }
         }

         return enchantBuilder.toString();
      } else {
         return "";
      }
   }
}
